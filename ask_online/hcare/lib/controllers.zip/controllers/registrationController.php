<?php session_start();

require_once ROOT_PATH . '/lib/common/form.php';
require_once ROOT_PATH . '/lib/model/registration/registration.php';
require_once ROOT_PATH . '/lib/model/admin/employee.php';
require_once ROOT_PATH . '/lib/model/admin/department.php';
require_once ROOT_PATH . '/lib/model/admin/insurance_company.php';
require_once ROOT_PATH . '/lib/model/admin/general.php';
require_once ROOT_PATH . '/lib/model/admin/op_reset_no.php';
require_once ROOT_PATH . '/lib/model/DBFunctions.php';
require_once ROOT_PATH . '/lib/common/commonFunctions.php';
require_once ROOT_PATH . '/lib/model/booking/booking.php';
require_once ROOT_PATH . '/lib/controllers/bookingController.php';

class RegistrationController {

	

	function viewPage($sub_module,$postArr='',$getArr='',$message=''){
	
			$form_creator = new Form();
			
			if(!empty ($message)){
				$form_creator ->popArr['message']=$message;
			}
			switch($sub_module){
				
				case 'patient_registeration'	:
													$db_obj=new DBFunction();
													$emp_obj=new Employee();
													$dep_obj=new Department();
													$bk_obj = new Booking();
													$gen_obj = new General();
													
													if(isset($postArr['paction']) && $postArr['paction']="REREG_FORM"){
														$form_creator ->popArr['status']="RENEW";
													}else{
														$form_creator ->popArr['status']="NEW";
													}
													if(!empty($getArr['bk_id'])){
													
														$form_creator ->popArr['bk_id']=$getArr['bk_id'];
														$wheredata[0]="id='".$getArr['bk_id']."'";
														
														$bkInfo=$bk_obj->getBookingList($wheredata);													
														
														
														$is_field[0]="a.id ='".$bkInfo[0][2]."'";
					
														$docinfo=$emp_obj->getEmployee($is_field);
														
														$docfee=$docinfo[0][19];
														$post['validity_days']=$docinfo[0][23];
														//registration fees
														$selectfield[0]="reg_fee";
														$reg_fee=$gen_obj->getOpSettings($selectfield,'','date','desc');
														$regfee=$reg_fee[0][0];
														
														$post['bk_id']=$bkInfo[0][0];
														$post['token']=$bkInfo[0][1];
														$post['doctor']=$bkInfo[0][2];
														$post['first_name']=$bkInfo[0][6];
														$post['place']=$bkInfo[0][7];
														$post['contact_no']=$bkInfo[0][8];
														$post['docfee']=$docfee;
														$post['regfee']=$regfee;
														
														$form_creator ->popArr['post']=$post;
														$form_creator ->popArr['status']="NEW";
														$form_creator ->popArr['doctors']=$emp_obj->getEmployee($is_field);
														
													}else{
													
														$is_field[0]="a.title='Dr'";												
														$form_creator ->popArr['doctors']=$emp_obj->getEmployee($is_field);
													}
													$form_creator ->popArr['action']="REGISTRATION";
													$form_creator ->popArr['departments']=$dep_obj->getDepartment();
													$form_creator ->popArr['countries']=$db_obj->getCountries();
													$form_creator ->formPath ='/templates/registration/registration_form.php';
													break;
				case 'Print_OP_Sheet'			:
													$reg_obj= new Registration();
													$emp_obj= new Employee();
													
													$id=$postArr['id'];
													
													$selectCondition[]="b.`id`>='".$id."'";
													$form_creator ->popArr['patient_info']=$patientInfo=$reg_obj->getOPPatientInfo('',$selectCondition);
													
													$is_field[0]="a.id='".$patientInfo[0][14]."'";
													$form_creator ->popArr['empInfo']=$emp_obj->getEmployee($is_field);
													
													$form_creator ->formPath ='/templates/registration/print_op_sheet.php';
													break;
				case 'ManagePatients'			:
														$com_obj = new CommonFunctions();
														$reg_obj= new Registration();
														$emp_obj= new Employee();
														
														if(isset($postArr['from_date']) && $postArr['action']!="CLEAR"){
															$fromdate=$com_obj->getcurrentDate("Y-m-d",$postArr['from_date']);
															$todate=$com_obj->getcurrentDate("Y-m-d",$postArr['to_date']);
															
															if(!empty($postArr["opno"])){
																$selectCondition[]="a.`id`='".$postArr["opno"]."'";
															}
															if(!empty($postArr["first_name"])){
																$selectCondition[]="a.`first_name` like '%".$postArr["first_name"]."%'";
															}
															if(!empty($postArr["place"])){
																$selectCondition[]="a.`place`='".$postArr["place"]."'";
															}
															if(!empty($postArr["doctor"])){
																$selectCondition[]="b.`doc_id`='".$postArr["doctor"]."'";
															}
														}else{
															$fromdate=$com_obj->getcurrentDate();
															$todate=$com_obj->getcurrentDate();
														}
														
														$selectCondition[]="b.`visit_date`>='".$fromdate."'";
														$selectCondition[]="b.`visit_date`<='".$todate."'";
														$selectCondition[]="b.`cancelled`=0";
														
														$form_creator ->popArr['patient_info']=$reg_obj->getOPPatientInfo('',$selectCondition,'b.visit_date','asc');
														
														 if(isset($postArr['action']) && $postArr['action']!="CLEAR"){
															$form_creator ->popArr['post']=$postArr;
														}else $form_creator ->popArr['post']='';
														
														$is_field[0]="a.title='Dr'";													
														$form_creator ->popArr['doctors']=$emp_obj->getEmployee($is_field);
														
														$form_creator ->formPath ='/templates/registration/manage_op_patients.php';
														break;
				
										
						
									
			
			}
			
			$form_creator->display();
	
	}
	function processOPNo($post,$get = null){
		
		$form_creator = new Form();
		
		$reg_obj= new Registration();
		$emp_obj= new Employee();
		$inc_obj= new InsuranceCompany();
		$db_obj=new DBFunction();
		$dep_obj=new Department();		
		$com_obj = new CommonFunctions();
		$gen_obj = new General();
		$bk_obj = new Booking();
		
		
		$todate =$com_obj->getcurrentDate();
		$booking_status="0";
		
		if(!empty($post['id'])){
			$opid=$post['id'];
			$selectCondition[0]="b.`id`='".$opid."'";
		}else{
			$opno=$post['opno'];
			$selectCondition[0]="a.`id`='".$opno."'";
		}
		
		if(!empty($get['bk_id'])){
			
				$wheredata[0]="id='".$get['bk_id']."'";
				$bkInfo=$bk_obj->getBookingList($wheredata);
				$docid=$bkInfo[0][2];
				$post['bk_id']=$bkInfo[0][0];
				$post['token']=$bkInfo[0][1];
				$selectCondition[1]="b.`doc_id`='".$docid."'";
				
				$patientInfo=$reg_obj->getOPPatientInfo('',$selectCondition,'b.id','desc');
				
				if(empty($patientInfo)){
					$booking_status="0";
				}else $booking_status=1;
				
				unset($selectCondition[1]);
		
		}
		if($booking_status == 0 ) {
			$patientInfo=$reg_obj->getOPPatientInfo('',$selectCondition,'b.id','desc');
		}
		
		if(!empty($patientInfo)){
		
			$post['opno']=$opno=$patientInfo[0][0];			
			$validity = $patientInfo[0][21];
			$age=$patientInfo[0][4];
			$dob=$patientInfo[0][5];
			$visit_date=$patientInfo[0][20];
			$free =$patientInfo[0][41];
			
			if($free == 1) $post['free']=1;
			
			if($booking_status ==0 && empty($get['bk_id'])){
			
				$docid=$patientInfo[0][14];			
				
			}else $validity =date("Y-m-d");
			
			
			
			if(!empty($post['id'])){
				
				$status =$patientInfo[0][32];
				
				//$docfee=$patientInfo[0][17];
				$docfee=$patientInfo[0][18];
				
				
				$age_in=explode(" ",$age);
				$age=$age_in[0];
				$age_type=$age_in[1];
				
				$form_creator ->popArr['action']="REG_UPDATE";
				$post['refferal_info']=$patientInfo[0][34];
			}else{
			
					if($visit_date == $todate && empty($get['bk_id'])) {
						 $form_creator ->popArr['message1']="Patient Already Registered for Selected Doctor!";
					}
					if($validity < $todate){
				
						$status ="RENEW";
				
						//doctor fee
				
						$is_field[0]="a.id ='".$docid."'";
					
						$docinfo=$emp_obj->getEmployee($is_field);
						$docfee=$docinfo[0][19];
						$post['validity_days']=$docinfo[0][23];
				
						//registration fees
						$selectfield[0]="reg_fee";
						$reg_fee=$gen_obj->getOpSettings($selectfield,'','date','desc');
						$regfee=$reg_fee[0][0];
				
					}else {
			
						$status ="VISIT";
						$docfee=0;
						$regfee=0;
					}
			
			
			//Calculate age
		
			//$ageInfo=$this->calculateAge($dob,$age);
			//$age=$ageInfo[0];
			//$age_type=$ageInfo[1];
			
			$age_in=explode(" ",$age);
				$age=$age_in[0];
				$age_type=$age_in[1];
			
			$form_creator ->popArr['action']="REGISTRATION";
		}
			
			
			
			$post['first_name']=$patientInfo[0][1];
			$post['middle_name']=$patientInfo[0][2];
			$post['last_name']=$patientInfo[0][3];
			$post['age']=$age;
			$post['age_type']=$age_type;
		
			$post['gender']=$patientInfo[0][6];
			$post['marital_status']=$patientInfo[0][7];
			$post['place']=$patientInfo[0][8];
			$post['nationality']=$patientInfo[0][9];
			$post['contact_no']=$patientInfo[0][10];
			$post['email']=$patientInfo[0][11];
			$post['doctor']=$docid;
			$post['docfee']=$docfee;
			$post['regfee']=$regfee;
			$post['insurance_company']=$patientInfo[0][22];
			$post['policy_no']=$patientInfo[0][24];
			$post['claim']=$patientInfo[0][25];
			$post['company_name']=$patientInfo[0][26];
			$post['company_id']=$patientInfo[0][27];
			$post['relation']=$patientInfo[0][28];
			if($patientInfo[0][29] !='0000-00-00' && $patientInfo[0][30] !='0000-00-00'){
				$post['date_issue']=date("d-m-Y",strtotime($patientInfo[0][29]));
				$post['date_expiry']=date("d-m-Y",strtotime($patientInfo[0][30]));
			}
			if($patientInfo[0][5] !='0000-00-00' && $patientInfo[0][5] !="1970-01-01"){
					$post['dob']=date("d-m-Y",strtotime($patientInfo[0][5]));
			}
			
			if($post['insurance_company']>0){
				$post['inc']="insurance";
			}
			if(!empty($patientInfo[0][38] )){
			
					$post['mlc']="mlc";
					$post['mlc_date']=$patientInfo[0][20];
					$post['mlc_time']=$patientInfo[0][19];
					$post['mlc_summary']=$patientInfo[0][38];
			}
					
			
			if($patientInfo[0][22] >0 ){
			
					$is_field[0]="a.valid_upto >='".$todate."'";
					$form_creator ->popArr['insurance_company']=$inc_obj->getInsCompany($is_field);
			}
			
			$form_creator ->popArr['post']=$post;		
		
		}else {
		
			$form_creator ->popArr['message']="Invalid OP Number";
			if(!empty($get['bk_id'])){
				$form_creator ->formPath ='/templates/booking/booking_report.php';
				//$form_creator->display();
				exit();
			}
		}
			$is_field[0]="a.title ='Dr'";
			if(!empty($get['bk_id'])){
				$is_field[1]="a.id ='".$bkInfo[0][2]."'";
			}
			$form_creator ->popArr['doctors']=$emp_obj->getEmployee($is_field);
			$form_creator ->popArr['departments']=$dep_obj->getDepartment();
			$form_creator ->popArr['countries']=$db_obj->getCountries();
			$form_creator ->popArr['status']=$status;
			
			
			$form_creator ->formPath ='/templates/registration/registration_form.php';
			$form_creator->display();
	
	}
	function calculateAge($dob = null ,$age = null ){
	
			if($dob !='0000-00-00'){
			
				$value = ((time() - strtotime($dob)) / 31556926);
				if($value < 1) {
					$age_value = (round(((time() - strtotime($dob)) / 31556926),2)*10);
					if($age_value < 1){
					
								
						$age = ($age_value+.1)*30;
						$age_type="D";
						
					}else{
						$age=ceil($age_value);
						$age_type="M";
					}
					
				}else{
					$age = floor((time() - strtotime($dob)) / 31556926);
					$age_type="Y";
				}
				
			}else if($age !=''){
			
				$age_in=explode(" ",$age);
				$age=$age_in[0];
				if($age_in[1] == "Y"){
					$age_type="year";
				}else if($age_in[1] == "M"){
					$age_type="month";
				}else $age_type ="days";
				
				$dob_exp=date("Y-m-d",strtotime("-".$age."$age_type"));
				
				$age = floor((time() - strtotime($dob_exp)) / 31556926);
				$age_type=$age_in[1];
			}else {
				$age_in=explode(" ",$age);
				$age=$age_in[0];
				$age_type=$age_in[1];
			}
			
		return array($age,$age_type);	
	}
	function processRegForm($post){
	
			$form_creator = new Form();
			$emp_obj= new Employee();
			$inc_obj= new InsuranceCompany();
			$db_obj=new DBFunction();
			$dep_obj=new Department();
			$gen_obj = new General();
			$com_obj = new CommonFunctions();
			$reg_obj= new Registration();
			
			$dep_id=$post['department'];
			$inc=$post['inc'];
			$mlc=$post['mlc'];
			$inc_company=$post['insurance_company'];
			$docid=$post['doctor'];
			$status=$post['status'];
			$action=$post['paction'];
			$todate =$com_obj->getcurrentDate();
			$docfee=0;
			$reg_fee=0;
			
			if(!empty($post['free'])){
				$status="FREE";
			}
			
			
			
			//if department selected show doctors in selected department else show all doctors
			if($dep_id !='') {
			
					$is_field[0]="a.title ='Dr'";
					
					$form_creator ->popArr['doctors']=$emp_obj->getEmployee($is_field,$dep_id);
			
			}else{
					$is_field[0]="a.title ='Dr'";
					
					$form_creator ->popArr['doctors']=$emp_obj->getEmployee($is_field);
			
			}
			
			//If insurance checked true then show insurance companies
			if($inc != ''){
					$is_field[0]="a.valid_upto >='".$todate."'";
					$form_creator ->popArr['insurance_company']=$inc_obj->getInsCompany($is_field);
			
			}
			
			//if doctor selected then get doc fee and reg fee
			if($docid!=''){
					$is_field='';
					
					$is_field[0]="a.id ='".$docid."'";
					
					$docinfo=$emp_obj->getEmployee($is_field);
					$post['validity_days']=$docinfo[0][23];
					
					if(!empty($post['opno']) && $status!="NEW"){
					
						$opno=$post['opno'];
						$selectCondition[0]="a.`id`='".$opno."'";
						$selectCondition[1]="b.`doc_id`='".$docid."'";
						if(!empty($post['id'])){
							$selectCondition[2]="b.`id`<'".$post['id']."'";
						}
						
						$patientInfo=$reg_obj->getOPPatientInfo('',$selectCondition,'b.id','desc');
						
						if(!empty($patientInfo)){
												
							$validity = $patientInfo[0][21];
							$visit_date=$patientInfo[0][20];
							
							
							
								if($visit_date == $todate) $form_creator ->popArr['message1']="Patient Already Registered for Selected Doctor!";
							
							
							
							if($validity <= $todate){
				
								$status ="RENEW";
								
								
							}else{
							
								$status ="VISIT";
								
							}
						
						}else{
						
								$status ="RENEW";
								
						}
					}else {
					
							
								$status ="NEW";
						
					}
				
					switch($status) {
					
						case 'VISIT' : $docfee=0;
										$regfee=0;
										break;
							default	 :
										$docfee=$docinfo[0][19];
										//registration fees
										$selectfield[0]="reg_fee";
										$reg_fee=$gen_obj->getOpSettings($selectfield,'','date','desc');
										$regfee=$reg_fee[0][0];
										break;
					
					}
					
					if(!empty($post['free'])){
					
						$docfee=0;
						$regfee=0;
					}
					
					$emp_depid=$docinfo[0][10];
					
					
					if($dep_id!='' && $dep_id!=$emp_depid){
						$docfee='';
					}
					
					
			}
			
			//If insurance company selected then get doctor fee after insurance deduction
			if(!empty($inc_company)){
			
				$docfee =$docfee - $this->getinsuranceDeduction($inc_company,"CONSULTATION",$docfee);		
			}
			
			if($post['dob']!=''){
				$ageInfo=$this->calculateAge($post['dob']);
				
				
				$post['age']=$ageInfo[0];
				$post['age_type']=$ageInfo[1];
			}
			
			$post['docfee']=$docfee;
			$post['regfee']=$regfee;
			
			
			$form_creator ->popArr['departments']=$dep_obj->getDepartment();
			$form_creator ->popArr['countries']=$db_obj->getCountries();
			$form_creator ->popArr['post']=$post;
			
			$form_creator ->formPath ='/templates/registration/registration_form.php';
			$form_creator ->popArr['action']=$action;
			$form_creator ->popArr['status']=$status;
			$form_creator->display();
													
	
	}
	function getinsuranceDeduction($ins_id,$type,$field_value){
	
			$inc_obj= new InsuranceCompany();
			
			$is_field[0]="a.id ='".$ins_id."'";
					
			$incInfo=$inc_obj->getInsCompany($is_field);
			
			if($type == "CONSULTATION") {
			
				$disc_type=$incInfo[0][15];
				$disc_value=$incInfo[0][16];
			}
			
			if($disc_type =="Cash"  && $disc_value>0 && $field_value>0){
												
					$disc_amt=$disc_value;
								
			}else if($disc_type =="%"  && $disc_value>0 && $field_value>0){
							
					$disc_amt=($field_value*$disc_value/100);
			}else{
					$disc_amt =0;
			}
	
		return $disc_amt;
	}
	function processRegistration($post){
	
		$gen_obj = new General();
		$com_obj = new CommonFunctions();
		$reg_obj= new Registration();
		$restOp_obj= new OPResetNo();
		$opno=0;
	
		$action =$post['paction'];
		$status =$post['status'];
		
		$selectfield[0]="op_validity";
		
		$validity_days=$post['validity_days'];
		if($validity_days==0){
		$validity_days=$gen_obj->getOpSettings($selectfield,'','date','desc');
		}
		
		$post['visit_time']=$com_obj->getcurrentTime('h:i a');
		$post['visit_date'] =$com_obj->getcurrentDate();
		
		$inc_company=$post['insurance_company'];
		if(!empty($inc_company)){
		
				$post['cons_disc_amt']=$this->getinsuranceDeduction($inc_company,"CONSULTATION",$post['docfee']);
				
		}else {
		
			$post['cons_disc_amt']=0;
			$post['insurance_company']='';
			$post['policy_no']='';
			$post['claim']='';
			$post['company_name']='';
			$post['company_id']='';
			$post['relation']='';
			$post['date_issue']='';
			$post['date_expiry']='';
		}
		
		if(empty($post['mlc'])){
		
					
			$post['mlc_date']='';
			$post['mlc_time']='';
			$post['mlc_summary']='';
			
		}else {
			$post['visit_time']=$post['mlc_time'];
		}
		
		
		switch($status){
		
			case 'NEW'		:								
										$post['validity'] =date("Y-m-d",strtotime("+".$validity_days." day"));
										if($action =="REGISTRATION"){
											$opno=$reg_obj->addPatientinfo($post);
										}else {
											
											$opno=$reg_obj->updatePatientinfo($post);
										}
										
										break;
			case  'VISIT'			:	
										
										$opno=$post['opno'];
										$docid=$post['doctor'];
										$selectCondition[0]="a.`id`='".$opno."'";
										$selectCondition[1]="b.`doc_id`='".$docid."'";
										$selectField[0]="b.`validity_expiry`";
										
										$patientInfo=$reg_obj->getOPPatientInfo($selectField,$selectCondition,'a.id','desc');
										$post['validity'] =	$patientInfo[0][0];	
																
										$opno=$reg_obj->updatePatientinfo($post);
										break;
			case   'RENEW'		:
										
										
										$post['validity'] =date("Y-m-d",strtotime("+".$validity_days." days"));
										
										$opno=$reg_obj->updatePatientinfo($post);
										break;
		
		}
		
		
		
		if($opno > 0 ){
		
			
			$post['opno']=$opno;
			
			//Generate Token Number
			
			if(empty($post['token'])){
			
				$docid=$post['doctor'];
				$bk_obj = new BookingController();
				$post['token']=$bk_obj->generateTokenNo($docid,date("d-m-Y"));
			}
			if($action =="REGISTRATION"){
			
				$post['reset_op_no']=$restOp_obj->nextResetOPNO();
				
				$opid=$reg_obj->addVisitInfo($post);
				
				$restOp_obj->updateResetOPNO($post['reset_op_no']);
				
				if(!empty($post['token'])){
					$bk_obj = new Booking();
					$bk_obj->updateToVisit($post['bk_id']);	
				}
			}else{
				$opid=$reg_obj->updateVisitInfo($post);
			}
		
		}else $opid=0;
		
		if($opid >0 ){
			$post['id']=$opid;
			
			if($action =="REGISTRATION"){
				$this->viewPage("Print_OP_Sheet",$post);
			}else{
			$this->viewPage("ManagePatients",$post);
			}
		
		}else{
		
			$this->viewPage("patient_registeration");
		}
	
	}
	function deletePatientVisit($post){
	
		$reg_obj= new Registration();
		
		$status=$reg_obj->deletePatientVisit($post);
		$this->viewPage("ManagePatients",$post);
	}
	
	
	
	
}


?>
