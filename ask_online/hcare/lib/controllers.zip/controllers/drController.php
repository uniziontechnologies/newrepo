<?php session_start();

require_once ROOT_PATH . '/lib/common/form.php';
require_once ROOT_PATH . '/lib/common/commonFunctions.php';
require_once ROOT_PATH . '/lib/model/DBFunctions.php';
require_once ROOT_PATH . '/lib/model/inpatient/inpatient.php';
require_once ROOT_PATH . '/lib/model/admin/employee.php';
require_once ROOT_PATH . '/lib/model/procedure/procedure.php';




class DrController {

	

	function viewPage($sub_module,$postArr='',$getArr='',$message=''){
	
			$form_creator = new Form();
			
			if(!empty ($message)){
				$form_creator ->popArr['message']=$message;
			}
			switch($sub_module){ 
				
				
				case 'patient_list':			  
								   $ip_obj= new Inpatient();
                                                                   
									

                                                                   
										
				                         
											  
											 	
							$form_creator ->formPath ='/templates/nurse/home.php';
							break;

                                 
													
			
			}
			
			$form_creator->display();
	
	}
	
       
	
}



?>
