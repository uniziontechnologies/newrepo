<?php session_start();

require_once ROOT_PATH . '/lib/common/form.php';
require_once ROOT_PATH . '/lib/model/DBFunctions.php';
require_once ROOT_PATH . '/lib/common/commonFunctions.php';

require_once ROOT_PATH . '/lib/model/admin/employee.php';
require_once ROOT_PATH . '/lib/model/admin/department.php';
require_once ROOT_PATH . '/lib/model/booking/scheduling.php';
require_once ROOT_PATH . '/lib/model/booking/booking.php';
require_once ROOT_PATH . '/lib/model/admin/general.php';
require_once ROOT_PATH . '/lib/model/booking/reservedTokens.php';

class BookingController {

	var $addSuccess="Added Successfully";
	var $addfailed="Failed To Add";
	

	function viewPage($sub_module,$postArr='',$getArr='',$message=''){
	
			$form_creator = new Form();
			
			if(!empty ($message)){
				$form_creator ->popArr['message']=$message;
			}
			switch($sub_module){
			
				case 'Booking'				:	
												$dep_obj=new Department();
												$dep_id='';
												$date='';
												
												if(!empty($postArr['department'])){
													$dep_id=$postArr['department'];
												}
												if(!empty($postArr['date'])){
													$date=$postArr['date'];
												}
												if(!empty($postArr['id'])){
													$form_creator ->popArr['dateAvaillability']=$this->getDoctorsAvailability($postArr);
													$form_creator ->popArr['docid']=$postArr['id'];
													
													$dbObj= new DBFunction();
													
													$form_creator ->popArr['docname']=$dbObj->getidToValue("title","id",$postArr['id'],"hcare_emp_info")." ".$dbObj->getidToValue("first_name","id",$postArr['id'],"hcare_emp_info")." ".$dbObj->getidToValue("last_name","id",$postArr['id'],"hcare_emp_info");
												}
				
												
												
												$form_creator->popArr['dep_id']=$dep_id;
												$form_creator->popArr['post']=$postArr;
												
												$form_creator ->popArr['doctors']=$this->getDoctorOnDate($date,$dep_id);
												$form_creator ->popArr['departments']=$dep_obj->getDepartment();
												$form_creator ->formPath ='/templates/booking/selectDoctor.php';
											
											break;
				case 'Booking_Form'				:
												$gen_obj = new General();
												$emp_obj=new Employee();
												$shed_obj=new Scheduling();
												
												$opSettings= $gen_obj->getOpSettings();
												$regfee=$opSettings[0][2];
												
												$is_field[0]= "a.id ='$postArr[id]'";
												$doctorInfo=$emp_obj->getEmployee($is_field);
												
												$shedInfo=$shed_obj->getDrScheduling($postArr['id']);
												
												$weekday = date('l', strtotime($postArr['date']));
												$weekno	=date('N', strtotime($postArr['date']));
												if($weekno == 7 ){
													$start=5;
												}else{
													$start=9+($weekno-1)*4;
												}
												$constime='';
												if(!empty($shedInfo[0][$start])){
													$constime .= $shedInfo[0][$start]."-".$shedInfo[0][$start+1];
												}
												if(!empty($shedInfo[0][$start+2])){
													$constime .= "/".$shedInfo[0][$start+2]."-".$shedInfo[0][$start+3];
												}
												$arrList[0]=$postArr['id'];
												$arrList[1]=$doctorInfo[0][1]." ".$doctorInfo[0][2]." ".$doctorInfo[0][3];
												$arrList[2]=$constime;
												$arrList[3]=$postArr['date'];
												$arrList[4]=$doctorInfo[0][19];
												$arrList[5]=$regfee;											
												
												
												$form_creator ->popArr['arrList']=$arrList;
												$form_creator ->popArr['reserved_tokens']=$this->getavailReservedTokens($postArr);
												$form_creator ->formPath ='/templates/booking/booking_form.php';
											
											break;
				case 'Booking_Report'		:
												$bk_obj = new Booking();
												$emp_obj=new Employee();
												$k=0;
												if(!empty($postArr['book_id'])){
												
												 	$wheredata[$k++]="id='".$postArr['book_id']."'";
												 }else{
												 if(!empty($postArr['from_date'])){
												 
												 	$wheredata[$k++]="booking_date >='".date("Y-m-d",strtotime($postArr['from_date']))."' and "."booking_date <='".date("Y-m-d",strtotime($postArr['to_date']))."'";
												 }else $wheredata[$k++]="booking_date >='".date("Y-m-d")."' and "."booking_date <='".date("Y-m-d")."'";
												 if(!empty($postArr['doctor'])){
												 
												 	$wheredata[$k++]="doc_id ='".$postArr['doctor']."'";
												 }
												 if(!empty($postArr['patient_name'])){
												 
												 	$wheredata[$k++]="patient_name like'".$postArr['patient_name']."%'";
												 }
												 if(!empty($postArr['place'])){
												 
												 	$wheredata[$k++]="place like'".$postArr['place']."%'";
												 }
												 if(!empty($postArr['phone'])){
												 
												 	$wheredata[$k++]="phone like'".$postArr['phone']."%'";
												 }
												}
												$wheredata[$k++]="visited=0";
												$form_creator ->popArr['bookingInfo']=$bk_obj->getBookingList($wheredata);
												
												$is_field[0]= "a.title ='Dr'";
												$form_creator ->popArr['doctors']=$emp_obj->getEmployee($is_field);
												$form_creator ->popArr['post']=$postArr;
												
												$form_creator ->formPath ='/templates/booking/booking_report.php';
											
											break;
				
				case 'Manage_Scheduling'	:
												
											$emp_obj=new Employee();
											$dep_obj=new Department();
											$shed_obj=new Scheduling();	
											
											
											
											$is_field[0]= "a.title ='Dr'";
											$dep_id='';
											
											if(!empty($postArr['department'])){
											
												$form_creator ->popArr['dep_id']=$dep_id=$postArr['department'];
												
											}
											
											$form_creator ->popArr['doctors']=$emp_obj->getEmployee($is_field,$dep_id);
											$form_creator ->popArr['departments']=$dep_obj->getDepartment();
											if(!empty($postArr['doctor'])){
											
												$form_creator ->popArr['doc_id']=$postArr['doctor'];
												$is_field[0]="a.id='".$postArr['doctor']."'";
												$form_creator ->popArr['scheduling_list']=$shed_obj->getSchedulingList($is_field);
												
											}else{
												$form_creator ->popArr['scheduling_list']=$shed_obj->getSchedulingList();
											}
											$form_creator ->formPath ='/templates/booking/manage_scheduling.php';
											
											break;
				case 'Scheduling_Form'		:
											$emp_obj=new Employee();
											$shed_obj=new Scheduling();
											
											$id=$postArr['id'];
											
											$is_field[0]= "a.id =$id";
											$form_creator ->popArr['id']=$id;
											$form_creator ->popArr['action']="UPDATE";
											$form_creator ->popArr['doctor']=$emp_obj->getEmployee($is_field);
											$form_creator ->popArr['scheduling_info']=$shed_obj->getDrScheduling($id);
											$form_creator ->popArr['message']=$message;
											$form_creator ->formPath ='/templates/booking/scheduling_form.php';
											
											break;
											
				/*case 'Doctors_Availability' :
												$this->getDoctorsAvailability($post);
				
												break;*/
				case 'Token_Reservation'	:
				
												$rs_obj= new ReservedTokens();
												
												$form_creator ->popArr['reserved_tokens']=$rs_obj->getReservedTokens();
												$form_creator ->formPath ='/templates/booking/token_reservation.php';
											
												break;
				
										
						
									
			
			}
			
			$form_creator->display();
	
	}
	function updateTokenReservation($post){
	
		$rs_obj= new ReservedTokens();
		$rs_obj->deleteTokens();
		
		if(!empty($post['tokens'])){
			
				for($i=0;$i<count($post['tokens']);$i++){
					$rs_obj->addTokens($post['tokens'][$i]);
				}
		}
		
		$this->viewPage('Token_Reservation',$post,'',"Updated Successfully");
	}
	function getavailReservedTokens($post){
	
		$rs_obj= new ReservedTokens();
		$bk_obj = new Booking();
		
		$docid=$post['id'];
		$date=$post['date'];
		$availTokens='';
		$j=0;
		
		$reserved_tokens=$rs_obj->getReservedTokens();
		
		if(!empty($reserved_tokens)){
			for($i=0;$i<count($reserved_tokens);$i++){
			
				$wheredata[0]="doc_id='".$docid."'";
				$wheredata[1]="booking_date='".date("Y-m-d",strtotime($date))."'";
				$wheredata[2]="token_no='".$reserved_tokens[$i]."'";
				
				$bookingInfo=$bk_obj->getBookingList($wheredata);
				if(empty($bookingInfo)){
					$availTokens[$j++]=$reserved_tokens[$i];
				}
			
			}
		
		}
		return $availTokens;
	}
	function getDoctorsAvailability($post){
	
		$shed_obj=new Scheduling();
		
		$docid=$post['id'];
		$fromdate=$post['date'];
		$i=1;
		$j=0;
		$dateInfo='';
		while($j<=17){
		
			$nextdate=date("d-m-Y",(strtotime($fromdate)+($i*24*3600)));
			$weekday = date('l', strtotime($nextdate));
			
			$arrayInfo=$shed_obj->getDrScheduling($docid,$weekday);
			
			if(!empty($arrayInfo)){
				$dateInfo[$j]=$nextdate;
				$j++;
			}
			
			$i++;
		}
		
		return $dateInfo;
	}
	function getDoctorOnDate($date = null,$dep_id = null){
	
		
		$shed_obj=new Scheduling();
		
		if(empty($date)){
		
			$date = date('Y-m-d');
		}else $date=date('Y-m-d',strtotime($date));	
		
		
		$doctors=$shed_obj->getSchedulingByDate($date,$dep_id);
		
		return $doctors;
	}
	function changeBookingStatus($post){
	
		$shed_obj=new Scheduling();
		
		$id=$postArr['id'];
		
		$result=$shed_obj->changeBookingStatus($post);
		
			$this->viewPage('Scheduling_Form',$post,'',$result);
	}
	
	function updateSchedule($postArr){
	
			$days=array("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday");
			$shed_obj=new Scheduling();
			
			$id=$postArr['id'];
			
			if(!empty($postArr['checkD'])){
			
				for($i=0;$i<count($postArr['checkD']);$i++){
					
					
					$field=strtolower(substr($postArr['checkD'][$i],0,3)); 
					$data[$postArr['checkD'][$i]]=$postArr[$field."_fs"]."/".$postArr[$field."_fe"]."/".$postArr[$field."_ss"]."/".$postArr[$field."_se"];
					
					
					
				}
				
				for($i=0;$i<count($days);$i++) {
				
						if(isset($data[$days[$i]])){
							$sheduledInfo[$i]=$data[$days[$i]];
						}else $sheduledInfo[$i]='';
				
				}
				$shedInfo=$shed_obj->getDrScheduling($id);
				if(empty($shedInfo)){
				
					$shed_obj->addSheduling($postArr,$sheduledInfo);
					
				}else{
				
					$shed_obj->updateSheduling($postArr,$sheduledInfo);
				}
				
			}
			
			$this->viewPage('Manage_Scheduling');
	}
	function booking_process($post){
	
		
		$bk_obj = new Booking();
		
		
		$docid=$post['id'];
		$date=$post['booking_date'];
		
		if(!empty($post['tokens'])){
		
			for($i=0;$i<count($post['tokens']);$i++){
				$token_no=$post['tokens'][$i];
				$post['token_from']="Reserved";
			}
		}else{
			$token_no=$this->generateTokenNo($docid,$date);
			$post['token_from']="Normal";
		}
		
		
			
		$result=$bk_obj->addBookingInfo($token_no,$post);
		
		if($result >0){
		
			$post['book_id']=$result;
			$this->viewPage('Booking_Report',$post,'',"Booked Successfully");
		}else{
			$this->viewPage('Booking_Form',$post,'',"Patient Booking Failed");
		}
	
	}
	function generateTokenNo($docid,$date){
	
		$comm_obj = new CommonFunctions();
		$bk_obj = new Booking();
		$rs_obj= new ReservedTokens();
		
		$today=$comm_obj->getcurrentDate('d-m-Y');
		
			$token_no=1;
			if($date == $today){
				$token_no=$bk_obj->getNextRegToken($docid,$date);
			}
		
			if($token_no == 1 ){
		
				$token_no=$bk_obj->getNextToken($docid,$date);
			}
			
			$check_token=$rs_obj->checktokenIsReserved($token_no);
			if($check_token == 1){
				while ($check_token == 1 ){
				
					$token_no++;
					$check_token=$rs_obj->checktokenIsReserved($token_no);
					
					
				
				}
			
			}
		return $token_no;
	}
	
	
	
}


?>