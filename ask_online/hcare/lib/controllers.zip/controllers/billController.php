﻿<?php session_start();

require_once ROOT_PATH . '/lib/common/form.php';
require_once ROOT_PATH . '/lib/common/commonFunctions.php';
require_once ROOT_PATH . '/lib/model/registration/registration.php';
require_once ROOT_PATH . '/lib/model/admin/employee.php';
require_once ROOT_PATH . '/lib/model/room/room.php';
require_once ROOT_PATH . '/lib/model/DBFunctions.php';
require_once ROOT_PATH . '/lib/model/billing/billing.php';
require_once ROOT_PATH . '/lib/model/inpatient/inpatient.php';
require_once ROOT_PATH . '/lib/model/admin/user.php';



class BillController {

	

	function viewPage($sub_module,$postArr='',$getArr='',$message=''){
	
			$form_creator = new Form();
			
			if(!empty ($message)){
				$form_creator ->popArr['message']=$message;
			}
			switch($sub_module){
				
				
				case 'Select_Bill'			:
												
												$reg_obj= new Registration();
												$emp_obj= new Employee();
												$ip_obj= new Inpatient();
												$com_obj = new CommonFunctions();
                                                    
                                                                                                
                                                                                                //set default type as OP
                                                                                                if(empty($postArr['type'])) {
                                                                                                  
                                                                                                   $postArr['type']="OP";
                                                                                                }
                                                                                                
                                                                                                $type=$postArr['type'];
                                                          
                                                                                               if($type == "OP"){
													
													if(!empty($postArr["opno"])){
														$selectCondition[]="a.`id`='".$postArr["opno"]."'";
													}else{
													if(!empty($postArr["date"])){
														$selectCondition[]="b.`visit_date`='".date("Y-m-d",strtotime($postArr["date"]))."'";
													}else $selectCondition[]="b.`visit_date`='".date("Y-m-d")."'";												
													
													}
													if(!empty($postArr["name"])){
														$selectCondition[]="a.`first_name` like '%".$postArr["name"]."%'";
													}
													if(!empty($postArr["mname"])){
														$selectCondition[]="a.`middle_name` like '%".$postArr["mname"]."%'";
													}
													if(!empty($postArr["lname"])){
														$selectCondition[]="a.`last_name` like '%".$postArr["lname"]."%'";
													}
													if(!empty($postArr["place"])){
														$selectCondition[]="a.`place`='".$postArr["place"]."'";
													}
													
													if(!empty($postArr["contact_no"])){
														$selectCondition[]="a.`contact_no`='".$postArr["contact_no"]."'";
													}
													if(!empty($postArr["doctor"])){
														$selectCondition[]="b.`doc_id`='".$postArr["doctor"]."'";
													}
													
													$form_creator ->popArr['patient_info']=$reg_obj->getOPPatientInfo('',$selectCondition,'b.visit_date','asc');
                                                                                                    }else if($type == "IP"){
                                                  
                                                  
                                                                                                          //search criterias
											            if(isset($postArr['from_date']) ){
											   
															$fromdate=$com_obj->getcurrentDate("Y-m-d",$postArr['from_date']);
															$todate=$com_obj->getcurrentDate("Y-m-d",$postArr['to_date']);
															
															
															if(!empty($postArr["ipno"])){
																$selectCondition[]="b.`id`='".$postArr["ipno"]."'";
															}
															if(!empty($postArr["first_name"])){
																$selectCondition[]="a.`first_name` like '%".$postArr["first_name"]."%'";
															}
															
															if(!empty($postArr["doctor"])){
																$selectCondition[]="b.`doc_id`='".$postArr["doctor"]."'";
															}
															if(!empty($postArr["room_no"])){
																$selectCondition[]="c.`room_number`='".$postArr["room_no"]."'";
															}
											              }else{
															$fromdate=$com_obj->getcurrentDate();
															$todate=$com_obj->getcurrentDate();
												       }
												       
												       //set search conditions
												       
												      // $selectCondition[]="b.`admission_date`>='".$fromdate."'";
												      // $selectCondition[]="b.`admission_date`<='".$todate."'";
												       $selectCondition[]="(b.`discharge_date`='0000-00-00' OR b.`discharge_date`='')";
												       $selectCondition[]="b.`cancelled`=0";
												       
												       //retrieve patient information
												            $form_creator ->popArr['patient_info']=$ip_obj->getIPPatientInfo('',$selectCondition,'b.admission_date','asc');
                                                                                                            $form_creator ->popArr['post']=$postArr;
                                                                                                    }
													
													$is_field[0]="a.title='Dr'";													
													$form_creator ->popArr['doctors']=$emp_obj->getEmployee($is_field);
													$form_creator ->formPath ='/templates/billing/selectBill.php';
													break;
					case 'Billing_Form'			:												
													$type=$postArr['type'];
													$pid=$postArr['id'];
													
													if($type == "OP") {
													
														$postArr=$this->processOP($pid);
														
														if(empty($postArr['payment_mode']) && $postArr['ins_id']>0){
															$postArr['payment_mode']="INSURANCE";
														}
														
													}
                                                                                                 //if patient type is ip
                                                                                                        if($type == "IP") {
                                                          
                                                                                                             $postArr=$this->processIP($pid);
                                                          
                                                                                                        }
												
													$postArr['type']=$type;
													$postArr['paction'] = "ADD";
													$form_creator ->popArr['post']=$postArr;
													
													$form_creator ->formPath ='/templates/billing/billing_form.php';
													break;
					case 'Manage_Billing'		:
													$bill_obj=new Billing();
													$user_obj=new User();
													$k=0;
													if(!empty($postArr['from_date'])) {
													
														$wheredata[$k++]="bill_date >='".date("Y-m-d",strtotime($postArr['from_date']))."'";
														$wheredata[$k++]="bill_date <='".date("Y-m-d",strtotime($postArr['to_date']))."'";
													}else{
														$wheredata[$k++]="bill_date >='".date("Y-m-d")."'";
														$wheredata[$k++]="bill_date <='".date("Y-m-d")."'";
													}
													if(!empty($postArr['billno'])) {
														$wheredata[$k++]="id ='".$postArr['billno']."'";
													}
													if(!empty($postArr['status'])) {
														$wheredata[$k++]="status ='".$postArr['status']."'";
													}else {
                                                                                                         $postArr['status']=0;
                                                                                                         $wheredata[$k++]="status ='0'";
                                                                                                       }
													if(!empty($postArr['type'])) {
														$wheredata[$k++]="type ='".$postArr['type']."'";
														
													}
													if(!empty($postArr['user'])) {
														$wheredata[$k++]="user_id ='".$postArr['user']."'";
														
													}
													$user_type=$_SESSION['user_type'];
													$user_type_id=$_SESSION['user_type_id'];
													$user_data=="";
													
													if($user_type !='ADMIN'){									 
													
													 
													 	if($user_type_id == 6) {
													 
													 		$user_data[0]="user_type='".$user_type_id."'"." or "."user_type='7'";
													 	}else  $user_data[0]="user_type='".$user_type_id."'";
													 
													 }
													 
													$form_creator ->popArr['post']=$postArr;
													$form_creator ->popArr['user']=$user_obj->getUser('',$user_data);;
													$form_creator ->popArr['billInfo']=$bill_obj->getBillInfo($wheredata);
													$form_creator ->formPath ='/templates/billing/manage_billing.php';
													break;
						case 'Credit_Billing'		:
													$bill_obj=new Billing();
													$user_obj=new User();
													$k=0;
													if(!empty($postArr['from_date'])) {
													
														$wheredata[$k++]="bill_date >='".date("Y-m-d",strtotime($postArr['from_date']))."'";
														$wheredata[$k++]="bill_date <='".date("Y-m-d",strtotime($postArr['to_date']))."'";
													}else{
														$wheredata[$k++]="bill_date >='".date("Y-m-d")."'";
														$wheredata[$k++]="bill_date <='".date("Y-m-d")."'";
													}
													if(!empty($postArr['billno'])) {
														$wheredata[$k++]="id ='".$postArr['billno']."'";
													}													
													if(!empty($postArr['type']) && ($postArr['type']=='DIRECT' || $postArr['type']=='IP')) {
														$wheredata[$k++]="type ='".$postArr['type']."'";
															if(!empty($postArr['ref_no'])) {
																$wheredata[$k++]="ref_no ='".$postArr['ref_no']."'";														
															}
													}
													if(!empty($postArr['type']) && $postArr['type']=='OP') {
														$wheredata[$k++]="type ='".$postArr['type']."'";
															if(!empty($postArr['ref_no'])) {
																$wheredata[$k++]="opno ='".$postArr['ref_no']."'";														
															}
													}
												
													/*if(!empty($postArr['patient_name'])) {
														$wheredata[$k++]="type ='".$postArr['type']."'";
														
													}*/
													
													
													$wheredata[$k++]="status ='0'";
													$wheredata[$k++]="credit > 0";
                                                                                                        //$wheredata[$k++]="type !='IP'";
													
													$form_creator ->popArr['post']=$postArr;
													$form_creator ->popArr['user']=$user_obj->getUser();
													$form_creator ->popArr['billInfo']=$bill_obj->getBillInfo($wheredata,'','',true);
													$form_creator ->formPath ='/templates/billing/credit_billing.php';
													break;
						case 'Print_Bill'		:
													$bill_obj=new Billing();
													
													
													if(!empty($postArr['billid'])){
														$wheredata[0]="id ='".$postArr['billid']."'";
														$wheredataitem[0]="bill_id ='".$postArr['billid']."'";
													}elseif(!empty($postArr['id'])){
														$wheredata[0]="id ='".$postArr['id']."'";
														$wheredataitem[0]="bill_id ='".$postArr['id']."'";
													}
													
													$form_creator ->popArr['billInfo']=$bill_obj->getBillInfo($wheredata);
													$form_creator ->popArr['billitemInfo']=$bill_obj->getBillItemsInfo($wheredataitem);
													$form_creator ->formPath ='/templates/billing/print_bill.php';
													break;
						case  'Print_IP_Bill'           :
						                                        $bill_obj=new Billing();
						                                        $ip_obj= new Inpatient();
						                                        
						                                        if(!empty($postArr['billid'])){
												$wheredata[0]="id ='".$postArr['billid']."'";
												$wheredataitem[0]="billno ='".$postArr['billid']."'";
											}
											$form_creator ->popArr['billInfo']=$billInfo=$bill_obj->getIPBillInfo($wheredata);
											
											
											if(!empty($billInfo)){
											$ipno=$billInfo[0][1];
											 $selectCondition[]="b.`id`='".$ipno."'";
	                                                                  
												       
	                                                                             //retrieve patient information
	                                                                          $form_creator ->popArr['patient_info'] =$ip_obj->getIPPatientInfo('',$selectCondition,'b.admission_date','asc');
	                                                                   
	                                                                              }
	                                                                              
	                                                                              $form_creator ->popArr['billitems']=$bill_obj->getIPBillItems($wheredataitem);
											$form_creator ->formPath ='/templates/billing/print_ip_bill.php';
													
						                                        
						                                        break;
						case 'Print_Advance_Bill'		:
													$bill_obj=new Billing();
													
													
													
													
													if(!empty($postArr['billid'])){
														$wheredata[0]="id ='".$postArr['billid']."'";
														
														$form_creator ->popArr['billInfo']=$bill_obj->getAdvancePayments($wheredata);
														
													}else $form_creator ->popArr['message'] ="Bill Does Not Exist!";
													
													$form_creator ->formPath ='/templates/billing/print_advance_bill.php';
													break;
													
						case 'Credit_Payment_Form'		:
																									
													$form_creator ->popArr['post']=$this->processBillNo($postArr,'credit_payment_form');
													$form_creator ->formPath ='/templates/billing/credit_payment_form.php';
													break;
						case 'Add_Credit'	:
														$bill_obj=new Billing();
														
														if(empty($postArr['new_date'])) $postArr['new_date']=date("d-m-Y");
														$postArr['bill_no']=$bill_obj->addCredit($postArr);
														$form_creator ->popArr['creditInfo']=$postArr;
														$wheredata[0]="id ='".$postArr['billid']."'";
														$form_creator ->popArr['billInfo']=$bill_obj->getBillInfo($wheredata);
														$form_creator ->formPath ='/templates/billing/print_credit_bill.php';
						                             break;
						case 'Add_Multiple_Credit'	:
														
										               $this->addMultipleCredit($postArr);
														
														
						                                                                break;
						                                                                
					      case 'IP_Search'            :                     $emp_obj= new Employee();
												$ip_obj= new Inpatient();
												$com_obj = new CommonFunctions();
					                                                          
                                                                                                          //search criterias
											            if(isset($postArr['from_date']) ){
											   
															$fromdate=$com_obj->getcurrentDate("Y-m-d",$postArr['from_date']);
															$todate=$com_obj->getcurrentDate("Y-m-d",$postArr['to_date']);
															
															
															if(!empty($postArr["ipno"])){
																$selectCondition[]="b.`id`='".$postArr["ipno"]."'";
															}
															if(!empty($postArr["first_name"])){
																$selectCondition[]="a.`first_name` like '%".$postArr["first_name"]."%'";
															}
															
															if(!empty($postArr["doctor"])){
																$selectCondition[]="b.`doc_id`='".$postArr["doctor"]."'";
															}
															if(!empty($postArr["room_no"])){
																$selectCondition[]="c.`room_number`='".$postArr["room_no"]."'";
															}
															
															$selectCondition[]="b.`admission_date`>='".$fromdate."'";
												                        $selectCondition[]="b.`admission_date`<='".$todate."'";
											              }else{

                                                                                                             $postArr['from_date']='';
                                                                                                             $postArr['to_date']='';
                                                                                                        }
												      
												       //set search conditions
												       
												       
												       $selectCondition[]="(b.`discharge_date`='0000-00-00' OR b.`discharge_date`='')";
												       $selectCondition[]="b.`cancelled`=0";
												       
												       //retrieve patient information
												            $form_creator ->popArr['patient_info']=$ip_obj->getIPPatientInfo('',$selectCondition,'b.admission_date','asc');
												            
                                                                                                            $form_creator ->popArr['post']=$postArr;
                                                                                                            
                                                                                                            $form_creator ->popArr['doctors']=$emp_obj->getEmployee($is_field);
                                                                                                            
					                                                              $form_creator ->formPath ='/templates/billing/ip_patient_list.php';
													break;
					case 'Advance_Payment_Form'     :
					                                  $ip_obj= new Inpatient();
	                                                                  
	                                                                   
					                                  //Patient Info
	                                                                   
	                                                                   $selectCondition[]="b.`id`='".$postArr["id"]."'";
	                                                                   $selectCondition[]="(b.`discharge_date`!='0000-00-00' OR b.`discharge_date`!='')";
	                                                                   $selectCondition[]="b.`cancelled`=0";
												       
	                                                                   //retrieve patient information
	                                                                   $form_creator ->popArr['patient_info']=$ip_obj->getIPPatientInfo('',$selectCondition,'b.admission_date','asc');
	                                                                   	   
					                                   $postArr=$this->calculateBill($postArr);
					                                   $form_creator ->popArr['post']=$postArr;
	                                                                   $form_creator ->formPath ='/templates/billing/advance_payment_form.php';
	                                                                   $form_creator->display();
					                                          break;
				     case 'Final_Payment_Form'     :
					                                  $ip_obj= new Inpatient();
					                                  $bill_obj= new Billing();
					                                  
					                                  
					                                  
					                                  
					                                  //check request for json
	                                                                  
	                                                                   if($postArr['paction'] == "json"){
	                                                                   
	                                                                      $this->processFinalForm($postArr);	                                                                   
	                                                                   }else{ 
	                                                                   
	                                                                   $total_amt=0;
					                                  //Patient Info
	                                                                   $postArr['dod']=date("d-m-Y");
	                                                                   $selectCondition[]="b.`id`='".$postArr["id"]."'";
	                                                                   $selectCondition[]="(b.`discharge_date`!='0000-00-00' OR b.`discharge_date`!='')";
	                                                                   $selectCondition[]="b.`cancelled`=0";
												       
	                                                                   //retrieve patient information
	                                                                   $form_creator ->popArr['patient_info']=$ip_obj->getIPPatientInfo('',$selectCondition,'b.admission_date','asc');
	                                                                   
	                                                                   
	                                                                   
	                                                                   
	                                                                   //procedure bill item details
	                                                                   
	                                                                   
	                                                                   $wheredata[0]="b.type = 'P'";	  
	                                                                   $wheredata[1]="b.category_id=1"; 
	                                                                   $wheredata[2]="a.type='IP'";
									   $wheredata[3]="a.ref_no='".$postArr['id']."'";  
	                                                                     
	                                                                   
	                                                                   $groupby="b.type,b.test_id,b.category_id";                                                            
	                                                                   $form_creator ->popArr['procedure_items']=$bill_obj->getBillItemPatient($wheredata,$groupby);
	                                                                   
	                                                                   //xray bill item details
	                                                                   
	                                                                   
	                                                                   $wheredata[0]="b.type = 'P'";	  
	                                                                   $wheredata[1]="b.category_id=2"; 
	                                                                   $wheredata[2]="a.type='IP'";
									   $wheredata[3]="a.ref_no='".$postArr['id']."'";  
	                                                                    
	                                                                     
	                                                                    $groupby="b.category_id";                                                             
	                                                                   $xray=$bill_obj->getBillItemPatient($wheredata,$groupby);
	                                                                   
	                                                                    if(!empty($xray)) $postArr['xray_charges']=$xray[0][0];
	                                                                   //lab bill item details
	                                                                   
	                                                                   
	                                                                   $wheredata[0]="b.type = 'L'"; 
	                                                                   $wheredata[1]="a.type='IP'";
									   $wheredata[2]="a.ref_no='".$postArr['id']."'";  
	                                                                   	                                                                    
	                                                                                                                               
	                                                                   $lab=$bill_obj->getBillItemPatient($wheredata);
	                                                                   
	                                                                   if(!empty($lab)) $postArr['lab']=$lab[0][0];
	                                                                   
	                                                                   	   
					                                  $postArr=$this->calculateBill($postArr);
					                                   $form_creator ->popArr['post']=$postArr;
	                                                                  $form_creator ->formPath ='/templates/billing/final_payment_form.php';
	                                                                   
	                                                                   //$form_creator->display();
	                                                                 }
					                                          break;
					  case 'Manage_IP_Payments':  $bill_obj= new Billing(); 
					                              $user_obj=new User();
					  
					  
					                               $k=0;
									if(!empty($postArr['from_date'])) {
													
										$wheredata[$k++]="bill_date >='".date("Y-m-d",strtotime($postArr['from_date']))."'";
										$wheredata[$k++]="bill_date <='".date("Y-m-d",strtotime($postArr['to_date']))."'";
									}else{
										$wheredata[$k++]="bill_date >='".date("Y-m-d")."'";
										$wheredata[$k++]="bill_date <='".date("Y-m-d")."'";
									}
									if(!empty($postArr['billno'])) {
											$wheredata[$k++]="id ='".$postArr['billno']."'";
									}
									if(!empty($postArr['ipno'])) {
											$wheredata[$k++]="ipno='".$postArr['ipno']."'";
									}
									if(!empty($postArr['user'])) {
											$wheredata[$k++]="user_id='".$postArr['user']."'";
									}
					 
					                               $form_creator ->popArr['billInfo']=$bill_obj->getIPBillInfo($wheredata);
					                               $form_creator ->popArr['user']=$user_obj->getUser();;
					                               $form_creator ->formPath ='/templates/billing/manage_ip_payment.php';
									break;
			
			}
			
			$form_creator->display();
	
	}
	function processFinalForm($post){
	
	      $total_bill=$post['actual_bill'];
	      $balance=$post['actual_balance'];
	      
	      
	      
	      for($i=0;$i<18;$i++){
	      
	       if(($i <13 || $i >15) && $i!=7 && $i!=18 && $i!=11){
	       
	          if($post['item'][$i] > 0 ){
	         
	            $total_bill +=$post['item'][$i];
	            $balance +=$post['item'][$i];
	         
	          }
	        }
	      
	      
	      
	      }
	       
	       /*if($post['admission_fee'] > 0 ){
	       
	         $total_bill +=$post['admission_fee'];
	          $balance +=$post['admission_fee'];
	       }
	       if($post['surgeon_fee'] > 0 ){
	       
	         $total_bill+= $post['surgeon_fee'];
	           $balance +=$post['admission_fee'];
	       }
	       if($post['anaesthesia_fee'] > 0 ){
	       
	         $total_bill+= $post['anaesthesia_fee'];
	           $balance +=$post['admission_fee'];
	       }
	       if($post['theatre_charges'] > 0 ){
	       
	         $total_bill+= $post['theatre_charges'];
	           $balance +=$post['admission_fee'];
	       }
	       if($post['gynaecologist_fee'] > 0 ){
	       
	         $total_bill += $post['gynaecologist_fee'];
	           $balance +=$post['admission_fee'];
	       }
	       if($post['labour_charges'] > 0 ){
	       
	         $total_bill+= $post['labour_charges'];
	           $balance +=$post['admission_fee'];
	       }
	       if($post['icu_charge'] > 0 ){
	       
	         $total_bill+= $post['icu_charge'];
	           $balance +=$post['admission_fee'];
	       }
	       if($post['medicine_charges'] > 0 ){
	       
	         $total_bill+= $post['medicine_charges'];
	           $balance +=$post['admission_fee'];
	       }
	       if($post['candd_charges'] > 0 ){
	       
	         $total_bill+= $post['candd_charges'];
	           $balance +=$post['admission_fee'];
	       }
	       if($post['suturing_charges'] > 0 ){
	       
	         $total_bill += $post['suturing_charges'];
	           $balance +=$post['admission_fee'];
	       }
	       if($post['special_cons'] > 0 ){
	       
	         $total_bill+= $post['special_cons'];
	           $balance +=$post['admission_fee'];
	       }
	       if($post['dr_charges'] > 0 ){
	       
	         $total_bill+= $post['dr_charges'];
	           $balance +=$post['admission_fee'];
	       }
	       if($post['nursing_charges'] > 0 ){
	       
	         $total_bill+= $post['nursing_charges'];
	           $balance +=$post['admission_fee'];
	       }*/
	       /*if($post['xray_charges'] > 0 ){
	       
	         $total_bill+= $post['xray_charges'];
	       }
	       if($post['lab'] > 0 ){
	       
	         $total_bill += $post['lab'];
	       }
	       if($post['room_rent'] > 0 ){
	       
	         $total_bill+= $post['room_rent'];
	       }
	       if($post['nebulization'] > 0 ){
	       
	         $total_bill+= $post['nebulization'];
	       }*/
	       /*if($post['usg'] > 0 ){
	       
	         $total_bill+= $post['usg'];
	           $balance +=$post['admission_fee'];
	       }
	       if($post['medico'] > 0 ){
	       
	         $total_bill+= $post['medico'];
	           $balance +=$post['admission_fee'];
	       }*/
	
	        $data['total_amount']=$total_bill;
	        
	        
		if(!empty($post['discount'])){
		
     			$disc_type=$post['disc_type'];
     			$discount=$post['discount'];
    
     
    			if($disc_type == "CASH"){
    			
           			$disc_amt=$discount;
           			
    			}else{
           			$disc_amt=(($total_bill*$discount)/100);
     			}
     
     			$balance=$balance-$disc_amt;
 		}
                 $data['balance']=$balance;
		
		 echo json_encode($data);
	
	}
	function calculateBill($post){
	
	
	    $bill_obj=new Billing();  
	    $db_function =new DBFunction(); 
	    $com_obj = new CommonFunctions();
            $ip_obj= new Inpatient();
	    
	     
	    $total_balance=0;
	    $total_bill=0;
	    $total_paid=0;
	    $advance_paid=0;
	    
	  
	     $ipno=$post['id'];
	     
	      //room rent calculation

             $where[]= "ipno = ".$ipno;
             $roomhist = $ip_obj->getRoomhistory('',$where);
             $room_total_rent=0;
             $cur_ad_date=='';

              if(!empty($roomhist)){

                 for($i=0;$i<count($roomhist);$i++) {
                      
                   
                    $rent=$roomhist[$i][6];

                    $sdate = new DateTime($roomhist[$i][2]);

                    $prev_date = date('Y-m-d', strtotime($roomhist[$i][3] .' -1 day'));
 
                    $edate = new DateTime($roomhist[$i][3]);
 
                    $difference = $sdate->diff($edate);
              
                    $ndays=$difference->days;

                   //if($ndays ==0) $ndays=1;
                    $room_total_rent +=($ndays* $rent);

                    if($i==(count($roomhist)-1)){

                       $cur_ad_date=$roomhist[$i][3];

                    }
                 }


             }//echo $room_total_rent;
	     
	      $room_rent=$db_function->getidToValue("room_rent","id",$ipno,"hcare_ip_info"); 
	      $admission_Date=$db_function->getidToValue("admission_date","id",$ipno,"hcare_ip_info");      
	      $curr_date=$com_obj->getcurrentDate("Y-m-d");
	      
	      //echo $ad_days=floor((strtotime($curr_date)-strtotime($admission_date))/86400);
	      
              if(!empty($cur_ad_date)){

                     $datetime1 = new DateTime($cur_ad_date);
              }else {
	              $datetime1 = new DateTime($admission_Date);
              }
 
              $datetime2 = new DateTime($curr_date);
 
              $difference = $datetime1->diff($datetime2);
              
              $ad_days=$difference->days+1;

             if($ad_days ==0) $ad_days=1;
              
              $room_total_rent+=$room_rent*$ad_days;

            
              
              $total_bill +=$room_total_rent;
            $total_balance +=$room_total_rent;
	    
	    //bill calcultation
	    $wheredata[]="status ='0'";
	    $wheredata[]="type = 'IP'";
	    $wheredata[]="ref_no = '".$ipno."'";
	    
	    $billInfo=$bill_obj->getBillInfo($wheredata);
	    
	   
	   
	    
	   if(!empty($billInfo)){
	    
	         for($i=0;$i<count($billInfo);$i++){
	         
	         //total bill
	         
	             $total_bill+=$billInfo[$i][11];
	             
	         //total paid amount
	          $total_paid+=$billInfo[$i][13]+$billInfo[$i][15];
	             
	         
	            $balanceAmt=$billInfo[$i][14];
	            
	            if($balanceAmt>0){
	            
	              $total_balance=$total_balance+$balanceAmt;
	            }
	         
	         
	         }
	    }
           //procedure bill from nurse entry
            $procondn[0]="status = 0";
            $procondn[1]="ipno = '".$ipno."'";
            $ipProcedure=$ip_obj->getIPProcedure('',$procondn,'date','asc');

            $procedureAmt=0;
           if(!empty($ipProcedure)){
	    
	         for($i=0;$i<count($ipProcedure);$i++){
                      
                   $procedureAmt += $ipProcedure[$i][3];
                 }
           }

           $total_bill += $procedureAmt;

           //doctor visit bill from nurse entry
            $docondn[0]="status = 0";
            $docondn[1]="ipno = '".$ipno."'";
            $doctorVisit=$ip_obj->getDoctorVisit('',$docondn,'date','asc');

            $doc_visit_amt=0;
           if(!empty($doctorVisit)){
	    
	         for($i=0;$i<count($doctorVisit);$i++){
                      
                   $doc_visit_amt += $doctorVisit[$i][3];
                 }
           }

           $total_bill += $doc_visit_amt;

	   //pharmacy credits

              $total_pharma_bill=0;
              $total_phamt_paid=0;

             $phwhere[]="cust_type = 'IP'";        
              $phwhere[]="ip_no = '".$ipno."'";  
             $phwhere[]="status = '0'";
	    $pharmaInfo=$bill_obj->getpharmaBill($phwhere);

             if(!empty($pharmaInfo)){
	    
	         for($i=0;$i<count($pharmaInfo);$i++){

                   //total bill
	         
	             $total_pharma_bill+=$pharmaInfo[$i][2];
	             
	         //total paid amount
	          $total_phamt_paid+=$pharmaInfo[$i][10];
	             
	         
	            $phbalanceAmt=$pharmaInfo[$i][11];
	            
	            if($phbalanceAmt>0){
	            
	              $total_balance=$total_balance+$phbalanceAmt;
	            }

                 }
             }
            $total_bill+= $total_pharma_bill;
             $total_paid+=$total_phamt_paid;

	    //advance calculation
	     
	    $where[]="ipno='".$ipno."'";
	    $advaneInfo=$bill_obj->getAdvancePayments($where);
	    
	     if(!empty($advaneInfo)){
	    
	         for($i=0;$i<count($advaneInfo);$i++){
	         
	             $advance_paid+=$advaneInfo[$i][3]+$advaneInfo[$i][4];
	         }
	     }
	     
	     $total_paid+=$advance_paid;
	     $total_balance -=$advance_paid;
	     
	    
	    
	    $post['room_rent']=$room_total_rent;
	     $post['advance_paid']=$advance_paid;
             $post['medicine_charges']=$total_pharma_bill;
	     $post['balance']=$total_balance;
	     $post['paid_amount']=$total_paid;
	    
	    $post['total_bill_amount']=$total_bill;
            $post['nurse_added_procedures']=$procedureAmt;
            $post['doc_visit_amt']=$doc_visit_amt;
	    
	    return $post;
	
	}
	function addMultipleCredit($postArr){
	
		$bill_obj=new Billing();
		if(!empty($postArr['paybill'])){
														
				for($i=0;$i<count($postArr['paybill']);$i++)
				{
						$arrayInfo=explode('#',$postArr['paybill'][$i]);
						$billInfo['billid']=$arrayInfo[0];
						$billInfo['amount_paid']=$postArr['amount'][$i];
						$billInfo['new_date']=date("Y-m-d");
						$postArr['bill_no']=$bill_obj->addCredit($billInfo);
				}
		}
		$message="Payment Added Successfully!";
		$this->viewPage('Credit_Billing',$postArr,'',$message);
	}
	function processBillNo($post,$action = null){
	
		$bill_obj=new Billing();
		$form_creator = new Form();
		$db_function =new DBFunction();
		
		$billid=$post['id'];
		
		$wheredata[0]="id ='".$billid."'";
		$billInfo=$bill_obj->getBillInfo($wheredata);
		
		if(!empty($billInfo)){
		
			$post['billid']=$billid;
			$post['type']=$billInfo[0][1];
			$post['id']=$billInfo[0][2];
			$post['name']=$billInfo[0][3];
			$post['age']=$billInfo[0][4];
			$post['gender']=$billInfo[0][5];
			$post['place']=$billInfo[0][6];
			$post['contact_no']=$billInfo[0][7];
			
			if($billInfo[0][1] == "OP"){
				$post['doctor']=$billInfo[0][8];
				$post['ins_id']=$db_function->getidToValue("insurance_company","id",$billInfo[0][2],"hcare_op_visit_info");;
			}else{
				$post['refferal_info']=$billInfo[0][8];
			}
			$post['date']=$billInfo[0][16];
			
			$post['total_amount']=$billInfo[0][9];
			$post['dr_disc']=$billInfo[0][10];
			$post['net_amount']=$billInfo[0][11];
			$post['payment_mode']=$billInfo[0][12];
			$post['amount_paid']=$billInfo[0][13];
			$post['card_amount']=$billInfo[0][15];
			$post['ins_deduction']=$billInfo[0][20];
			$post['remarks']=$billInfo[0][17];
			$post['paction']="UPDATE";
			
			$wheredata[0]="bill_id ='".$billid."'";
			
			$billItemInfo=$bill_obj->getBillItemsInfo($wheredata);
			
			if(!empty($billItemInfo)){
			
				for($i=0;$i<count($billItemInfo);$i++) {
				
				{
					$post["items_in_array"][]=$billItemInfo[$i][4]."!$%".$billItemInfo[$i][5]."!$%".$billItemInfo[$i][7]."!$%".$billItemInfo[$i][8]."!$%".$billItemInfo[$i][9]."!$%".$billItemInfo[$i][11]."!$%".$billItemInfo[$i][3]."!$%".$billItemInfo[$i][6];
				}
			}
			
			
			
			if(!empty($action) && $action='credit_payment_form'){
			$post['balance']=$billInfo[0][14];
			return $post;
			}else{
			$form_creator ->popArr['post']=$post;
			 $form_creator ->formPath ='/templates/billing/billing_form.php';
			}
			$form_creator ->formPath ;
			$form_creator->display();
													
		}
	}
	}
    function processIP($ipno){
    
                  $postArr['id']=$ipno;
                  
                  $postArr['name']="Soni";
				$postArr['place']="Soni";
				$postArr['age']=29;
				$postArr['gender']="F";
				$postArr['contact_no']="";
				$postArr['doctor']="Dr.VVV";
                
                return $postArr;
    }
	function processOP($opid){
	
		$reg_obj= new Registration();
		$db_function =new DBFunction();
		
		$total_amount=0;
		$net_amount=0;
		$dr_disc=0;
	
		$selectCondition[0]="b.`id`='".$opid."'";
		$patientInfo=$reg_obj->getOPPatientInfo('',$selectCondition,'b.id','desc');;
													
				$postArr['name']=$patientInfo[0][1]." ".$patientInfo[0][2]." ".$patientInfo[0][3];
				$postArr['place']=$patientInfo[0][8];
				$postArr['age']=$patientInfo[0][4];
				$postArr['gender']=$patientInfo[0][6];
				$postArr['contact_no']=$patientInfo[0][10];
				$postArr['doctor']="Dr.".$patientInfo[0][15]." ".$patientInfo[0][16];
				
				$postArr['ins_id']=$insurance_company=$patientInfo[0][22];
														
					if($patientInfo[0][40] == 0){
														
						$consultaion=$patientInfo[0][17]+$patientInfo[0][18];
						$net_consultaion=$consultaion-$patientInfo[0][31];
															
							if($consultaion > 0 ) {
															
								//$discountInfo=$this->calculateInsuranceDiscount($opid,"C",$patientInfo[0][17]);						
																
																
								$postArr["items_in_array"][]="0"."!$%"."Consultation"."!$%".$consultaion."!$%"."CASH"."!$%".$patientInfo[0][31]."!$%".$net_consultaion."!$%"."C"."!$%"."0"."!$%"."0";
							}
															
									$total_amount=$total_amount+$net_consultaion;
									
					}
			$drpageInfo=$db_function->getDoctorPrescribedTest($opid);
			
			if(!empty($drpageInfo)){
			
				$dr_disc=$drpageInfo['disc_per'];
				
				if(!empty($drpageInfo['generaltest'])){					
				
					$generaltest=explode(",",$drpageInfo['generaltest']);
					for($i=0;$i<count($generaltest);$i++){
						if(!empty($generaltest[$i])){
						
							$t_name=$generaltest[$i];
							$test_id=$db_function->getidToValue("id","procedure_test",$t_name,"hcare_procedure");
							$amount=$db_function->getidToValue("amount","id",$test_id,"hcare_procedure");
							$cid=$db_function->getidToValue("category_id","id",$test_id,"hcare_procedure");
							
								//if($insurance_company > 0 ) {
								
									$discountInfo=$this->calculateInsuranceDiscount($opid,"P",$amount);
									$final_amount=$discountInfo[0];
									$discount_type=$discountInfo[1];
									$discount_value=$discountInfo[2];
								//}
							
							$total_amount=$total_amount+$final_amount;
							
							$postArr["items_in_array"][]=$test_id."!$%".$t_name."!$%".$amount."!$%".$discount_type."!$%".$discount_value."!$%".$final_amount."!$%"."L"."!$%".$cid."!$%"."0";
						}
					}
				
				}
				if(!empty($drpageInfo['labtest'])){	
				
					$labtestpre=explode(",",$drpageInfo['labtest']);
					
					for($i=0;$i<count($labtestpre);$i++){
					
						$discount_type='';
						$discount_value=0;
					
						if(!empty($labtestpre[$i])){
						
							$labtest=$labtestpre[$i];
							
							if($db_function->isValidCatagory($labtest))
							{
							
								$tid=$db_function->getidToValue("id","test_name",$labtest,"hcare_lab_element");
								$cid=$db_function->getidToValue("category","id",$tid,"hcare_lab_element");
								//$status=$db_functions->checktestBilled($opid,$testid,"element")
								
								
								$amount=$db_function->getidToValue("Price","id",$tid,"hcare_lab_element");
								
								//if($insurance_company > 0 ) {
								
									$discountInfo=$this->calculateInsuranceDiscount($opid,"L",$amount);
									$final_amount=$discountInfo[0];
									$discount_type=$discountInfo[1];
									$discount_value=$discountInfo[2];
								//}
							
							}else if($db_function->isValidTest($labtest)){
							
								$tid=$db_function->getidToValue("id","testName",$labtest,"hcare_lab_test");
								$cid=$db_function->getidToValue("catId","id",$tid,"hcare_lab_test");
								//$status=$db_functions->checktestBilled($opid,$testid,"element")
								$amount=$db_function->getidToValue("Price","id",$tid,"hcare_lab_test");
								
								//if($cid!=0) {
								$test_type=1;
								//}
								
								//if($insurance_company > 0 ) {
								
									$discountInfo=$this->calculateInsuranceDiscount($opid,"L",$amount);
									$final_amount=$discountInfo[0];
									$discount_type=$discountInfo[1];
									$discount_value=$discountInfo[2];
								//}
							
							}
							
							$total_amount=$total_amount+$final_amount;
							
							$postArr["items_in_array"][]=$tid."!$%".$labtest."!$%".$amount."!$%".$discount_type."!$%".$discount_value."!$%".$final_amount."!$%"."L"."!$%".$cid."!$%".$test_type;
						}
					}
				
				
				
				}
			}
			$postArr['id']=$opid;
			$postArr['total_amount']=$total_amount;
			$postArr['dr_disc']=$dr_disc;
			$postArr['net_amount']= $total_amount-($total_amount*($dr_disc/100));
			
			return $postArr;
	
	}
	
	function process_select_bill($post){
	
			$form_creator = new Form();
			
			$form_creator ->popArr['post']=$post;
			$form_creator ->formPath ='/templates/billing/selectBill.php';
			$form_creator->display();
	}
	function calculateInsuranceDiscount($opid,$type,$amount){
	
		$db_function =new DBFunction();
		
		$discount_type='';
		$discount_value=0;
		$final_amount=$amount;
		
		$ins_id=$db_function->getidToValue("insurance_company","id",$opid,"hcare_op_visit_info");
		
		if($ins_id >0 && !empty($opid)){
				
				if($type == "C") {
				
					$discount_type=$db_function->getidToValue("cons_disc_type","ins_id",$ins_id,"hcare_insurance_discount_info");
					$discount_value=$db_function->getidToValue("cons_disc_value","ins_id",$ins_id,"hcare_insurance_discount_info");
					
				}else if($type == "L"){
				
					$discount_type=$db_function->getidToValue("lab_disc_type","ins_id",$ins_id,"hcare_insurance_discount_info");
					$discount_value=$db_function->getidToValue("lab_disc_value","ins_id",$ins_id,"hcare_insurance_discount_info");
				}else{
					$discount_type=$db_function->getidToValue("test_disc_type","ins_id",$ins_id,"hcare_insurance_discount_info");
					$discount_value=$db_function->getidToValue("test_disc_value","ins_id",$ins_id,"hcare_insurance_discount_info");
				}
				
					
				if((!empty($discount_type)) && $discount_value >0) {
					
						if($lab_disc_type == "CASH"){
						
							$final_amount=$amount-$discount_value;
						}else {
							$final_amount=$amount-($amount*($discount_value/100));
						}
				}
		}
		
		return array($final_amount,$discount_type,$discount_value);
	
	}
	
	function process_bill_form($post,$get){
	
		$db_function =new DBFunction();
		$form_creator = new Form();
		
		$total_amount=0;
		$net_amount=0;
		
		$opid=$post["id"];
		$post['ins_id']=$ins_id=$db_function->getidToValue("insurance_company","id",$opid,"hcare_op_visit_info");	
		$items=$post['items'];		
		
		if(count($items) > 0){
		
			unset($post['items']);
			$j=0;
			$rm=1;
			for($i=0;$i<count($items);$i++){
			
				$rm=1;
				if($get['action'] == "RM"){
		
		 			$loc=$get['loc'];
					
					if($i==$loc) $rm=0;
		 
		 		}
				if($get['action'] == "INS"){
		
		 			$loc=$get['loc'];
					
					if($i==$loc) {
					
						if($items[$i][9] == "CASH") $items[$i][9]="INSURANCE";
						else $items[$i][9]="CASH";
					}
		 
		 		}
				//Calculate discount
				if(!empty($items[$i][3]) && !empty($items[$i][4])){
				
					if($items[$i][3] == 'CASH'){
						$items[$i][5]=$items[$i][2]-$items[$i][4];
					}else if($items[$i][3] == '%'){
						$items[$i][5]=$items[$i][2]-($items[$i][2]*($items[$i][4]/100));
					}
					
				}
				if($rm!=0) {				
					
					//For Mode Insurance
					
					
						$post["items_in_array"][$j++]=$items[$i][0]."!$%".$items[$i][1]."!$%".$items[$i][2]."!$%".$items[$i][3]."!$%".$items[$i][4]."!$%".$items[$i][5]."!$%".$items[$i][6]."!$%".$items[$i][7]."!$%".$items[$i][8];
						
				
					$total_amount=$total_amount+$items[$i][5];
					
				
			}	
			
		}	
	}
		
		if(!empty($post['particulars'])){
		
			
			$pInfo=explode(" -",$post['particulars_ID']);
			$particular=$post['particulars'];
			
			$ptype=$pInfo[0];
			$pid=$pInfo[1];
			$test_type=0;
			
			if($pid > 0) {
			
				if($ptype == "L"){
			
				
					if($db_function->isValidCatagory($particular)){
				
						$amount=$db_function->getidToValue("Price","id",$pid,"hcare_lab_element");
						$cid=$db_function->getidToValue("category","id",$pid,"hcare_lab_element");
				
					}else if($db_function->isValidTest($particular)){
						$amount=$db_function->getidToValue("Price","id",$pid,"hcare_lab_test");
						$cid=$db_function->getidToValue("catId","id",$pid,"hcare_lab_test");
						//if($cid!=0) {
								$test_type=1;
						//}
					}else {
				
						$amount=0;
						$cid=0;
					}			
					
						
					$discountInfo=$this->calculateInsuranceDiscount($opid,"L",$amount);	
				
					$discount_type=$discountInfo[1];
					$discount_value=$discountInfo[2];
					$final_amount=$discountInfo[0];
				
				}else if($ptype == "P"){
			
			
					$amount=$db_function->getidToValue("amount","id",$pid,"hcare_procedure");
					$cid=$db_function->getidToValue("category_id","id",$pid,"hcare_procedure");
					$discountInfo=$this->calculateInsuranceDiscount($opid,"P",$amount);	
				
					$discount_type=$discountInfo[1];
					$discount_value=$discountInfo[2];
					$final_amount=$discountInfo[0];
				}
			
		
			
			
				$total_amount=$total_amount+$final_amount;
			
			
				
			
					$post["items_in_array"][]=$pid."!$%".$particular."!$%".$amount."!$%".$discount_type."!$%".$discount_value."!$%".$final_amount."!$%".$ptype."!$%".$cid."!$%".$test_type;
				
			}else $form_creator ->popArr['message']="Invalid Item Selected";
		}
		
		$net_amount= $total_amount-($total_amount*($post['dr_disc']/100));
		
		$post['total_amount']=$total_amount;
		$post['net_amount']=$net_amount;
		$form_creator ->popArr['post']=$post;												
		$form_creator ->formPath ='/templates/billing/billing_form.php';
		$form_creator->display();
	
	}
	
	function process_billing($post){
	
		$bill_obj=new Billing();
		$db_function =new DBFunction();
		$reg_obj= new Registration();
		
		$items=$post['items'];
					
		if(count($items) > 0){
		
			if($post['paction'] == "ADD"){
			
				if($post['type'] == "DIRECT"){
			
					$post['id']=$bill_obj->addCustomer($post);
					$post['opno']=0;
				}else if($post['type'] == "OP"){				
				
				$post['opno']=$db_function->getidToValue("opno","id",$post['id'],"hcare_op_visit_info");				
				}else{
				  $post['opno']=$db_function->getidToValue("opno","id",$post['id'],"hcare_ip_info");
				}
		
				$post['billid']=$bill_id=$bill_obj->addToBill($post);
				
		
				if($bill_id >0 ) {		
		
					for($i=0;$i<count($items);$i++){
				
						if($items[$i][6] == "C" && $post['type'] == "OP"){
						
							$reg_obj->updatePaidStatus($post['id'],1);
						}
						$id=$bill_obj->addToBillItems($bill_id,$items[$i],$post);
					}
				}
			}else{
			
				$bill_id=$post['billid'];
				
				if($post['type'] == "DIRECT"){
			
					$post['id']=$db_function->getidToValue("ref_no","id",$bill_id,"hcare_bill");
					$bill_obj->updateCustomer($post);
				}
				
				$bill_obj->updateBill($post);
				$bill_obj->deleteBillItems($post);
				
				for($i=0;$i<count($items);$i++){
				
					
						$id=$bill_obj->addToBillItems($bill_id,$items[$i],$post);
				}
			
			}
		}
		
		$this->viewPage('Print_Bill',$post,'',$result);
	
	}
	
	function deleteBill($post){
	
		$bill_obj=new Billing();
		$reg_obj= new Registration();
		$db_function =new DBFunction();
		
		$bill_obj->cancelBill($post);
		
		$opid=$db_function->getidToValue("ref_no","id",$post['id'],"hcare_bill");
		$reg_obj->updatePaidStatus($opid,0);
		$bill_obj->cancelBillItems($post);
		
		$this->viewPage('Manage_Billing',$post,'',$result);
	}
	
	function add_advance_payment($post){
	
	      $bill_obj=new Billing();
	      $com_obj = new CommonFunctions();
	      
	      
	      
	      $post['curr_date_time']=$com_obj->getcurrentDate("Y-m-d h:i A");
	      $post['billid']=$bill_id=$bill_obj->add_advance_payment($post);
	      
	      $this->viewPage('Print_Advance_Bill',$post);
	}
	
	function add_final_payment($post){
	
	  $bill_obj=new Billing();
	   $com_obj = new CommonFunctions();
	   $room_obj=new Room();
	   $ip_obj=new Inpatient;
	   $db_function =new DBFunction();
	   
	   
	   $post['curr_date']=$com_obj->getcurrentDate("Y-m-d");
	    $post['curr_time']=$com_obj->getcurrentDate("h:i A");
	    
	    $post['billid']=$bill_obj->add_ip_bill($post);
	    
	    
	    $items=$post['item'];
	    $particulars=$post['particulars'];
	    
	   
	    for($i=0;$i<count($items);$i++){
	    
	      if($items[$i] > 0 ) {
	         $result= $bill_obj->add_ip_bill_items($post['billid'],$items[$i],$particulars[$i]);
	       }
	    }
	    
	   // add discharge date
	   
	   $ip_obj->add_discharge_date($post);
	
	   //change room status
	  
	    $bed_id=$db_function->getidToValue("bed_id","id",$post['id'],"hcare_ip_info");
	    $room_obj->updateBedStatus("FREE",$bed_id);
	    
	    $this->viewPage('Print_IP_Bill',$post,'',$result);
	}
	
	
	
	
	
}


?>
