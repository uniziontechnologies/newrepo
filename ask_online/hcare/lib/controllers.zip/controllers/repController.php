<?php session_start();

require_once ROOT_PATH . '/lib/common/form.php';
require_once ROOT_PATH . '/lib/common/commonFunctions.php';
require_once ROOT_PATH . '/lib/model/registration/registration.php';
require_once ROOT_PATH . '/lib/model/admin/employee.php';
require_once ROOT_PATH . '/lib/model/DBFunctions.php';
require_once ROOT_PATH . '/lib/model/billing/billing.php';
require_once ROOT_PATH . '/lib/model/admin/user.php';
require_once ROOT_PATH . '/lib/model/report/report.php';
require_once ROOT_PATH . '/lib/model/procedure/category.php';
require_once ROOT_PATH . '/lib/model/procedure/procedure.php';



class ReportController {

	

	function viewPage($sub_module,$postArr='',$getArr='',$message=''){
	
			$form_creator = new Form();
			
			if(!empty ($message)){
				$form_creator ->popArr['message']=$message;
			}
			switch($sub_module){
				
				
				case 'index'			:
													
													$form_creator ->formPath ='/templates/reports/index.php';
													break;
				case 'daily_collection'  : 
											$rep_obj=new Report();
											$com_obj = new CommonFunctions();
											
											
											if(isset($postArr['from_date'])){
											
													$fromdate=$com_obj->getcurrentDate("Y-m-d",$postArr['from_date']);
													$todate=$com_obj->getcurrentDate("Y-m-d",$postArr['to_date']);
											}else{
													$fromdate=$com_obj->getcurrentDate("Y-m-d");
													$todate=$com_obj->getcurrentDate("Y-m-d");
											}
											
											$form_creator ->popArr['post']=$postArr;
											$form_creator ->popArr['daily_collection']=$rep_obj->daily_collection($fromdate,$todate);;
				                            $form_creator ->formPath ='/templates/reports/daily_collection.php';
											break;
					case 'bill_collection'  : 
											$rep_obj=new Report();
											$com_obj = new CommonFunctions();
											$user_obj=new User();
											
											
											if(isset($postArr['from_date'])){
											
													$fromdate=$com_obj->getcurrentDate("Y-m-d",$postArr['from_date']);
													$todate=$com_obj->getcurrentDate("Y-m-d",$postArr['to_date']);
											}else{
													$fromdate=$com_obj->getcurrentDate("Y-m-d");
													$todate=$com_obj->getcurrentDate("Y-m-d");
											}
											
											//Extract by user id and user type
											
											$user_type_logged_in=$_SESSION['user_type'];
											$user_type_id=$_SESSION['user_type_id'];
											$user_data=="";
											$user_type="";
											$user_id="";
											
											if(!empty($postArr['user_type'])) {
														
												$user_data[]="user_type='".$postArr['user_type']."'";
												
												if(empty($postArr['user'])) {
														
													$userInfo=$user_obj->getUser('',$user_data);
													
													for($i=0;$i<count($userInfo);$i++){
														
														if($i == 0 ){
															$user_id .="(";
														}
														//echo (count($userInfo));
														if($i == ((count($userInfo))-1)){
														
															$user_id .=$userInfo[$i][0].")";
														}else{
															$user_id .=$userInfo[$i][0].",";
														}
													}
												
														
												}

														
											}		
											if(!empty($postArr['user'])) {
														
												$user_id="($postArr[user])";
												
														
											}
											
											$user_type_info='';
													
											if($user_type_logged_in !='ADMIN' ){
											$user_type_info[]="id='".$user_type_id."'"; 
												
												if(empty($postArr['user_type'])){
												
													$postArr['user_type']=$user_type_id;
													
													
													//$user_type[]="id='".$user_type_id."'";
												}
												if(empty($postArr['user'])){
													
													$user_id="($_SESSION[user_id])";
													$user_data[]="user_type='".$user_type_id."'";
													$postArr['user']=$_SESSION['user_id'];
													
												}
											}
													
											$form_creator ->popArr['post']=$postArr;
											$form_creator ->popArr['user_type']=$user_obj->getUsertype($user_type_info);
											$form_creator ->popArr['user']=$user_obj->getUser('',$user_data);
											$form_creator ->popArr['daily_collection']=$rep_obj->daily_bill_collection($fromdate,$todate,$user_id);
											$form_creator ->formPath ='/templates/reports/bill_collection.php';
											break;
					case 'patient_report' :	$com_obj = new CommonFunctions();
														$reg_obj= new Registration();
														$emp_obj= new Employee();
														
														if(isset($postArr['from_date']) && $postArr['action']!="CLEAR"){
															$fromdate=$com_obj->getcurrentDate("Y-m-d",$postArr['from_date']);
															$todate=$com_obj->getcurrentDate("Y-m-d",$postArr['to_date']);
															
															if(!empty($postArr["opno"])){
																$selectCondition[]="a.`id`='".$postArr["opno"]."'";
															}
															if(!empty($postArr["first_name"])){
																$selectCondition[]="a.`first_name` like '%".$postArr["first_name"]."%'";
															}
															if(!empty($postArr["place"])){
																$selectCondition[]="a.`place`='".$postArr["place"]."'";
															}
															if(!empty($postArr["doctor"])){
																$selectCondition[]="b.`doc_id`='".$postArr["doctor"]."'";
															}
														}else{
															$postArr['from_date']=$fromdate=$com_obj->getcurrentDate();
															$postArr['to_date']=$todate=$com_obj->getcurrentDate();
														}
														
														$selectCondition[]="b.`visit_date`>='".$fromdate."'";
														$selectCondition[]="b.`visit_date`<='".$todate."'";
														$selectCondition[]="b.`cancelled`=0";
														
														$form_creator ->popArr['patient_info']=$reg_obj->getOPPatientInfo('',$selectCondition,'b.visit_date','asc');
														
														 if($postArr['action']!="CLEAR"){
															$form_creator ->popArr['post']=$postArr;
														}else $form_creator ->popArr['post']='';
														
														$is_field[0]="a.title='Dr'";													
														$form_creator ->popArr['doctors']=$emp_obj->getEmployee($is_field);
														
														$form_creator ->formPath ='/templates/reports/patient_report.php';
														break;
					case 'age_gender_report' :			$com_obj = new CommonFunctions();
														$reg_obj= new Registration();
														$emp_obj= new Employee();
														
														if(isset($postArr['from_date']) && $postArr['action']!="CLEAR"){
															$fromdate=$com_obj->getcurrentDate("Y-m-d",$postArr['from_date']);
															$todate=$com_obj->getcurrentDate("Y-m-d",$postArr['to_date']);
															
															
															if(!empty($postArr["age_from"])){
																$selectCondition[]="a.`age`>=".$postArr["age_from"]."";
															}
															if(!empty($postArr["age_to"])){
																$selectCondition[]="a.`age`<=".$postArr["age_to"]."";
															}
															
															if(!empty($postArr["age_from"]) || !empty($postArr["age_to"])){
															
															
															$selectCondition[]="(a.`age` like '%".$postArr["age_type"]."')";
																
															
															}
															if(!empty($postArr["gender"])){
																$selectCondition[]="a.`gender` = '".$postArr["gender"]."'";
															}
															
														}else{
															$postArr['from_date']=$fromdate=$com_obj->getcurrentDate();
															$postArr['to_date']=$todate=$com_obj->getcurrentDate();
														}
														
														$selectCondition[]="b.`visit_date`>='".$fromdate."'";
														$selectCondition[]="b.`visit_date`<='".$todate."'";
														$selectCondition[]="b.`cancelled`=0";
														
														$form_creator ->popArr['patient_info']=$reg_obj->getOPPatientInfo('',$selectCondition,'b.visit_date','asc');
														
														 if($postArr['action']!="CLEAR"){
															$form_creator ->popArr['post']=$postArr;
														}else $form_creator ->popArr['post']='';
														
														
														
														$form_creator ->formPath ='/templates/reports/age_gender_report.php';
														break;
					case 'cancelled_op' :	$com_obj = new CommonFunctions();
														$reg_obj= new Registration();
														$emp_obj= new Employee();
														
														if(isset($postArr['from_date']) && $postArr['action']!="CLEAR"){
															$fromdate=$com_obj->getcurrentDate("Y-m-d",$postArr['from_date']);
															$todate=$com_obj->getcurrentDate("Y-m-d",$postArr['to_date']);
															
															if(!empty($postArr["opno"])){
																$selectCondition[]="a.`id`='".$postArr["opno"]."'";
															}
															if(!empty($postArr["first_name"])){
																$selectCondition[]="a.`first_name` like '%".$postArr["first_name"]."%'";
															}
															if(!empty($postArr["place"])){
																$selectCondition[]="a.`place`='".$postArr["place"]."'";
															}
															if(!empty($postArr["doctor"])){
																$selectCondition[]="b.`doc_id`='".$postArr["doctor"]."'";
															}
														}else{
															$postArr['from_date']=$fromdate=$com_obj->getcurrentDate();
															$postArr['to_date']=$todate=$com_obj->getcurrentDate();
														}
														
														$selectCondition[]="b.`visit_date`>='".$fromdate."'";
														$selectCondition[]="b.`visit_date`<='".$todate."'";
														$selectCondition[]="b.`cancelled`=1";
														
														$form_creator ->popArr['patient_info']=$reg_obj->getOPPatientInfo('',$selectCondition,'b.visit_date','asc');
														
														 if($postArr['action']!="CLEAR"){
															$form_creator ->popArr['post']=$postArr;
														}else $form_creator ->popArr['post']='';
														
														$is_field[0]="a.title='Dr'";													
														$form_creator ->popArr['doctors']=$emp_obj->getEmployee($is_field);
														
														$form_creator ->formPath ='/templates/reports/cancelled_op_report.php';
														break;
				
				
					case 'doctor_report'  :
												 $rep_obj=new Report();
												 $reg_obj= new Registration();
												 $com_obj = new CommonFunctions();
												 $emp_obj= new Employee();
												 
												 if(isset($postArr['from_date'])){
											
													$fromdate=$com_obj->getcurrentDate("Y-m-d",$postArr['from_date']);
													$todate=$com_obj->getcurrentDate("Y-m-d",$postArr['to_date']);
												}else{
													$fromdate=$com_obj->getcurrentDate("Y-m-d");
													$todate=$com_obj->getcurrentDate("Y-m-d");
												}
												
												$selectCondition[]="b.`visit_date`>='".$fromdate."'";
												$selectCondition[]="b.`visit_date`<='".$todate."'";
												
												if(!empty($getArr['docid'])){
												$postArr['doctor']=$docid=$getArr['docid'];
												 $selectCondition[]="b.`doc_id`='".$docid."'";
												}
												if(!empty($postArr['doctor'])){
												$docid=$postArr['doctor'];
												 $selectCondition[]="b.`doc_id`='".$docid."'";
												}
												$selectCondition[]="b.`cancelled`=0";
												 $is_field[0]="a.title='Dr'";	
												 $form_creator ->popArr['doctors']=$emp_obj->getEmployee($is_field);
												$form_creator ->popArr['patient_info']=$reg_obj->getOPPatientInfo('',$selectCondition,'b.visit_date','asc');
												$form_creator ->popArr['post']=$postArr;											
				                            $form_creator ->formPath ='/templates/reports/doctor_report.php';
											break;
					case 'doctor_consolidated':
					
					                           $emp_obj= new Employee();
											   $com_obj = new CommonFunctions();
											   $rep_obj=new Report();
											   
											   if(isset($postArr['from_date'])){
											
													$fromdate=$com_obj->getcurrentDate("Y-m-d",$postArr['from_date']);
													$todate=$com_obj->getcurrentDate("Y-m-d",$postArr['to_date']);
												}else{
													$fromdate=$com_obj->getcurrentDate("Y-m-d");
													$todate=$com_obj->getcurrentDate("Y-m-d");
												}
											   
											   $is_field[0]="a.title='Dr'";		
											   
											   if(!empty($postArr["doctor"])){
														$is_field[1]="a.`id`='".$postArr["doctor"]."'";
												}											
												$doctors=$emp_obj->getEmployee($is_field);
												$arrList='';
												$j=0;
												if(count($doctors) >0 ){
												
												  for($i=0;$i<count($doctors);$i++){
												  
												    $docid=$doctors[$i][0];
													$patientInfo=$rep_obj->patient_count($docid,$fromdate,$todate);
												
													if($patientInfo[0] >0 || $patientInfo[1] >0 || $patientInfo[2]>0 || $patientInfo[3] >0 || $patientInfo[4] >0) {
													
															$arrList[$j][0]=$doctors[$i][1].".".$doctors[$i][2]." ".$doctors[$i][3];
															$arrList[$j][1]=$patientInfo[0];
															$arrList[$j][2]=$patientInfo[1];
															$arrList[$j][3]=$patientInfo[2];
															$arrList[$j][4]=$patientInfo[3];
															$arrList[$j][5]=$docid;
															$arrList[$j][6]=$patientInfo[4];
															$j++;
													}
													
												  }
												
												}
												$form_creator ->popArr['post']=$postArr;
												
												$is_field[0]="a.title='Dr'";													
												$form_creator ->popArr['doctors']=$emp_obj->getEmployee($is_field);
														
												$form_creator ->popArr['doctor_info']=$arrList;
				                            	$form_creator ->formPath ='/templates/reports/doctor_consolidate.php';
													break;
							case 'credit_payment' :
											                $bill_obj=new Billing();
													$user_obj=new User();
													$k=0;
													if(!empty($postArr['from_date'])) {
													
														$wheredata[$k++]="b.bill_date >='".date("Y-m-d",strtotime($postArr['from_date']))."'";
														$wheredata[$k++]="b.bill_date <='".date("Y-m-d",strtotime($postArr['to_date']))."'";
													}else{
														$wheredata[$k++]="b.bill_date >='".date("Y-m-d")."'";
														$wheredata[$k++]="b.bill_date <='".date("Y-m-d")."'";
													}
													if(!empty($postArr['billno'])) {
														$wheredata[$k++]="b.bill_no ='".$postArr['billno']."'";
													}													
													if(!empty($postArr['type'])) {
														$wheredata[$k++]="a.type ='".$postArr['type']."'";
														
													}
													if(!empty($postArr['ref_no'])) {
														$wheredata[$k++]="a.ref_no ='".$postArr['ref_no']."'";
														
													}

                                                                                         $user_data=array();
                                                                                    //USER TYPE RESTRICTION
											$user_type=$_SESSION['user_type'];

										if(!empty($postArr['user_type'])) {
														
										      $user_data[]="a.user_type='".$postArr['user_type']."'";
                                                                                }else{

                                                                                   if($user_type !='ADMIN' && empty($postArr['user_type'])){
													
														
														
														
											//IF USER LOGGED IN IS LAB ADMIN SHOW LAB USER IN USERTYPE DROPDOWN
											if($user_type == "LAB ADMIN"){
															
												$user_data[]="b.user_type='LAB ADMIN' or b.user_type='LAB USER'";

											}else{
															
												$user_data[]="b.user_type='".$user_type."'";
														
											}
														
										  }

                                                                                }                                                                                                                                             
                                                                                                  														
                                                                  
														
										$userInfo=$user_obj->getfullUserInfo($user_data);
															
										    if(count($userInfo) >0){
											for($i=0;$i<count($userInfo);$i++){
														
												if($i == 0 ){
													$user_id .="(";
												}
														
												if($i == ((count($userInfo))-1)){
														
													$user_id .=$userInfo[$i][0].")";
												}else{
													$user_id .=$userInfo[$i][0].",";
												}
											}
											$wheredata[$k++]="b.user_id in $user_id";
										}else $wheredata[$k++]="b.user_id in (0)";
														
														
													
														
													
													
													$wheredata[$k++]="a.status ='0'";
													$wheredata[$k++]="a.credit > 0";
													
													
													
													$user_type_info=array();
													
												    if($user_type !='ADMIN' ){
													
														
														
														
														//IF USER LOGGED IN IS LAB ADMIN SHOW LAB USER IN USERTYPE DROPDOWN
														if($user_type == "LAB ADMIN"){
															
															$user_type_info[]="user_type='LAB ADMIN' or user_type='LAB USER'";

														}else{
															
															$user_type_info[]="user_type='".$user_type."'";
														
														}
														
													}
													
													$form_creator ->popArr['post']=$postArr;
													$form_creator ->popArr['user_type']=$user_obj->getUsertype($user_type_info);
													$form_creator ->popArr['billInfo']=$bill_obj->getfullCreditInfo($wheredata);
													$form_creator ->formPath ='/templates/reports/credit_payment_report.php';
													break;
					case 'itemwise_conso_bill_report'		: 		
													$bill_obj=new Billing();
													$user_obj=new User();
													$db_function =new DBFunction();
													$k=0;
													if(!empty($postArr['from_date'])) {
													
														$wheredata[$k++]="bill_date >='".date("Y-m-d",strtotime($postArr['from_date']))."'";
														$wheredata[$k++]="bill_date <='".date("Y-m-d",strtotime($postArr['to_date']))."'";
													}else{
														$wheredata[$k++]="bill_date >='".date("Y-m-d")."'";
														$wheredata[$k++]="bill_date <='".date("Y-m-d")."'";
													}
													$pInfo=explode(" -",$postArr['particulars_ID']);
		
													if(!empty($postArr['particulars'])){
													$ptype=$pInfo[0];
													$pid=$pInfo[1];
		
		
													$wheredata[]="type='".$ptype."'";
		
		
													if($ptype == "L"){
		
														if($db_function->isValidCatagory($item)){
			
															$tid=$db_function->getidToValue("tid","eid",$pid,"hcare_lab_test_element");
															$wheredata[]="(test_id='".$pid."' or test_id='".$tid."')";
				
				
				
														}else{
															$wheredata[]="test_id='".$pid."'";
														}
												}else{
													$wheredata[]="test_id='".$pid."'";
												}
												}	
													
													$form_creator ->popArr['post']=$postArr;
													
													$bill_info=$bill_obj->getBillConsoItems($wheredata);
													
													
													$form_creator ->popArr['billInfo']=$bill_info;
													$form_creator ->formPath ='/templates/reports/billing_report_conso_items.php';
													break;
		case 'bill_report_item_details'		: 		
													$bill_obj=new Billing();
													$user_obj=new User();
													$k=0;
													if(!empty($postArr['from_date'])) {
													
														$wheredata[$k++]="a.bill_date >='".date("Y-m-d",strtotime($postArr['from_date']))."'";
														$wheredata[$k++]="a.bill_date <='".date("Y-m-d",strtotime($postArr['to_date']))."'";
													}else{
														$wheredata[$k++]="a.bill_date >='".date("Y-m-d")."'";
														$wheredata[$k++]="a.bill_date <='".date("Y-m-d")."'";
													}
													if(!empty($postArr['billno'])) {
														$wheredata[$k++]="a.id ='".$postArr['billno']."'";
													}
													if(!empty($postArr['status'])) {
														$wheredata[$k++]="a.status ='".$postArr['status']."'";
													}else $wheredata[$k++]="a.status ='0'";
													
													if(!empty($postArr['type'])) {
														$wheredata[$k++]="a.type ='".$postArr['type']."'";
														
													}
													
													//Filter data by name if name field is not empty
													if($postArr['type'] == "OP" &&  !empty($postArr['name'])) {
														$wheredata[$k++]="b.first_name like '%".$postArr['name']."%'";
														
													}elseif($postArr['type'] == "DIRECT" &&  !empty($postArr['name'])) {
														$wheredata[$k++]="c.name like '%".$postArr['name']."%'";
														
													}elseif(!empty($postArr['name'])){
													
														$wheredata[$k++]="(b.first_name like '%".$postArr['name']."%' or c.name like '%".$postArr['name']."%')";
														
													}
													
													
													$user_type=$_SESSION['user_type'];
													$user_type_id=$_SESSION['user_type_id'];
													
													if(!empty($postArr['user'])) {
														$wheredata[$k++]="a.user_id ='".$postArr['user']."'";

														
													}
													$user_data=="";
													
												    if($user_type !='ADMIN' && empty($postArr['user'])){
													
														$user_id=$_SESSION['user_id'];
														$wheredata[$k++]="a.user_id ='".$user_id."'";
														$user_data[0]="user_type='".$user_type_id."'";
														$postArr['user']=$user_id; 
													}
													
													$form_creator ->popArr['post']=$postArr;
													$form_creator ->popArr['user']=$user_obj->getUser('',$user_data);
													$bill_info=$bill_obj->getBillInfoAllField($wheredata);
													
													if(!empty($bill_info)){
													
														for($i=0;$i<count($bill_info);$i++){
														
															$billid=$bill_info[$i][0];
															$itemcondition[0]="bill_id = ".$billid;
															$itemInfo=$bill_obj->getBillItemsInfo($itemcondition);
															$items="";
															if(!empty($itemInfo)){
																for($k=0;$k<count($itemInfo);$k++){
																
																	$items .=$itemInfo[$k][5]."<br>";
															
																}
															}
															$bill_info[$i][23]=$items;
														}
													}
													$form_creator ->popArr['billInfo']=$bill_info;
													$form_creator ->formPath ='/templates/reports/billing_report_item_details.php';
													break;
					case 'bill_report'		:
													$bill_obj=new Billing();
													$user_obj=new User();
													$k=0;
													if(!empty($postArr['from_date'])) {
													
														$wheredata[$k++]="a.bill_date >='".date("Y-m-d",strtotime($postArr['from_date']))."'";
														$wheredata[$k++]="a.bill_date <='".date("Y-m-d",strtotime($postArr['to_date']))."'";
													}else{
														$wheredata[$k++]="a.bill_date >='".date("Y-m-d")."'";
														$wheredata[$k++]="a.bill_date <='".date("Y-m-d")."'";
													}
													if(!empty($postArr['billno'])) {
														$wheredata[$k++]="a.id ='".$postArr['billno']."'";
													}
													if(!empty($postArr['status'])) {
														$wheredata[$k++]="a.status ='".$postArr['status']."'";
													}else $wheredata[$k++]="a.status ='0'";
													
													if(!empty($postArr['type'])) {
														$wheredata[$k++]="a.type ='".$postArr['type']."'";
														
													}
													
													//Filter data by name if name field is not empty
													if($postArr['type'] == "OP" &&  !empty($postArr['name'])) {
														$wheredata[$k++]="b.first_name like '%".$postArr['name']."%'";
														
													}elseif($postArr['type'] == "DIRECT" &&  !empty($postArr['name'])) {
														$wheredata[$k++]="c.name like '%".$postArr['name']."%'";
														
													}elseif(!empty($postArr['name'])){
													
														$wheredata[$k++]="(b.first_name like '%".$postArr['name']."%' or c.name like '%".$postArr['name']."%')";
														
													}
													
													
													$user_type=$_SESSION['user_type'];
													$user_type_id=$_SESSION['user_type_id'];
													
													if(!empty($postArr['user'])) {
														$wheredata[$k++]="a.user_id ='".$postArr['user']."'";

														
													}
													$user_data=="";
													
												    if($user_type !='ADMIN' && empty($postArr['user'])){
													
														$user_id=$_SESSION['user_id'];
														$wheredata[$k++]="a.user_id ='".$user_id."'";
														
														//$postArr['user']=$user_id; 
													}
													
													 if($user_type !='ADMIN'){
													 
													
													 
													 if($user_type_id == 6) {
													 
													 	$user_data[0]="user_type='".$user_type_id."'"." or "."user_type='7'";
													 }else  $user_data[0]="user_type='".$user_type_id."'";
													 //$postArr['user']='';
													 }
													
													$form_creator ->popArr['post']=$postArr;
													$form_creator ->popArr['user']=$user_obj->getUser('',$user_data);
													$form_creator ->popArr['billInfo']=$bill_obj->getBillInfoAllField($wheredata);
													$form_creator ->formPath ='/templates/reports/billing_report.php';
													break;
						case 'test_consolidated' :
													$this->getConsolidatedTest($postArr);
													$form_creator ->formPath ='/templates/reports/test_consolidated.php';
													break;
					 case 'itemwise_bill_report' :
					 
					 								$cat_obj=new Category();
													$form_creator ->popArr['category']=$cat_obj->getCategory();
													
													$form_creator ->popArr['itemInfo']="";
													
													
													$form_creator ->popArr['post']=$postArr;
													
													if(!empty($postArr['particulars'])){
													
														
														$form_creator ->popArr['itemInfo']=$this->getitemwise_bill_report($postArr);
													}
													
													$form_creator ->formPath ='/templates/reports/itemwise_bill_report.php';
													break;
				
													
			
			}
			
			$form_creator->display();
	
	}
	
	public function getitemwise_bill_report($postArr){
	
		$bill_obj=new Billing();
		$db_function =new DBFunction();

		$item=$postArr['particulars'];
		
		
		$pInfo=explode(" -",$postArr['particulars_ID']);
		
		$ptype=$pInfo[0];
		$pid=$pInfo[1];
		$amount=0;
		
		$wheredata[]="type='".$ptype."'";
		
		
		if($ptype == "L"){
		
			if($db_function->isValidCatagory($item)){
			
				$tid=$db_function->getidToValue("tid","eid",$pid,"hcare_lab_test_element");
				$wheredata[]="(test_id='".$pid."' or test_id='".$tid."')";
				
				$amount=$db_function->getidToValue("Price","id",$pid,"hcare_lab_element");
				
			}else{
				$wheredata[]="test_id='".$pid."'";
			}
		}else{
				$wheredata[]="test_id='".$pid."'";
		}
		
		if(!empty($postArr['from_date'])) {
													
			$wheredata[]="bill_date >='".date("Y-m-d",strtotime($postArr['from_date']))."'";
			$wheredata[]="bill_date <='".date("Y-m-d",strtotime($postArr['to_date']))."'";
		
		}else{
			$wheredata[]="bill_date >='".date("Y-m-d")."'";
		    $wheredata[]="bill_date <='".date("Y-m-d")."'";
		}
		
		
		
		$billitemInfo=$bill_obj->getBillItemsInfo($wheredata);
		
		return array($billitemInfo,$amount);

    }
}



/*public function getConsolidatedTest($postArr){




}	*/

?>
