<?php session_start();

require_once ROOT_PATH . '/lib/common/form.php';
require_once ROOT_PATH . '/lib/common/commonFunctions.php';
require_once ROOT_PATH . '/lib/model/registration/registration.php';
require_once ROOT_PATH . '/lib/model/admin/employee.php';
require_once ROOT_PATH . '/lib/model/DBFunctions.php';
require_once ROOT_PATH . '/lib/model/billing/billing.php';
require_once ROOT_PATH . '/lib/model/admin/user.php';



class BillController {

	

	function viewPage($sub_module,$postArr='',$getArr='',$message=''){
	
			$form_creator = new Form();
			
			if(!empty ($message)){
				$form_creator ->popArr['message']=$message;
			}
			switch($sub_module){
				
				
				case 'Select_Bill'			:
													$com_obj = new CommonFunctions();
													$reg_obj= new Registration();
													$emp_obj= new Employee();
													
													if(!empty($postArr["opno"])){
														$selectCondition[]="a.`id`='".$postArr["opno"]."'";
													}else{
													if(!empty($postArr["date"])){
														$selectCondition[]="b.`visit_date`='".date("Y-m-d",strtotime($postArr["date"]))."'";
													}else $selectCondition[]="b.`visit_date`='".date("Y-m-d")."'";												
													
													}
													if(!empty($postArr["name"])){
														$selectCondition[]="a.`first_name` like '%".$postArr["name"]."%'";
													}
													if(!empty($postArr["mname"])){
														$selectCondition[]="a.`middle_name` like '%".$postArr["mname"]."%'";
													}
													if(!empty($postArr["lname"])){
														$selectCondition[]="a.`last_name` like '%".$postArr["lname"]."%'";
													}
													if(!empty($postArr["place"])){
														$selectCondition[]="a.`place`='".$postArr["place"]."'";
													}
													
													if(!empty($postArr["contact_no"])){
														$selectCondition[]="a.`contact_no`='".$postArr["contact_no"]."'";
													}
													if(!empty($postArr["doctor"])){
														$selectCondition[]="b.`doc_id`='".$postArr["doctor"]."'";
													}
													
													$form_creator ->popArr['patient_info']=$reg_obj->getOPPatientInfo('',$selectCondition,'b.visit_date','asc');
													
													$is_field[0]="a.title='Dr'";													
													$form_creator ->popArr['doctors']=$emp_obj->getEmployee($is_field);
													$form_creator ->formPath ='/templates/billing/selectBill.php';
													break;
					case 'Billing_Form'			:												
													$type=$postArr['type'];
													$opid=$postArr['id'];
													
													if($type == "OP") {
													
														$postArr=$this->processOP($opid);
														
														if(empty($postArr['payment_mode']) && $postArr['ins_id']>0){
															$postArr['payment_mode']="INSURANCE";
														}
														
													}
													
													$postArr['type']=$type;
													$postArr['action'] = "ADD";
													$form_creator ->popArr['post']=$postArr;
													
													$form_creator ->formPath ='/templates/billing/billing_form.php';
													break;
					case 'Manage_Billing'		:
													$bill_obj=new Billing();
													$user_obj=new User();
													$k=0;
													if(!empty($postArr['from_date'])) {
													
														$wheredata[$k++]="bill_date >='".date("Y-m-d",strtotime($postArr['from_date']))."'";
														$wheredata[$k++]="bill_date <='".date("Y-m-d",strtotime($postArr['to_date']))."'";
													}else{
														$wheredata[$k++]="bill_date >='".date("Y-m-d")."'";
														$wheredata[$k++]="bill_date <='".date("Y-m-d")."'";
													}
													if(!empty($postArr['billno'])) {
														$wheredata[$k++]="id ='".$postArr['billno']."'";
													}
													if(!empty($postArr['status'])) {
														$wheredata[$k++]="status ='".$postArr['status']."'";
													}else $wheredata[$k++]="status ='0'";
													if(!empty($postArr['type'])) {
														$wheredata[$k++]="type ='".$postArr['type']."'";
														
													}
													if(!empty($postArr['user'])) {
														$wheredata[$k++]="user_id ='".$postArr['user']."'";
														
													}
													$form_creator ->popArr['post']=$postArr;
													$form_creator ->popArr['user']=$user_obj->getUser();
													$form_creator ->popArr['billInfo']=$bill_obj->getBillInfo($wheredata);
													$form_creator ->formPath ='/templates/billing/manage_billing.php';
													break;
						case 'Credit_Billing'		:
													$bill_obj=new Billing();
													$user_obj=new User();
													$k=0;
													if(!empty($postArr['from_date'])) {
													
														$wheredata[$k++]="bill_date >='".date("Y-m-d",strtotime($postArr['from_date']))."'";
														$wheredata[$k++]="bill_date <='".date("Y-m-d",strtotime($postArr['to_date']))."'";
													}else{
														$wheredata[$k++]="bill_date >='".date("Y-m-d")."'";
														$wheredata[$k++]="bill_date <='".date("Y-m-d")."'";
													}
													if(!empty($postArr['billno'])) {
														$wheredata[$k++]="id ='".$postArr['billno']."'";
													}													
													if(!empty($postArr['type'])) {
														$wheredata[$k++]="type ='".$postArr['type']."'";
														
													}
													/*if(!empty($postArr['ref_no'])) {
														$wheredata[$k++]="type ='".$postArr['type']."'";
														
													}
													if(!empty($postArr['patient_name'])) {
														$wheredata[$k++]="type ='".$postArr['type']."'";
														
													}*/
													
													
													$wheredata[$k++]="status ='0'";
													$wheredata[$k++]="credit > 0";
													
													$form_creator ->popArr['post']=$postArr;
													$form_creator ->popArr['user']=$user_obj->getUser();
													$form_creator ->popArr['billInfo']=$bill_obj->getBillInfo($wheredata,'','',true);
													$form_creator ->formPath ='/templates/billing/credit_billing.php';
													break;
						case 'Print_Bill'		:
													$bill_obj=new Billing();
													
													
													if(!empty($postArr['billid'])){
														$wheredata[0]="id ='".$postArr['billid']."'";
														$wheredataitem[0]="bill_id ='".$postArr['billid']."'";
													}elseif(!empty($postArr['id'])){
														$wheredata[0]="id ='".$postArr['id']."'";
														$wheredataitem[0]="bill_id ='".$postArr['id']."'";
													}
													
													$form_creator ->popArr['billInfo']=$bill_obj->getBillInfo($wheredata);
													$form_creator ->popArr['billitemInfo']=$bill_obj->getBillItemsInfo($wheredataitem);
													$form_creator ->formPath ='/templates/billing/print_bill.php';
													break;
						case 'Credit_Payment_Form'		:
																									
													$form_creator ->popArr['post']=$this->processBillNo($postArr,'credit_payment_form');
													$form_creator ->formPath ='/templates/billing/credit_payment_form.php';
													break;
						case 'Add_Credit'	:
														$bill_obj=new Billing();
														$postArr['bill_no']=$bill_obj->addCredit($postArr);
														$form_creator ->popArr['creditInfo']=$postArr;
														$wheredata[0]="id ='".$postArr['billid']."'";
														$form_creator ->popArr['billInfo']=$bill_obj->getBillInfo($wheredata);
														$form_creator ->formPath ='/templates/billing/print_credit_bill.php';
						                             break;
			
			}
			
			$form_creator->display();
	
	}
	function processBillNo($post,$action = null){
	
		$bill_obj=new Billing();
		$form_creator = new Form();
		$db_function =new DBFunction();
		
		$billid=$post['id'];
		
		$wheredata[0]="id ='".$billid."'";
		$billInfo=$bill_obj->getBillInfo($wheredata);
		
		if(!empty($billInfo)){
		
			$post['billid']=$billid;
			$post['type']=$billInfo[0][1];
			$post['id']=$billInfo[0][2];
			$post['name']=$billInfo[0][3];
			$post['age']=$billInfo[0][4];
			$post['gender']=$billInfo[0][5];
			$post['place']=$billInfo[0][6];
			$post['contact_no']=$billInfo[0][7];
			
			if($billInfo[0][1] == "OP"){
				$post['doctor']=$billInfo[0][8];
				$post['ins_id']=$db_function->getidToValue("insurance_company","id",$billInfo[0][2],"hcare_op_visit_info");;
			}else{
				$post['refferal_info']=$billInfo[0][8];
			}
			$post['date']=$billInfo[0][16];
			
			$post['total_amount']=$billInfo[0][9];
			$post['dr_disc']=$billInfo[0][10];
			$post['net_amount']=$billInfo[0][11];
			$post['payment_mode']=$billInfo[0][12];
			$post['amount_paid']=$billInfo[0][13];
			$post['card_amount']=$billInfo[0][15];
			$post['ins_deduction']=$billInfo[0][20];
			$post['remarks']=$billInfo[0][17];
			$post['action']="UPDATE";
			
			$wheredata[0]="bill_id ='".$billid."'";
			
			$billItemInfo=$bill_obj->getBillItemsInfo($wheredata);
			
			if(!empty($billItemInfo)){
			
				for($i=0;$i<count($billItemInfo);$i++) {
				
				{
					$post["items_in_array"][]=$billItemInfo[$i][4]."!$%".$billItemInfo[$i][5]."!$%".$billItemInfo[$i][7]."!$%".$billItemInfo[$i][8]."!$%".$billItemInfo[$i][9]."!$%".$billItemInfo[$i][11]."!$%".$billItemInfo[$i][3]."!$%".$billItemInfo[$i][6];
				}
			}
			
			
			
			if(!empty($action) && $action='credit_payment_form'){
			$post['balance']=$billInfo[0][14];
			return $post;
			}else{
			$form_creator ->popArr['post']=$post;
			 $form_creator ->formPath ='/templates/billing/billing_form.php';
			}
			$form_creator ->formPath ;
			$form_creator->display();
													
		}
	}
	}
	function processOP($opid){
	
		$reg_obj= new Registration();
		$db_function =new DBFunction();
		
		$total_amount=0;
		$net_amount=0;
		$dr_disc=0;
	
		$selectCondition[0]="b.`id`='".$opid."'";
		$patientInfo=$reg_obj->getOPPatientInfo('',$selectCondition,'b.id','desc');;
													
				$postArr['name']=$patientInfo[0][1]." ".$patientInfo[0][2]." ".$patientInfo[0][3];
				$postArr['place']=$patientInfo[0][8];
				$postArr['age']=$patientInfo[0][4];
				$postArr['gender']=$patientInfo[0][6];
				$postArr['contact_no']=$patientInfo[0][10];
				$postArr['doctor']="Dr.".$patientInfo[0][15]." ".$patientInfo[0][16];
				
				$postArr['ins_id']=$insurance_company=$patientInfo[0][22];
														
					if($patientInfo[0][40] == 0){
														
						$consultaion=$patientInfo[0][17]+$patientInfo[0][18];
						$net_consultaion=$consultaion-$patientInfo[0][31];
															
							if($consultaion > 0 ) {
															
								//$discountInfo=$this->calculateInsuranceDiscount($opid,"C",$patientInfo[0][17]);						
																
																
								$postArr["items_in_array"][]="0"."!$%"."Consultation"."!$%".$consultaion."!$%"."CASH"."!$%".$patientInfo[0][31]."!$%".$net_consultaion."!$%"."C"."!$%"."0"."!$%"."0";
							}
															
									$total_amount=$total_amount+$net_consultaion;
									
					}
			$drpageInfo=$db_function->getDoctorPrescribedTest($opid);
			
			if(!empty($drpageInfo)){
			
				$dr_disc=$drpageInfo['disc_per'];
				
				if(!empty($drpageInfo['generaltest'])){					
				
					$generaltest=explode(",",$drpageInfo['generaltest']);
					for($i=0;$i<count($generaltest);$i++){
						if(!empty($generaltest[$i])){
						
							$t_name=$generaltest[$i];
							$test_id=$db_function->getidToValue("id","procedure_test",$t_name,"hcare_procedure");
							$amount=$db_function->getidToValue("amount","id",$test_id,"hcare_procedure");
							$cid=$db_function->getidToValue("category_id","id",$test_id,"hcare_procedure");
							
								//if($insurance_company > 0 ) {
								
									$discountInfo=$this->calculateInsuranceDiscount($opid,"P",$amount);
									$final_amount=$discountInfo[0];
									$discount_type=$discountInfo[1];
									$discount_value=$discountInfo[2];
								//}
							
							$total_amount=$total_amount+$final_amount;
							
							$postArr["items_in_array"][]=$test_id."!$%".$t_name."!$%".$amount."!$%".$discount_type."!$%".$discount_value."!$%".$final_amount."!$%"."L"."!$%".$cid."!$%"."0";
						}
					}
				
				}
				if(!empty($drpageInfo['labtest'])){	
				
					$labtestpre=explode(",",$drpageInfo['labtest']);
					
					for($i=0;$i<count($labtestpre);$i++){
					
						$discount_type='';
						$discount_value=0;
					
						if(!empty($labtestpre[$i])){
						
							$labtest=$labtestpre[$i];
							
							if($db_function->isValidCatagory($labtest))
							{
							
								$tid=$db_function->getidToValue("id","test_name",$labtest,"hcare_lab_element");
								$cid=$db_function->getidToValue("category","id",$tid,"hcare_lab_element");
								//$status=$db_functions->checktestBilled($opid,$testid,"element")
								
								
								$amount=$db_function->getidToValue("Price","id",$tid,"hcare_lab_element");
								
								//if($insurance_company > 0 ) {
								
									$discountInfo=$this->calculateInsuranceDiscount($opid,"L",$amount);
									$final_amount=$discountInfo[0];
									$discount_type=$discountInfo[1];
									$discount_value=$discountInfo[2];
								//}
							
							}else if($db_function->isValidTest($labtest)){
							
								$tid=$db_function->getidToValue("id","testName",$labtest,"hcare_lab_test");
								$cid=$db_function->getidToValue("catId","id",$tid,"hcare_lab_test");
								//$status=$db_functions->checktestBilled($opid,$testid,"element")
								$amount=$db_function->getidToValue("Price","id",$tid,"hcare_lab_test");
								
								//if($cid!=0) {
								$test_type=1;
								//}
								
								//if($insurance_company > 0 ) {
								
									$discountInfo=$this->calculateInsuranceDiscount($opid,"L",$amount);
									$final_amount=$discountInfo[0];
									$discount_type=$discountInfo[1];
									$discount_value=$discountInfo[2];
								//}
							
							}
							
							$total_amount=$total_amount+$final_amount;
							
							$postArr["items_in_array"][]=$tid."!$%".$labtest."!$%".$amount."!$%".$discount_type."!$%".$discount_value."!$%".$final_amount."!$%"."L"."!$%".$cid."!$%".$test_type;
						}
					}
				
				
				
				}
			}
			$postArr['id']=$opid;
			$postArr['total_amount']=$total_amount;
			$postArr['dr_disc']=$dr_disc;
			$postArr['net_amount']= $total_amount-($total_amount*($dr_disc/100));
			
			return $postArr;
	
	}
	
	function process_select_bill($post){
	
			$form_creator = new Form();
			
			$form_creator ->popArr['post']=$post;
			$form_creator ->formPath ='/templates/billing/selectBill.php';
			$form_creator->display();
	}
	function calculateInsuranceDiscount($opid,$type,$amount){
	
		$db_function =new DBFunction();
		
		$discount_type='';
		$discount_value=0;
		$final_amount=$amount;
		
		$ins_id=$db_function->getidToValue("insurance_company","id",$opid,"hcare_op_visit_info");
		
		if($ins_id >0 && !empty($opid)){
				
				if($type == "C") {
				
					$discount_type=$db_function->getidToValue("cons_disc_type","ins_id",$ins_id,"hcare_insurance_discount_info");
					$discount_value=$db_function->getidToValue("cons_disc_value","ins_id",$ins_id,"hcare_insurance_discount_info");
					
				}else if($type == "L"){
				
					$discount_type=$db_function->getidToValue("lab_disc_type","ins_id",$ins_id,"hcare_insurance_discount_info");
					$discount_value=$db_function->getidToValue("lab_disc_value","ins_id",$ins_id,"hcare_insurance_discount_info");
				}else{
					$discount_type=$db_function->getidToValue("test_disc_type","ins_id",$ins_id,"hcare_insurance_discount_info");
					$discount_value=$db_function->getidToValue("test_disc_value","ins_id",$ins_id,"hcare_insurance_discount_info");
				}
				
					
				if((!empty($discount_type)) && $discount_value >0) {
					
						if($lab_disc_type == "CASH"){
						
							$final_amount=$amount-$discount_value;
						}else {
							$final_amount=$amount-($amount*($discount_value/100));
						}
				}
		}
		
		return array($final_amount,$discount_type,$discount_value);
	
	}
	
	function process_bill_form($post,$get){
	
		$db_function =new DBFunction();
		$form_creator = new Form();
		
		$total_amount=0;
		$net_amount=0;
		
		$opid=$post["id"];
		$post['ins_id']=$ins_id=$db_function->getidToValue("insurance_company","id",$opid,"hcare_op_visit_info");	
		$items=$post['items'];		
		
		if(count($items) > 0){
		
			unset($post['items']);
			$j=0;
			$rm=1;
			for($i=0;$i<count($items);$i++){
			
				$rm=1;
				if($get['action'] == "RM"){
		
		 			$loc=$get['loc'];
					
					if($i==$loc) $rm=0;
		 
		 		}
				if($get['action'] == "INS"){
		
		 			$loc=$get['loc'];
					
					if($i==$loc) {
					
						if($items[$i][9] == "CASH") $items[$i][9]="INSURANCE";
						else $items[$i][9]="CASH";
					}
		 
		 		}
				if($rm!=0) {				
					
					//For Mode Insurance
					
					
						$post["items_in_array"][$j++]=$items[$i][0]."!$%".$items[$i][1]."!$%".$items[$i][2]."!$%".$items[$i][3]."!$%".$items[$i][4]."!$%".$items[$i][5]."!$%".$items[$i][6]."!$%".$items[$i][7]."!$%".$items[$i][8];
						
				
					$total_amount=$total_amount+$items[$i][5];
					
				
			}	
			
		}	
	}
		
		if(!empty($post['particulars'])){
		
			
			$pInfo=explode(" -",$post['particulars_ID']);
			$particular=$post['particulars'];
			
			$ptype=$pInfo[0];
			$pid=$pInfo[1];
			$test_type=0;
			
			if($pid > 0) {
			
				if($ptype == "L"){
			
				
					if($db_function->isValidCatagory($particular)){
				
						$amount=$db_function->getidToValue("Price","id",$pid,"hcare_lab_element");
						$cid=$db_function->getidToValue("category","id",$pid,"hcare_lab_element");
				
					}else if($db_function->isValidTest($particular)){
						$amount=$db_function->getidToValue("Price","id",$pid,"hcare_lab_test");
						$cid=$db_function->getidToValue("catId","id",$pid,"hcare_lab_test");
						//if($cid!=0) {
								$test_type=1;
						//}
					}else {
				
						$amount=0;
						$cid=0;
					}			
					
						
					$discountInfo=$this->calculateInsuranceDiscount($opid,"L",$amount);	
				
					$discount_type=$discountInfo[1];
					$discount_value=$discountInfo[2];
					$final_amount=$discountInfo[0];
				
				}else if($ptype == "P"){
			
			
					$amount=$db_function->getidToValue("amount","id",$pid,"hcare_procedure");
					$cid=$db_function->getidToValue("category_id","id",$pid,"hcare_procedure");
					$discountInfo=$this->calculateInsuranceDiscount($opid,"P",$amount);	
				
					$discount_type=$discountInfo[1];
					$discount_value=$discountInfo[2];
					$final_amount=$discountInfo[0];
				}
			
		
			
			
				$total_amount=$total_amount+$final_amount;
			
			
				
			
					$post["items_in_array"][]=$pid."!$%".$particular."!$%".$amount."!$%".$discount_type."!$%".$discount_value."!$%".$final_amount."!$%".$ptype."!$%".$cid."!$%".$test_type;
				
			}else $form_creator ->popArr['message']="Invalid Item Selected";
		}
		
		$net_amount= $total_amount-($total_amount*($post['dr_disc']/100));
		
		$post['total_amount']=$total_amount;
		$post['net_amount']=$net_amount;
		$form_creator ->popArr['post']=$post;												
		$form_creator ->formPath ='/templates/billing/billing_form.php';
		$form_creator->display();
	
	}
	
	function process_billing($post){
	
		$bill_obj=new Billing();
		$db_function =new DBFunction();
		$reg_obj= new Registration();
		
		$items=$post['items'];
					
		if(count($items) > 0){
		
			if($post['action'] == "ADD"){
			
				if($post['type'] == "DIRECT"){
			
					$post['id']=$bill_obj->addCustomer($post);
				}
		
				$post['billid']=$bill_id=$bill_obj->addToBill($post);
		
				if($bill_id >0 ) {		
		
					for($i=0;$i<count($items);$i++){
				
						if($items[$i][6] == "C" && $post['type'] == "OP"){
						
							$reg_obj->updatePaidStatus($post['id'],1);
						}
						$id=$bill_obj->addToBillItems($bill_id,$items[$i],$post);
					}
				}
			}else{
			
				$bill_id=$post['billid'];
				
				if($post['type'] == "DIRECT"){
			
					$post['id']=$db_function->getidToValue("ref_no","id",$bill_id,"hcare_bill");
					$bill_obj->updateCustomer($post);
				}
				
				$bill_obj->updateBill($post);
				$bill_obj->deleteBillItems($post);
				
				for($i=0;$i<count($items);$i++){
				
					
						$id=$bill_obj->addToBillItems($bill_id,$items[$i],$post);
				}
			
			}
		}
		
		$this->viewPage('Print_Bill',$post,'',$result);
	
	}
	
	function deleteBill($post){
	
		$bill_obj=new Billing();
		$reg_obj= new Registration();
		$db_function =new DBFunction();
		
		$bill_obj->cancelBill($post);
		
		$opid=$db_function->getidToValue("ref_no","id",$post['id'],"hcare_bill");
		$reg_obj->updatePaidStatus($opid,0);
		$bill_obj->cancelBillItems($post);
	}
	
	
	
	
	
}


?>
