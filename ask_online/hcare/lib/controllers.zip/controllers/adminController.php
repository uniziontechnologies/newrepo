<?php session_start();


require_once ROOT_PATH . '/lib/model/admin/user.php';
require_once ROOT_PATH . '/lib/model/admin/hospitalInfo.php';
require_once ROOT_PATH . '/lib/model/admin/department.php';
require_once ROOT_PATH . '/lib/model/admin/designation.php';
require_once ROOT_PATH . '/lib/model/admin/speciality.php';
require_once ROOT_PATH . '/lib/model/admin/employee.php';
require_once ROOT_PATH . '/lib/model/admin/insurance_company.php';
require_once ROOT_PATH . '/lib/model/admin/general.php';
require_once ROOT_PATH . '/lib/model/DBFunctions.php';

require_once ROOT_PATH . '/lib/common/form.php';

class AdminController {

	var $addSuccess="Added Successfully";
	var $addfailed="Failed To Add";
	var $updateSuccess="Updated Successfully";
	var $updatefailed="Failed To Update";
	var $deleteSuccess="Deleted Successfully";
	var $deletefailed="Failed To Delete";

	function viewPage($sub_module,$postArr='',$getArr='',$message=''){
	
			$form_creator = new Form();
			
			if(!empty ($message)){
				$form_creator ->popArr['message']=$message;
			}
			switch($sub_module){
				case 'HospitalInfo'		:
											$hosp_obj= new HospitalInfo();
											$db_obj=new DBFunction();
											
											$form_creator ->popArr['hospitalInfo']=$hosp_obj->getHospitalInfo();
											$form_creator ->popArr['countries']=$db_obj->getCountries();
											
											$form_creator ->formPath ='/templates/admin/hospital/hospitalInfo.php';
											break;
				case 'User'				: 
											$user_obj=new User();
											if(isset($postArr['action']) && ($postArr['action']=="CREATE_PAGE" || $postArr['action']=="EDIT_PAGE")){
											
												
												$form_creator ->formPath ='/templates/admin/user/user_form.php';
												
												
												$form_creator ->popArr['user_type']=$user_obj->getUsertype();
												
												if($postArr['action']=="CREATE_PAGE"){
												
													$form_creator ->popArr['action']="ADD";
													
												}else {								
													
													
													$form_creator ->popArr['action']="UPDATE";
													
													$id=$postArr['id'];
													$wheredata[0]="id=".$id;
													
													$form_creator ->popArr['userInfo']=$user_obj->getUser('',$wheredata);
													
												}
											}else	{
												$k=0;
												if(isset($postArr['action']) && ($postArr['action']=="SEARCH")){								
													
													
													$wheredata='';
													
													$message ="SEARCH RESULT FOR:";
													if(!empty($postArr['username'])){
													
														$message .= " USER NAME  -  ".$postArr['username'] ." ";
														$wheredata[$k]="user_name like '%".$postArr['username']."%'";
														
														$k++;
													}
													if(!empty($postArr['user_type'])){
													
														
														$data[0]="id='".$postArr['user_type']."'";
														$type=$user_obj->getUsertype($data);
														$message .= " &nbsp;USER TYPE -".$type[0][1];
														
														$wheredata[$k]="user_type ='".$postArr['user_type']."'";
														$k++;
													}
													$form_creator ->popArr['message']=$message;
												}
												if(!empty($postArr['id']) && $postArr['action'] == "UPDATE"){
												
													
													$wheredata[$k]="id='".$postArr['id']."'";
													
												}	
													$wheredata[$k]="status = 0";
												$form_creator ->popArr['user_type']=$user_obj->getUsertype();
												$form_creator ->popArr['users']	=$user_obj->getUser('',$wheredata);
												$form_creator ->formPath ='/templates/admin/user/users.php';
											}
											
												
													break;
											
				case 'Department'	   :
				
											$dep_obj=new Department();
											
											if(isset($postArr['action']) && ($postArr['action']=="CREATE_PAGE" || $postArr['action']=="EDIT_PAGE")){
											
													$form_creator ->formPath ='/templates/admin/department/department_form.php';
											
													if($postArr['action']=="CREATE_PAGE"){
												
														$form_creator ->popArr['action']="ADD";
													
													}else {								
													
													
														$form_creator ->popArr['action']="UPDATE";
													
														$id=$postArr['id'];
														$wheredata[0]="id=".$id;
														$form_creator ->popArr['DepartmentInfo']=$dep_obj->getDepartment('',$wheredata);
													
													}
											
											}else{
											
												$k=0;
												
												if(isset($postArr['action']) && ($postArr['action']=="SEARCH")){
												
													
												
													$wheredata='';
													
													$message ="SEARCH RESULT FOR:";
													if(!empty($postArr['dep_name'])){
													
														$message .= " DEPARTMENT NAME  -  ".$postArr['dep_name'] ." ";
														
														$wheredata[$k]="department like '%".$postArr['dep_name']."%'";
														$k++;
													
													}
												}
											
												if(!empty($postArr['id']) && $postArr['action'] == "UPDATE"){
												
														$wheredata[$k]="id='".$postArr['id']."'";
													$k++;
												}
												$wheredata[$k]="status = 0";
											
												$form_creator ->popArr['department']	=$dep_obj->getDepartment('',$wheredata);
												$form_creator ->formPath ='/templates/admin/department/departments.php';
											}
											
													break;
					case 'Designation'	   :
				
											$des_obj=new Designation();
											
											if(isset($postArr['action']) && ($postArr['action']=="CREATE_PAGE" || $postArr['action']=="EDIT_PAGE")){
											
													$form_creator ->formPath ='/templates/admin/job/designation_form.php';
											
													if($postArr['action']=="CREATE_PAGE"){
												
														$form_creator ->popArr['action']="ADD";
													
													}else {								
													
													
														$form_creator ->popArr['action']="UPDATE";
													
														$id=$postArr['id'];
														$wheredata[0]="id=".$id;
														$form_creator ->popArr['DesignationInfo']=$des_obj->getDesignation('',$wheredata);
													
													}
											
											}else{
											
												$k=0;
												
												if(isset($postArr['action']) && ($postArr['action']=="SEARCH")){
												
													
													
													$wheredata='';
													$message ="SEARCH RESULT FOR:";
													if(!empty($postArr['des_name'])){
													
														$message .= " DESIGNATION  -  ".$postArr['des_name'] ." ";
														
														$wheredata[$k]="designation like '%".$postArr['des_name']."%'";
														$k++;
													}
												}
											
												if(!empty($postArr['id']) && $postArr['action'] == "UPDATE"){
												
													$wheredata[$k]="id='".$postArr['id']."'";
													$k++;
													
												}
												$wheredata[$k]="status = 0";
												$form_creator ->popArr['DesignationInfo']	=$des_obj->getDesignation('',$wheredata);
												$form_creator ->formPath ='/templates/admin/job/designations.php';
											}
											
													break;
					case 'Speciality'	   :
				
											$spec_obj=new Speciality();
											$dep_obj=new Department();
											
											
											
											$form_creator ->popArr['department']=$dep_obj->getDepartment();
											
											if(isset($postArr['action']) && ($postArr['action']=="CREATE_PAGE" || $postArr['action']=="EDIT_PAGE")){
											
													$form_creator ->formPath ='/templates/admin/speciality/speciality_form.php';
											
													if($postArr['action']=="CREATE_PAGE"){
												
														$form_creator ->popArr['action']="ADD";
													
													}else {								
													
													
														$form_creator ->popArr['action']="UPDATE";
													
														$id=$postArr['id'];
														$wheredata[0]="id=".$id;
														$form_creator ->popArr['SpecialityInfo']=$spec_obj->getSpeciality('',$wheredata);
													
													}
													
											
												
													
											
											}else{
											
												$k=0;
												
												if(isset($postArr['action']) && ($postArr['action']=="SEARCH")){
												
													
													$likefield='';
													$wheredata='';
													$message ="SEARCH RESULT FOR:";
													if(!empty($postArr['dep_id'])){
													
														$message .= " DEPARTMENT  -  ".$postArr['dep_id'] ." ";
														
														$wheredata[$k]="department_id = '".$postArr['dep_id']."'";
														$k++;
													}if(!empty($postArr['spec_name'])){
													
														$message .= " SPECIALITY  -  ".$postArr['spec_name'] ." ";
														
														$wheredata[$k]="speciality like '%".$postArr['spec_name']."%'";
														$k++;
													}
												}
											
												if(!empty($postArr['id']) && $postArr['action'] == "UPDATE"){
												
													$wheredata[$k]="id='".$postArr['id']."'";
													$k++;
													
												}
												$wheredata[$k]="status = 0";
												$form_creator ->popArr['SpecialityInfo']	=$spec_obj->getSpeciality('',$wheredata);
												$form_creator ->formPath ='/templates/admin/speciality/specialities.php';
											}
											
													break;
				case 'Employee':
										$spec_obj=new Speciality();
										$dep_obj=new Department();
										$des_obj=new Designation();
										$emp_obj=new Employee();
										
																					
										$form_creator ->popArr['department']=$depInfo= $dep_obj->getDepartment();										
										$form_creator ->popArr['SpecialityInfo']	= $spec_obj->getSpeciality();
										$form_creator ->popArr['DesignationInfo']	= $des_obj->getDesignation();
										
										if(isset($postArr['paction']) && ($postArr['paction']=="CREATE_PAGE" || $postArr['paction']=="EDIT_PAGE")){
												
													$form_creator ->formPath ='/templates/admin/employee/employee_form.php';
											
													if($postArr['paction']=="CREATE_PAGE"){
												
														$form_creator ->popArr['action']="ADD";
														
														if(!empty($depInfo)){
														
															$wheredep[0]="department_id ='".$depInfo[0][0]."'";
															$form_creator ->popArr['SpecialityInfo']	= $spec_obj->getSpeciality('',$wheredep);
															$form_creator ->popArr['dep_id']	= $depInfo[0][0];
														}
													
													}else {								
													
													
														$form_creator ->popArr['action']="UPDATE";
													
														$id=$postArr['id'];
														$is_field[0]="a.id ='".$id."'";
														
														$form_creator ->popArr['EmployeeInfo']=$empInfo=$emp_obj->getEmployee($is_field);
														$dep_id=$empInfo[0][10];
														
														$wheredep[0]="department_id ='".$dep_id."'";
														
														
														$form_creator ->popArr['SpecialityInfo']= $spec_obj->getSpeciality('',$wheredep);
													
													}
													if($postArr['change']=="CHANGE"){
													
														$form_creator ->popArr['postArr']=$postArr;
														if(!empty($postArr['dep_id'])){
															
															$data[0]="department_id ='".$postArr['dep_id']."'";
															$form_creator ->popArr['SpecialityInfo']	= $spec_obj->getSpeciality('',$data);
														}
													}
										
										}else{
										
												if(isset($postArr['paction']) && ($postArr['paction']=="SEARCH")){
													if(isset($postArr['search_by'])){
															$searchby=$postArr['search_by'];
													}
												
												}
												$form_creator ->popArr['EmployeeInfo']= $emp_obj->getEmployee();
										
										
												$form_creator ->formPath ='/templates/admin/employee/employees.php';
										}
										
												break;
								
				case 'Insurance'	:
										$ins_obj=new InsuranceCompany();
										$db_obj=new DBFunction();
										
										if(isset($postArr['action']) && ($postArr['action']=="CREATE_PAGE" || $postArr['action']=="EDIT_PAGE")){
											
													$form_creator ->formPath ='/templates/admin/insurance_company/insurance_company_form.php';
											
													if($postArr['action']=="CREATE_PAGE"){
												
														$form_creator ->popArr['action']="ADD";
													
													}else {								
													
													
														$form_creator ->popArr['action']="UPDATE";
													
														$id=$postArr['id'];
														$is_field[0]="a.id ='".$id."'";
														
														
														$form_creator ->popArr['countries']=$db_obj->getCountries();
														$form_creator ->popArr['InsuranceCompanyInfo']=$ins_obj->getInsCompany($is_field);
													
													}
											
											}else{
													$is_field= NULL ;
													if(isset($postArr['action']) && ($postArr['action']=="SEARCH")){
													
														$message ="SEARCH RESULT FOR:";
														
														if(!empty($postArr['ins_company'])){
													
														$message .= " INSURANCE COMPANY  -  ".$postArr['ins_company'] ." ";
														$is_field[0]="a.insurance_company like '%".$postArr['ins_company']."%'";
													
														
														}
														$form_creator ->popArr['message']=$message;
													}
												$form_creator ->popArr['InsuranceCompanyInfo']= $ins_obj->getInsCompany($is_field);
												$form_creator ->formPath ='/templates/admin/insurance_company/insurance_companies.php';
											}
											break;
										
										
				case 'OPSettings'	:
											$gen_obj = new General();
											$form_creator ->popArr['opSettingsinfo']= $gen_obj->getOpSettings();
											$form_creator ->formPath ='/templates/admin/general/op_settings.php';
											break;
				
										
						
									
			
			}
			
			$form_creator->display();
	
	}
	
	function updateHospitalInfo($post){
	
			$hosp_obj= new HospitalInfo();
			
			$status=$hosp_obj->updateHospitalInfo($post);
			if($status){
				
					$message='Update Successfully';
			}else {	
							
					$message='Failed To Update';				
			}
			
			$this->viewPage('HospitalInfo','','',$message);
	}
	function manageUser($post){
	
			$user_obj=new User();
			
			$action=$post['action'];
			
			if($action =="ADD" || $action == "UPDATE"){
			
				$check_user=$user_obj->checkUser($post);
				
					if($check_user){
							
							if($action =="ADD"){
								
								$status=$user_obj->addUser($post);
								
							}else{
								$status=$user_obj->updateUser($post);
							}
				
					}else{
						$message='User Already Exist!';
					}
			
			}else{
			
				$status=$user_obj->deleteUser($post);
			}
			
			if($status){
				$message=strtolower($action)."Success";
				$message=$this->$message; 
			}else{
				$message=strtolower($action)."failed";
				$message=$this->$message;
			}
			$this->viewPage('User',$post,'',$message);
	}
	
	function manageDepartment($post){
	
			$dep_obj=new Department();
			
			$action=$post['action'];
			
			if($action =="ADD" || $action == "UPDATE"){
			
					if($action =="ADD"){
								
						$status=$dep_obj->addDepartment($post);
								
					}else{
					
						$status=$dep_obj->updateDepartment($post);
					}
			
			}else{
			
				$is_dep_in_use=$dep_obj->checkDepartment($post);
				if($is_dep_in_use){
					$status=$dep_obj->deleteDepartment($post);
				}else {
				
					$message ="Department Already in Use";
					$this->viewPage('Department',$post,'',$message);
					exit();
				}
			
			}
			
			
			if($status){
				$message=strtolower($action)."Success";
				$message=$this->$message; 
			}else{
				$message=strtolower($action)."failed";
				$message=$this->$message;
			}
			$this->viewPage('Department',$post,'',$message);
	
	
	}
	function manageDesignation($post){
	
			$des_obj=new Designation();
			
			$action=$post['action'];
			
			if($action =="ADD" || $action == "UPDATE"){
			
					if($action =="ADD"){
								
						$status=$des_obj->addDesignation($post);
								
					}else{
					
						$status=$des_obj->updateDesignation($post);
					}
			
			}else{
				$is_des_in_use=$des_obj->checkDesignation($post);
				
				if($is_des_in_use){
				
					$status=$des_obj->deleteDesignation($post);
				}else {
				
					$message ="Designation Already in Use";
					$this->viewPage('Designation',$post,'',$message);
					exit();
				}
			
			}
			
			
			if($status){
				$message=strtolower($action)."Success";
				$message=$this->$message; 
			}else{
				$message=strtolower($action)."failed";
				$message=$this->$message;
			}
			$this->viewPage('Designation',$post,'',$message);
	
	
	}
	function manageSpeciality($post){
	
			$spec_obj=new Speciality();
			
			$action=$post['action'];
			
			if($action =="ADD" || $action == "UPDATE"){
			
					if($action =="ADD"){
								
						$status=$spec_obj->addSpeciality($post);
								
					}else{
					
						$status=$spec_obj->updateSpeciality($post);
					}
			
			}else{
			
				$status=$spec_obj->deleteSpeciality($post);
			
			}
			
			
			if($status){
				$message=strtolower($action)."Success";
				$message=$this->$message; 
			}else{
				$message=strtolower($action)."failed";
				$message=$this->$message;
			}
			$this->viewPage('Speciality',$post,'',$message);
	
	
	}
	function manageEmployee($post){
	
		$emp_obj=new Employee();
			
			$action=$post['paction'];
			
			if($action =="ADD" || $action == "UPDATE"){
			
					if($action =="ADD"){
								
						$status=$emp_obj->addEmployee($post);
								
					}else{
					
						$status=$emp_obj->updateEmployee($post);
					}
			
			}else{
			
				$status=$emp_obj->deleteEmployee($post);
			
			}
			
			
			if($status){
				$message=strtolower($action)."Success";
				$message=$this->$message; 
			}else{
				$message=strtolower($action)."failed";
				$message=$this->$message;
			}
			$this->viewPage('Employee',$post,'',$message);
	
	
	}
	function manageInsCompany($post){
	
			$ins_obj=new InsuranceCompany();
			
			$action=$post['action'];
			
			if($action =="ADD" || $action == "UPDATE"){
			
					if($action =="ADD"){
								
						$status=$ins_obj->addInsCompany($post);
								
					}else{
					
						$status=$ins_obj->updateInsCompany($post);
					}
			
			}else{
			
				$status=$ins_obj->deleteInsCompany($post);
			
			}
			
			
			if($status){
				$message=strtolower($action)."Success";
				$message=$this->$message; 
			}else{
				$message=strtolower($action)."failed";
				$message=$this->$message;
			}
			$this->viewPage('Insurance',$post,'',$message);
	
	
	}
	function manageOPSettings($post){
	
			$gen_obj=new General();
			
			$action=$post['action'];
			
			if($action =="ADD" ){
			
					if($action =="ADD"){
								
						$status=$gen_obj->addOpSettings($post);
								
					}
			
		}
			
			
			if($status){
				$message=strtolower($action)."Success";
				$message=$this->$message; 
			}else{
				$message=strtolower($action)."failed";
				$message=$this->$message;
			}
			$this->viewPage('OPSettings',$post,'',$message);
	
	
	}
	
	
	
	
}


?>
