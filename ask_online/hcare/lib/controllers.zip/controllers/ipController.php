﻿<?php session_start();



require_once ROOT_PATH . '/lib/model/room/room.php';
require_once ROOT_PATH . '/lib/model/inpatient/inpatient.php';
require_once ROOT_PATH . '/lib/model/registration/registration.php';
require_once ROOT_PATH . '/lib/model/admin/employee.php';
require_once ROOT_PATH . '/lib/model/DBFunctions.php';

require_once ROOT_PATH . '/lib/common/form.php';

class IpController {

	var $addSuccess="Added Successfully";
	var $addfailed="Failed To Add";
	var $updateSuccess="Updated Successfully";
	var $updatefailed="Failed To Update";
	var $deleteSuccess="Deleted Successfully";
	var $deletefailed="Failed To Delete";

	function viewPage($sub_module,$postArr='',$getArr='',$message=''){
	
			$form_creator = new Form();
			
			if(!empty ($message)){
				$form_creator ->popArr['message']=$message;
			}
			switch($sub_module){
				
				case 'OP_Search'	   :
													$com_obj = new CommonFunctions();
													$reg_obj= new Registration();
													$emp_obj= new Employee();
													
													if(!empty($postArr["opno"])){
														$selectCondition[]="a.`id`='".$postArr["opno"]."'";
													}else{
													if(!empty($postArr["date"])){
														$selectCondition[]="b.`visit_date`='".date("Y-m-d",strtotime($postArr["date"]))."'";
													}else $selectCondition[]="b.`visit_date`='".date("Y-m-d")."'";												
													
													}
													if(!empty($postArr["name"])){
														$selectCondition[]="a.`first_name` like '%".$postArr["name"]."%'";
													}
													if(!empty($postArr["mname"])){
														$selectCondition[]="a.`middle_name` like '%".$postArr["mname"]."%'";
													}
													if(!empty($postArr["lname"])){
														$selectCondition[]="a.`last_name` like '%".$postArr["lname"]."%'";
													}
													if(!empty($postArr["place"])){
														$selectCondition[]="a.`place`='".$postArr["place"]."'";
													}
													
													if(!empty($postArr["contact_no"])){
														$selectCondition[]="a.`contact_no`='".$postArr["contact_no"]."'";
													}
													if(!empty($postArr["doctor"])){
														$selectCondition[]="b.`doc_id`='".$postArr["doctor"]."'";
													}
													
													$form_creator ->popArr['patient_info']=$reg_obj->getOPPatientInfo('',$selectCondition,'b.visit_date','asc');
													
													$is_field[0]="a.title='Dr'";													
													$form_creator ->popArr['doctors']=$emp_obj->getEmployee($is_field);
													
													$form_creator ->formPath ='/templates/inpatient/op_search.php';
													break;
					case 'Admission_Form'			:												
													
													//create objects
													$db_obj=new DBFunction();
													$emp_obj=new Employee();
													$dep_obj=new Department();
													$room_obj= new Room();
                                                                                                        $ip_obj= new Inpatient();	
													
													//check ip patient updation or ip patiet admission
													if(isset($postArr['paction']) && $postArr['paction'] == "EDIT_PAGE"){
													
													     $ipno=$postArr['id'];													
													     $postArr=$this->processIP($ipno);
													    $action = "UPDATE";

                                                                                                           //room history informations

													  $where[]= "ipno = ".$ipno;
                                                                                                          $form_creator ->popArr['roomhist'] = $ip_obj->getRoomhistory('',$where);
													}else{
													
													   //get op details
													   $opid=$postArr['id'];													
													   $postArr=$this->processOP($opid);
													
													   //set action										
													
													        $action = "SAVE";
													}
												
													
													
													
													
													
											//set form element values
													$is_field[0]="a.title='Dr'";												
													$form_creator ->popArr['doctors']=$emp_obj->getEmployee($is_field);
													$form_creator ->popArr['post']=$postArr;
													$form_creator ->popArr['departments']=$dep_obj->getDepartment();
													$form_creator ->popArr['countries']=$db_obj->getCountries();
													
													
													$form_creator ->popArr['roomInfo']=$this->getFreeRooms();
													$form_creator ->popArr['action']=$action;
												
											//set the page	
													$form_creator ->formPath ='/templates/inpatient/admission_form.php';
													break;
					case 'manageInpatient' : 
					                           $emp_obj= new Employee();
											   $room_obj= new Room();
											   $com_obj = new CommonFunctions();
											   $ip_obj= new Inpatient();
											   
											   //search criterias
											   if(isset($postArr['from_date']) && $postArr['paction']!="CLEAR"){
											   
															$fromdate=$com_obj->getcurrentDate("Y-m-d",$postArr['from_date']);
															$todate=$com_obj->getcurrentDate("Y-m-d",$postArr['to_date']);
															
															if(!empty($postArr["opno"])){
																$selectCondition[]="a.`id`='".$postArr["opno"]."'";
															}
															if(!empty($postArr["ipno"])){
																$selectCondition[]="b.`id`='".$postArr["ipno"]."'";
															}
															if(!empty($postArr["first_name"])){
																$selectCondition[]="a.`first_name` like '%".$postArr["first_name"]."%'";
															}
															if(!empty($postArr["place"])){
																$selectCondition[]="a.`place`='".$postArr["place"]."'";
															}
															if(!empty($postArr["doctor"])){
																$selectCondition[]="b.`doc_id`='".$postArr["doctor"]."'";
															}
															if(!empty($postArr["room_no"])){
																$selectCondition[]="c.`room_number`='".$postArr["room_no"]."'";
															}
											   }else{
															$fromdate=$com_obj->getcurrentDate();
															$todate=$com_obj->getcurrentDate();
												}
												
												//$selectCondition[]="b.`admission_date`>='".$fromdate."'";
												//$selectCondition[]="b.`admission_date`<='".$todate."'";       
                                                                                                $selectCondition[]="(b.`discharge_date`='0000-00-00' OR b.`discharge_date`='')";                                                                            

												$selectCondition[]="b.`cancelled`=0";
												$form_creator ->popArr['patient_info']=$ip_obj->getIPPatientInfo('',$selectCondition,'b.admission_date','asc');
												if($postArr['action']!="CLEAR"){
															$form_creator ->popArr['post']=$postArr;
												}else $form_creator ->popArr['post']='';
											  
											  $is_field[0]="a.title='Dr'";													
											  $form_creator ->popArr['doctors']=$emp_obj->getEmployee($is_field);
											  
											 // $form_creator ->popArr['roomInfo']=$room_obj->getRoomDetails();
					                                                  $form_creator ->formPath ='/templates/inpatient/manage_ip_patient.php';
													break;

                                        case 'Discharged_patients' :

                                                                      $com_obj = new CommonFunctions();
                                                                      $emp_obj= new Employee();
                                                                      $bill_obj= new Billing();
                                                                       $ip_obj= new Inpatient();
//search criterias
									if(isset($postArr['from_date']) && $postArr['paction']!="CLEAR"){
											   
										$fromdate=$com_obj->getcurrentDate("Y-m-d",$postArr['from_date']);
										$todate=$com_obj->getcurrentDate("Y-m-d",$postArr['to_date']);
															
										if(!empty($postArr["opno"])){
											$selectCondition[]="a.`id`='".$postArr["opno"]."'";
										}
										if(!empty($postArr["ipno"])){
											$selectCondition[]="b.`id`='".$postArr["ipno"]."'";
										}
										if(!empty($postArr["first_name"])){
											$selectCondition[]="a.`first_name` like '%".$postArr["first_name"]."%'";
										}
										if(!empty($postArr["place"])){
											$selectCondition[]="a.`place`='".$postArr["place"]."'";
										}
										if(!empty($postArr["doctor"])){
											$selectCondition[]="b.`doc_id`='".$postArr["doctor"]."'";
										}
										if(!empty($postArr["room_no"])){
											$selectCondition[]="c.`room_number`='".$postArr["room_no"]."'";
										}
									}else{
											$fromdate=$com_obj->getcurrentDate();
											$todate=$com_obj->getcurrentDate();
									}

                                                                       $selectCondition[]="b.`discharge_date`>='".$fromdate."'";
								       $selectCondition[]="b.`discharge_date`<='".$todate."'";       

                                                                      $selectCondition[]="(b.`discharge_date`!='0000-00-00' OR b.`discharge_date`!='')";
								      $selectCondition[]="b.`cancelled`=0";
								      $patientInfo=$ip_obj->getIPPatientInfo('',$selectCondition,'b.admission_date','asc');
                                
                                                                       
                                                                      $bill_details=array();

                                                                       if(!empty($patientInfo)){
                                                                          for($i=0;$i<count($patientInfo);$i++){
                                                                               
                                                                               $ipno=$patientInfo[$i][13];

                                                                                $condition[0]="ipno ='".$ipno."'";

                                                                                $billInfo=$bill_obj->getIPBillInfo($condition);

                                                                                if(!empty($billInfo)){
                                                                                       for($j=0;$j<count($billInfo);$j++){
                                                                                          
                                                                                          $billno=$billInfo[$j][0];
                                                                                          $total_amount=$billInfo[$j][4];

                                                                                            $bill_details[$i][0]=$billno;
                                                                                            $bill_details[$i][1]=$total_amount;
                                                                                      }
                                                                                }
                                                                          }
     

                                                                       }
                                                                         $is_field[0]="a.title='Dr'";                                                  													
									$form_creator ->popArr['doctors']=$emp_obj->getEmployee($is_field);
											  
									$form_creator ->popArr['patientInfo']=$patientInfo;
                                                                        $form_creator ->popArr['billInfo']=$bill_details;
					                                $form_creator ->formPath ='/templates/inpatient/discharge_patient_list.php';
													break;
                                                                                      break;
					
	                                                                            
									
						
									
			
			}
			
			$form_creator->display();
	
	}
	function processIP($ipno){
	     $ip_obj= new Inpatient();
		 $inc_obj= new InsuranceCompany();
		  $com_obj = new CommonFunctions();	
		 
		 $selectCondition[]="b.`id`='".$ipno."'";
		 $patientInfo=$ip_obj->getIPPatientInfo('',$selectCondition,'b.admission_date','asc');
		 
		    $post['opno']=$opno=$patientInfo[0][0];												
			$post['first_name']=$patientInfo[0][1];
			$post['middle_name']=$patientInfo[0][2];
			$post['last_name']=$patientInfo[0][3];
			
			$age=$patientInfo[0][4];
				
			$age_in=explode(" ",$age);
			$age=$age_in[0];
			$age_type=$age_in[1];
				
				
			$post['age']=$age;
			$post['age_type']=$age_type;
		
			$post['gender']=$patientInfo[0][6];
			$post['marital_status']=$patientInfo[0][7];
			$post['place']=$patientInfo[0][8];
			$post['nationality']=$patientInfo[0][9];
			$post['contact_no']=$patientInfo[0][10];
			$post['email']=$patientInfo[0][11];
                        $post['c_of']=$patientInfo[0][45];
			$post['address']=$patientInfo[0][46];
			$post['mobile_no']=$patientInfo[0][47];
			$post['doctor']=$patientInfo[0][16];
			
			$post['insurance_company']=$patientInfo[0][23];
			$post['policy_no']=$patientInfo[0][25];
			$post['claim']=$patientInfo[0][26];
			$post['company_name']=$patientInfo[0][27];
			$post['company_id']=$patientInfo[0][28];
			$post['relation']=$patientInfo[0][29];
				
			
			if($patientInfo[0][30] !='0000-00-00' && $patientInfo[0][31] !='0000-00-00'){
				$post['date_issue']=date("d-m-Y",strtotime($patientInfo[0][30]));
				$post['date_expiry']=date("d-m-Y",strtotime($patientInfo[0][31]));
			}
			
			if($patientInfo[0][5] !='0000-00-00' && $patientInfo[0][5] !="1970-01-01"){
					$post['dob']=date("d-m-Y",strtotime($patientInfo[0][5]));
			}
			
			if($post['insurance_company']>0){
				$post['inc']="insurance";
			}
			
			
			$todate =$com_obj->getcurrentDate();
			
			//if($patientInfo[0][22] >0 ){
			
					$is_field[0]="a.valid_upto >='".$todate."'";
					$post['inc_company']=$inc_obj->getInsCompany($is_field);
			//}
	
			
			$post['refferal_info']=$patientInfo[0][32];
			
			$post['room_no']=$patientInfo[0][37];
			$post['bed_no']=$patientInfo[0][38];
			$post['rent']=$patientInfo[0][35];
                        $post['room_id']=$patientInfo[0][33];
			$post['bed_id']=$patientInfo[0][34];
			$post['admission_date']=$patientInfo[0][20];
                       
			
			$post['ipno']=$ipno;
			
			
			return $post;
	}
	function processOP($opid){
	
			$reg_obj= new Registration();			
			$inc_obj= new InsuranceCompany();
			$com_obj = new CommonFunctions();	
	
			$selectCondition[0]="b.`id`='".$opid."'";
			$patientInfo=$reg_obj->getOPPatientInfo('',$selectCondition,'b.id','desc');;
			
			$post['opno']=$opno=$patientInfo[0][0];												
			$post['first_name']=$patientInfo[0][1];
			$post['middle_name']=$patientInfo[0][2];
			$post['last_name']=$patientInfo[0][3];
				
			$age=$patientInfo[0][4];
				
			$age_in=explode(" ",$age);
			$age=$age_in[0];
			$age_type=$age_in[1];
				
				
			$post['age']=$age;
			$post['age_type']=$age_type;
		
			$post['gender']=$patientInfo[0][6];
			$post['marital_status']=$patientInfo[0][7];
			$post['place']=$patientInfo[0][8];
			$post['nationality']=$patientInfo[0][9];
			$post['contact_no']=$patientInfo[0][10];
			$post['email']=$patientInfo[0][11];
                        $post['c_of']=$patientInfo[0][44];
			$post['address']=$patientInfo[0][45];
			$post['mobile_no']=$patientInfo[0][46];
			$post['doctor']=$patientInfo[0][14];
			
			$post['insurance_company']=$patientInfo[0][22];
			$post['policy_no']=$patientInfo[0][24];
			$post['claim']=$patientInfo[0][25];
			$post['company_name']=$patientInfo[0][26];
			$post['company_id']=$patientInfo[0][27];
			$post['relation']=$patientInfo[0][28];


                        
				
			
			if($patientInfo[0][29] !='0000-00-00' && $patientInfo[0][30] !='0000-00-00'){
				$post['date_issue']=date("d-m-Y",strtotime($patientInfo[0][29]));
				$post['date_expiry']=date("d-m-Y",strtotime($patientInfo[0][30]));
			}
			
			if($patientInfo[0][5] !='0000-00-00' && $patientInfo[0][5] !="1970-01-01"){
					$post['dob']=date("d-m-Y",strtotime($patientInfo[0][5]));
			}
			
			if($post['insurance_company']>0){
				$post['inc']="insurance";
			}
			
			
			$todate =$com_obj->getcurrentDate();
			
			//if($patientInfo[0][22] >0 ){
			
					$is_field[0]="a.valid_upto >='".$todate."'";
					$post['inc_company']=$inc_obj->getInsCompany($is_field);
			//}
	
			
			$post['id']=$opid;
			
			
			return $post;
	
	}
    
    /*
       ADMIT PATIENT
           Save admission info of selected patient    
    
    */
	function processAdmission($postArr){
	
	       $com_obj = new CommonFunctions();
               $reg_obj= new Registration();
               $ip_obj= new Inpatient();
	       $room_obj= new Room();
               $db_function =new DBFunction();
           
	       $action=$postArr['paction'];
			
			switch($action){
		
				case 'SAVE' :
				
								$opno=$postArr['opno'];
								
                                //update patient info
                                   $opno=$reg_obj->updatePatientinfo($postArr);
                                   
                                //admit a patient
                                
                                   $postArr['admission_time']=$com_obj->getcurrentTime('h:i a');
                                   $postArr['admission_date'] =$com_obj->getcurrentDate();
                                   
                                   $ipno=$ip_obj->addIpPatient($postArr);
								//update bed status free to ADMITTED
								   
				   $room_obj->updateBedStatus('ADMITTED',$postArr['bed_no']);
								   break;
			 case 'UPDATE' :
			                     $ipno=$postArr['ipno'];

                                //check room for room transfer

                                 if(!empty($postArr['room']) && !empty($postArr['bed_no'])){
        
                                    //check for history
				     $where[]= "ipno = ".$ipno;
                                     $roomhist = $ip_obj->getRoomhistory('',$where);

				     if(!empty($roomhist)){

					$count = count($roomhist);
					$startdate= $roomhist[$count-1][3];
					$postArr["startdate"]=$startdate;

                                        
				     }else{

					//$postArr["startdate"]=$postArr["adate"];
                                         echo $postArr["startdate"]=$db_function->getidToValue("admission_date","id",$ipno,"hcare_ip_info");     

				     }

                                     $postArr['enddate']=$com_obj->getcurrentTime('h:i a');
				     $ip_obj->addIProomHistory($postArr);

                                     $room_obj->updateBedStatus('FREE',$postArr['bed_id']);
                                     $room_obj->updateBedStatus('ADMITTED',$postArr['bed_no']);
                                 }
								 
				//update patient info
                                 $opno=$reg_obj->updatePatientinfo($postArr);								 
				 $ipno=$ip_obj->updateIpPatient($postArr);
			}

				
            $this->viewPage("manageInpatient",$post);
	}
	public function getFreeRooms(){
	
		$room_obj= new Room();
		
		//$is_field[0]="room_status='FREE'";
                $wheredata[]="status =0 ";
		$roomInfo=$room_obj->getRoomDetails('',$wheredata);
		$rooms=array();
		$k=0;
		if(!empty($roomInfo)){
		
			for($i=0;$i<count($roomInfo);$i++){
				$condition=array();
				$room_id=$roomInfo[$i][0];
				
				$condition[] = "room_id=".$room_id;
				$condition[] = "bed_status='FREE'";
                                
			
				$bedInfo=$room_obj->getBedInfo('',$condition);
				
				if(!empty($bedInfo)){
				
					$rooms[$k][0]=$roomInfo[$i][0];
					$rooms[$k][1]=$roomInfo[$i][2];
					$k++;
				}
			
			}
		
		}
		
		return $rooms;
	
	}
	
	public function processRoom($post){
	
		//create instance
		
		$room_obj= new Room();	
	
		//get room id
		$room_id=$post['id'];
		
		
		//set the conditions to get room details
		
		$is_field[0]="id=".$room_id;
		$roomInfo=$room_obj->getRoomDetails('',$is_field);
		
		//get room details
		$total_bed_no=$roomInfo[0][4];
		$room_category=$roomInfo[0][1];
		$rent=$roomInfo[0][6];
		
		
		//get bed info
		$beds=array();
		
		$condition[] = "room_id=".$room_id;
		$condition[] = "bed_status='FREE'";
			
		$bedInfo=$room_obj->getBedInfo('',$condition);
			
			
			for($i=0;$i<count($bedInfo);$i++){
			
				$beds[$i][0]=$bedInfo[$i][0];
				$beds[$i][1]=$bedInfo[$i][2];
			}
			
	
		
		$data['bedInfo']=$beds;
		$data['room_rent']=$rent;
		
		 echo json_encode($data);
	}
	
	
	
	
}


?>
