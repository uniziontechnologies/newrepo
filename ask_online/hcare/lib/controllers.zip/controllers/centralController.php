﻿<?php session_start();

define('ROOT_PATH', $_SESSION['path']);

require_once ROOT_PATH . '/lib/controllers/adminController.php';
require_once ROOT_PATH . '/lib/controllers/roomController.php';
require_once ROOT_PATH . '/lib/controllers/registrationController.php';
require_once ROOT_PATH . '/lib/controllers/ipController.php';
require_once ROOT_PATH . '/lib/controllers/bookingController.php';
require_once ROOT_PATH . '/lib/controllers/procedureController.php';
require_once ROOT_PATH . '/lib/controllers/billController.php';
require_once ROOT_PATH . '/lib/controllers/nurseController.php';
require_once ROOT_PATH . '/lib/controllers/drController.php';
require_once ROOT_PATH . '/lib/controllers/repController.php';
require ROOT_PATH . '/language/language.php';

$module=$_GET['module'];
$sub_module=$_GET['sub_module'];

switch ($module) {

	case 'Admin'	: 
						$admin_controller=new AdminController();
					
						if(isset($_GET['View'])){
							$admin_controller->viewPage($sub_module);
							break;
						}
					switch($sub_module){
					
							case 'HospitalInfo'		:		if(isset($_POST['action']) && $_POST['action']==$lang_update){
							
																	$admin_controller->updateHospitalInfo($_POST);
															}
																	break;
							case 'User'				:	
															$action=$_POST['action'];
															 if(isset($_POST['action']) && ($action == $lang_add ||$action == $lang_update || $action == $lang_delete)){
																	$admin_controller->manageUser($_POST);
															}else{
																	$admin_controller->viewPage($sub_module,$_POST);	
															}
																	break;
																	
							case 'Department'	    :	
															$action=$_POST['action'];
															 if(isset($_POST['action']) && ($action == $lang_add ||$action == $lang_update || $action == $lang_delete)){
																	$admin_controller->manageDepartment($_POST);
															}else{
																	$admin_controller->viewPage($sub_module,$_POST);	
															}
																	break;
																
							case 'Designation'	    :	
															$action=$_POST['action'];
															 if(isset($_POST['action']) && ($action == $lang_add ||$action == $lang_update || $action == $lang_delete)){
																	$admin_controller->manageDesignation($_POST);
															}else{
																	$admin_controller->viewPage($sub_module,$_POST);	
															}
																	break;
						    case 'Speciality'	    :	
															$action=$_POST['action'];
															 if(isset($_POST['action']) && ($action == $lang_add ||$action == $lang_update || $action == $lang_delete)){
																	$admin_controller->manageSpeciality($_POST);
															}else{
																	$admin_controller->viewPage($sub_module,$_POST);	
															}
																	break;
							 case 'Employee'	    :	
															$action=$_POST['paction'];
															 if(isset($_POST['paction']) && ($action == $lang_add ||$action == $lang_update || $action == $lang_delete)){
																	$admin_controller->manageEmployee($_POST);
															}else{
																	$admin_controller->viewPage($sub_module,$_POST,$_GET);	
															}
																	break;
							case 'Insurance'	    :	
															$action=$_POST['action'];
															 if(isset($_POST['action']) && ($action == $lang_add ||$action == $lang_update || $action == $lang_delete)){
																	$admin_controller->manageInsCompany($_POST);
															}else{
																	$admin_controller->viewPage($sub_module,$_POST,$_GET);	
															}
																	break;
							case 'OPSettings'	    :	
															$action=$_POST['action'];
															 if(isset($_POST['action']) && ($action == $lang_add )){
																	$admin_controller->manageOPSettings($_POST);
															}else{
																	$admin_controller->viewPage($sub_module,$_POST,$_GET);	
															}
																	break;
							
					
					}
					
	
					break;
	case 'Room'	: 
						$room_controller=new RoomController();
					
						if(isset($_GET['View'])){
							$room_controller->viewPage($sub_module);
							break;
						}
					switch($sub_module){
					
							
																	
							case 'RoomCategory'	    :	
															$action=$_POST['action'];
															 if(isset($_POST['action']) && ($action == $lang_add ||$action == $lang_update || $action == $lang_delete)){
																	$room_controller->manageRoomCategory($_POST);
															}else{
																	$room_controller->viewPage($sub_module,$_POST);	
															}
																	break;
							case 'Room'				:         $action=$_POST['action'];
							
														if(isset($_POST['action']) && ($action == $lang_add ||$action == $lang_update || $action == $lang_delete)){
																	$room_controller->manageRooms($_POST);
															}else{
															
																$room_controller->viewPage($sub_module,$_POST);	
															}
															break;
                                                       case 'delete_room'                       :  $room_controller->deleteRoom($_POST);

                                                                                                    break;

                                                       case 'check_room_status'                       :  $room_controller->check_room_status($_POST);

                                                                                                    break;                
                                                       case 'Process_Station'              :

                                                                                               $room_controller->processStation($_POST);
                                                                                               break;
                                                       case 'Check_Station_Name'          :

                                                                                               $room_controller->check_station_name($_GET);
                                                                                               break;

                                                       default				:	$room_controller->viewPage($sub_module,$_POST);
												break;	
							
							
					
					}
							break;
					
	case 'Booking':
							$bk_controller=new BookingController();
							
							if(isset($_GET['View'])){
								$bk_controller->viewPage($sub_module,$_POST);
								break;
							}
							switch($sub_module){
							
								case 'Scheduling_Form'			:
								
																	if(isset($_GET['action']) && ($_GET['action'] == $lang_block)){
																				
																		$bk_controller->changeBookingStatus($_POST);
																	}
																	else if(isset($_POST['action']) && ($_POST['action'] == $lang_update)){
																				
																		$bk_controller->updateSchedule($_POST);
																	}else{
																	
																		$bk_controller->viewPage($sub_module,$_POST);
																	}
																	break;
								case 'Booking_Form'			:
								
																	if(isset($_POST['action']) && ($_POST['action'] == $lang_add)){
																				
																		$bk_controller->booking_process($_POST);
																	}else{
																	
																		$bk_controller->viewPage($sub_module,$_POST);
																	}
																	break;
								case 'Booking_Report'			:
																	$bk_controller->viewPage($sub_module,$_POST);
																	break;
								case 'Token_Reservation'			:
																	$bk_controller->updateTokenReservation($_POST);
																	break;
								/*case 'Doctors_Availability'     :
																	$bk_controller->viewPage($sub_module,$_POST);
																	break;*/
								default							:	$bk_controller->viewPage($sub_module,$_POST);
																		break;
								
							}
					break;
	case 'Registration':
							$reg_controller=new RegistrationController();
					
							if(isset($_GET['View'])){
								$reg_controller->viewPage($sub_module);
								break;
							}
							switch($sub_module){
							
								case 'patient_registeration'	:		
																		if(isset($_GET['paction']) && ($_GET['paction'] == $lang_process_form)){
																				$reg_controller->processRegForm($_POST);
																		}else if((isset($_GET['paction']) && $_GET['paction'] == $lang_process_OPNo) || (isset($_POST['paction']) && $_POST['paction'] == $lang_edit_page) ){
																				$reg_controller->processOPNo($_POST,$_GET);
																		}else if(isset($_POST['paction']) && ($_POST['paction'] == $lang_registration || $_POST['paction'] == $lang_regupdate)){
																				$reg_controller->processRegistration($_POST);
																		}else if(isset($_POST['paction']) && ($_POST['paction'] == $lang_delete)){
																		
																				$reg_controller->deletePatientVisit($_POST);
																		}else{
																				$reg_controller->viewPage($sub_module,$_POST,$_GET);	
																		}
																		break;
																		
											default				:		$reg_controller->viewPage($sub_module,$_POST);
																		break;
							
							
							
							}
						break;
	case 'IP'   :
		
		
								$ip_controller=new ipController();
					
								if(isset($_GET['View'])){
                                                                      if($sub_module == "Discharge") {

                                                                           $bill_controller = new BillController();
                                                                           $_POST['request_from']="Discharge";
                                                                           $bill_controller->viewPage("IP_Search",$_POST);

                                                                      }else{
									$ip_controller->viewPage($sub_module);
                                                                      }
									break;
								}
								
								switch($sub_module){
								
										/*case 'admit_form'	:
																	$ip_controller->admit_form($_POST,$_GET);
																	break;*/
                                                                             
										case 'patient_admission'	:		
																		if(isset($_POST['paction']) && ($_POST['paction'] == 'SAVE' || $_POST['paction'] == 'UPDATE')){
																				$ip_controller->processAdmission($_POST);
																		}
                                                                                break;
										case 'process_room'  :
																	$ip_controller->processRoom($_POST);
																	break;
										default				:		$ip_controller->viewPage($sub_module,$_POST);
																		break;
								}
		
						break;	
	 case 'Procedures':
	 						$proc_controller = new ProcedureController();
							
							if(isset($_GET['View'])){
								$proc_controller->viewPage($sub_module);
								break;
							}
							switch($sub_module){
							
									case 'Manage_Category'	    :	
																$action=$_POST['action'];
																 if(isset($_POST['action']) && ($action == $lang_add ||$action == $lang_update || $action == $lang_delete)){
																	$proc_controller->manageCategory($_POST);
																}else{
																	$proc_controller->viewPage($sub_module,$_POST);	
																}
																	break;
									case 'Manage_Procedure'	    :	
																$action=$_POST['action'];
																 if(isset($_POST['action']) && ($action == $lang_add ||$action == $lang_update || $action == $lang_delete)){
																	$proc_controller->manageProcedure($_POST);
																}else{
																	$proc_controller->viewPage($sub_module,$_POST);	
																}
																	break;
									default				:		$proc_controller->viewPage($sub_module,$_POST);
																		break;
							
							}
							break;
							
	 case 'Billing':
	 						$bill_controller = new BillController();
							
							if(isset($_GET['View'])){
								$bill_controller->viewPage($sub_module);
								break;
							}
							
							switch($sub_module){
                                                              
                                                                
							
								case 'Process_Select_Bill'	: $bill_controller->process_select_bill($_POST);
																	break;
																	
								case 'Process_Bill_Form'	: $bill_controller->process_bill_form($_POST,$_GET);
																	break;
								case 'Process_Billing'		: $bill_controller->process_billing($_POST);
																	break;
							        case 'Add_Advance_Payment'     : $bill_controller->add_advance_payment($_POST);
																	break;
							          case 'Add_Final_Payment'     : $bill_controller->add_final_payment($_POST);
																	break;
								case 'Final_Payment_Form'       :  if(isset($_POST['paction']) && $_POST['paction']== "json"){
													
													$bill_controller->processFinalForm($_POST);
																		
								
								                                  }else{
								                                  
								                                  	$bill_controller->viewPage($sub_module,$_POST);
																			
								                                  }
								                                  
								                                  break;
								case 'Manage_Billing'		: if((isset($_POST['paction']) && $_POST['paction'] == $lang_edit_page) ){
																	$bill_controller->processBillNo($_POST);
																	break;
																}else if((isset($_POST['paction']) && $_POST['paction'] == $lang_delete) ){
																	$bill_controller->deleteBill($_POST);
																	break;
																}
																	
								default						:		$bill_controller->viewPage($sub_module,$_POST);
																		break;					
								
								
								
							}
							break;

                case 'Nurse' :
                                  $nurse_controller = new NurseController();
                                 

   
							
					if(isset($_GET['View'])){

                                            
                                                if(!empty( $_SESSION['select_station'])) $sub_module ="Select_Station";
                                                else if(!empty( $_SESSION['current_menu'])) $sub_module =$_SESSION['current_menu'];

						$nurse_controller->viewPage($sub_module);
                                           
								break;
					}
							
					switch($sub_module){

                                                case 'select_ip_patient' : 

                                                                           $nurse_controller->select_ip_patient($_POST);

                                                                            break;
                                                
                                                case 'add_procedure' : 

                                                                           $nurse_controller->add_procedure($_POST);

                                                                            break;
                                               case 'delete_procedure' : 

                                                                           $nurse_controller->delete_procedure($_POST);

                                                                            break;
                                               case 'add_doctor_visit' : 

                                                                           $nurse_controller->add_doctor_visit($_POST);

                                                                            break;
                                               case 'delete_doctor_visit' : 

                                                                           $nurse_controller->delete_doctor_visit($_POST);

                                                                            break;
                                               case 'add_nursing_notes' : 

                                                                           $nurse_controller->add_nursing_notes($_POST);

                                                                            break;
                                               case 'delete_nursing_notes' : 

                                                                           $nurse_controller->delete_nursing_notes($_POST);

                                                                            break;
                                               case 'save_nursing_station' :

                                                                             $nurse_controller->save_nursing_station($_POST);

                                                                              break;

                                                 default		  :  $nurse_controller->viewPage($sub_module,$_POST);
                                                                               break;
																		break;					
                                        }
                                     break;
                case 'Doctor' :
                                   $dr_controller = new DrController();
                                 

   
							
					if(isset($_GET['View'])){

                                            
						$dr_controller->viewPage($sub_module);
                                           
								break;
					}

                                  break;
		case 'Report' :
		
		                  $rep_controller = new ReportController();
							
							
				$rep_controller->viewPage($sub_module,$_POST,$_GET);
								break;
							
							



}


?>
