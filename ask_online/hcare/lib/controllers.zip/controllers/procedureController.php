<?php session_start();

require_once ROOT_PATH . '/lib/common/form.php';
require_once ROOT_PATH . '/lib/model/procedure/category.php';
require_once ROOT_PATH . '/lib/model/procedure/procedure.php';
require_once ROOT_PATH . '/lib/model/DBFunctions.php';


class ProcedureController {

	var $addSuccess="Added Successfully";
	var $addfailed="Failed To Add";
	var $updateSuccess="Updated Successfully";
	var $updatefailed="Failed To Update";
	var $deleteSuccess="Deleted Successfully";
	var $deletefailed="Failed To Delete";

	function viewPage($sub_module,$postArr='',$getArr='',$message=''){
	
			$form_creator = new Form();
			
			if(!empty ($message)){
				$form_creator ->popArr['message']=$message;
			}
			switch($sub_module){
				
				
				case 'Manage_Procedure'			:
													$proc_obj=new Procedure();
													$cat_obj=new Category();
													$dbObj=new DBFunction();
											
											
											
											$form_creator ->popArr['category']=$cat_obj->getCategory();
											
											if(isset($postArr['action']) && ($postArr['action']=="CREATE_PAGE" || $postArr['action']=="EDIT_PAGE")){
											
													$form_creator ->formPath ='/templates/procedure/procedure_form.php';
											
													if($postArr['action']=="CREATE_PAGE"){
												
														$form_creator ->popArr['action']="ADD";
													
													}else {								
													
													
														$form_creator ->popArr['action']="UPDATE";
													
														$id=$postArr['id'];
														$wheredata[0]="id=".$id;
														$form_creator ->popArr['procedureInfo']=$proc_obj->getProcedure('',$wheredata);
													
													}	
													
											
											}else{
											
												$k=0;
												
												if(isset($postArr['action']) && ($postArr['action']=="SEARCH")){
												
													
													$likefield='';
													$wheredata='';
													$message ="SEARCH RESULT FOR:";
													if(!empty($postArr['category'])){
													
														$message .= " CATEGORY  -  ".$dbObj->getidToValue("category","id",$postArr['category'],"hcare_procedure_category") ." ";
														
														$wheredata[$k]="category_id = '".$postArr['category']."'";
														$k++;
													}if(!empty($postArr['procedure'])){
													
														$message .= " PROCEDURE  -  ".$postArr['procedure'] ." ";
														
														$wheredata[$k]="`procedure_test` like '%".$postArr['procedure']."%'";
														$k++;
													}
												}
												
												$form_creator ->popArr['message']	=$message;
												
												if(!empty($postArr['id']) && $postArr['action'] == "UPDATE"){
												
													$wheredata[$k]="id='".$postArr['id']."'";
													$k++;
													
												}
												$wheredata[$k]="status = 0";
												$form_creator ->popArr['procedureInfo']	=$proc_obj->getProcedure('',$wheredata);
												$form_creator ->formPath ='/templates/procedure/manage_procedure.php';
											}
											
													break;
													
													
				case 'Manage_Category'			:
													
													$cat_obj=new Category();
											
											if(isset($postArr['action']) && ($postArr['action']=="CREATE_PAGE" || $postArr['action']=="EDIT_PAGE")){
											
													$form_creator ->formPath ='/templates/procedure/category_form.php';
											
													if($postArr['action']=="CREATE_PAGE"){
												
														$form_creator ->popArr['action']="ADD";
													
													}else {								
													
													
														$form_creator ->popArr['action']="UPDATE";
													
														$id=$postArr['id'];
														$wheredata[0]="id=".$id;
														$form_creator ->popArr['categoryInfo']=$cat_obj->getCategory('',$wheredata);
													
													}
											
											}else{
											
												$k=0;
												
												if(isset($postArr['action']) && ($postArr['action']=="SEARCH")){
												
													
												
													$wheredata='';
													
													$message ="SEARCH RESULT FOR:";
													if(!empty($postArr['category'])){
													
														$message .= " CATEGORY NAME  -  ".$postArr['category'] ." ";
														
														$wheredata[$k]="category like '%".$postArr['category']."%'";
														$k++;
													
													}
													$form_creator ->popArr['message']	=$message;
												}
											
												if(!empty($postArr['id']) && $postArr['action'] == "UPDATE"){
												
														$wheredata[$k]="id='".$postArr['id']."'";
													$k++;
												}
												$wheredata[$k]="status = 0";
											
												$form_creator ->popArr['category']	=$cat_obj->getCategory('',$wheredata);
												$form_creator ->formPath ='/templates/procedure/manage_category.php';
											}
											
													break;
													
			
			}
			
			$form_creator->display();
	
	}
	
	function manageCategory($post){
	
			$cat_obj=new Category();
			
			$action=$post['action'];
			
			if($action =="ADD" || $action == "UPDATE"){
			
					if($action =="ADD"){
								
						$status=$cat_obj->addCategory($post);
								
					}else{
					
						$status=$cat_obj->updateCategory($post);
					}
			
			}else{
			
				$is_cat_in_use=$cat_obj->checkCategory($post);
				if($is_cat_in_use){
					$status=$cat_obj->deleteCategory($post);
				}else {
				
					$message ="Category Already in Use";
					$this->viewPage('Manage_Category',$post,'',$message);
					exit();
				}
			
			}
			
			
			if($status){
				$message=strtolower($action)."Success";
				$message=$this->$message; 
			}else{
				$message=strtolower($action)."failed";
				$message=$this->$message;
			}
			$this->viewPage('Manage_Category',$post,'',$message);
	
	
	}
	function manageProcedure($post){
	
			$proc_obj=new Procedure();
			
			$action=$post['action'];
			
			if($action =="ADD" || $action == "UPDATE"){
			
					if($action =="ADD"){
								
						$status=$proc_obj->addProcedure($post);
								
					}else{
					
						$status=$proc_obj->updateProcedure($post);
					}
			
			}else{
			
				$status=$proc_obj->deleteProcedure($post);
			
			}
			
			
			if($status){
				$message=strtolower($action)."Success";
				$message=$this->$message; 
			}else{
				$message=strtolower($action)."failed";
				$message=$this->$message;
			}
			$this->viewPage('Manage_Procedure',$post,'',$message);
	
	
	}
	
	
	
	
}


?>