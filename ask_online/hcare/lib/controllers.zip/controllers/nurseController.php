<?php session_start();

require_once ROOT_PATH . '/lib/common/form.php';
require_once ROOT_PATH . '/lib/common/commonFunctions.php';
require_once ROOT_PATH . '/lib/model/DBFunctions.php';
require_once ROOT_PATH . '/lib/model/inpatient/inpatient.php';
require_once ROOT_PATH . '/lib/model/admin/employee.php';
require_once ROOT_PATH . '/lib/model/procedure/procedure.php';




class NurseController {

	

	function viewPage($sub_module,$postArr='',$getArr='',$message=''){
	
			$form_creator = new Form();
			
			if(!empty ($message)){
				$form_creator ->popArr['message']=$message;
			}
			switch($sub_module){ 
				
				
				case 'Home'			:  $emp_obj= new Employee();								 
								   $com_obj = new CommonFunctions();
								   $ip_obj= new Inpatient();
                                                                   $room_obj=new room();
									

                                                                   //if patient is selected then unset

                                                                    		   
											   //search criterias
							           if(isset($postArr['from_date']) && $postArr['paction']!="CLEAR"){
											   
									$fromdate=$com_obj->getcurrentDate("Y-m-d",$postArr['from_date']);
									$todate=$com_obj->getcurrentDate("Y-m-d",$postArr['to_date']);
															
									if(!empty($postArr["opno"])){
										$selectCondition[]="a.`id`='".$postArr["opno"]."'";
									}
									if(!empty($postArr["ipno"])){
										$selectCondition[]="b.`id`='".$postArr["ipno"]."'";
									}
									if(!empty($postArr["first_name"])){
										$selectCondition[]="a.`first_name` like '%".$postArr["first_name"]."%'";
									}
									if(!empty($postArr["place"])){
										$selectCondition[]="a.`place`='".$postArr["place"]."'";
									}
									if(!empty($postArr["doctor"])){
										$selectCondition[]="b.`doc_id`='".$postArr["doctor"]."'";
									}
									if(!empty($postArr["room_no"])){
										$selectCondition[]="c.`room_number`='".$postArr["room_no"]."'";
									}
								}else{
										$fromdate=$com_obj->getcurrentDate();
										$todate=$com_obj->getcurrentDate();
								}

                                                                $station_id=$_SESSION['station_id'];

                                                                $srooms="";
                                                                $wheredata[0]="station_id=".$station_id;
                                                                $wheredata[1]="status =0 ";
                                                                $roomInfo=$room_obj->getRoomDetails('',$wheredata);

                                                                        if(!empty($roomInfo)){

                                                                           for($j=0;$j<count($roomInfo);$j++) {

                                                                              $srooms .=$roomInfo[$j][0];

                                                                               if($j < (count($roomInfo)-1)) $srooms .="," ;
                                                                           }
                                                                        }
												
												
                                                               $selectCondition[]="(b.`discharge_date`='0000-00-00' OR b.`discharge_date`='')";   
                                                               $selectCondition[]="b.`room_id` in ($srooms)";   


                                                                                  

								$selectCondition[]="b.`cancelled`=0";
								$form_creator ->popArr['patient_info']=$ip_obj->getIPPatientInfo('',$selectCondition,'b.admission_date','asc');
								if(isset($postArr['action']) && $postArr['action']!="CLEAR"){
										$form_creator ->popArr['post']=$postArr;
								}else $form_creator ->popArr['post']='';
											  
								
                                                          $is_field[0]="a.title='Dr'";
										
				                          $form_creator ->popArr['doctors']=$emp_obj->getEmployee($is_field);
											  
											 	
							$form_creator ->formPath ='/templates/nurse/home.php';
							break;

                                  case 'Bill_Procedure': $proc_obj=new Procedure();
                                                         $ip_obj=new Inpatient();

                                                         $_SESSION['current_menu']="";

                                                         $wheredata[0]="status = 0";
                                                         $wheredata[1]="category_id = 1";
							 $form_creator ->popArr['procedureInfo']=$proc_obj->getProcedure('',$wheredata);

                                                         $wheredata[1]="ipno = '".$_SESSION['patient_selected']."'";
                                                         $form_creator ->popArr['ipProcedure']=$ip_obj->getIPProcedure('',$wheredata,'date','asc');

                                                         $form_creator ->formPath ='/templates/nurse/bill_procedure.php';
							 break;
                                 case 'Doctor_Visit': $emp_obj= new Employee();

                                                         $ip_obj=new Inpatient();

                                                         $wheredata[0]="status = 0";
                                                         $wheredata[1]="ipno = '".$_SESSION['patient_selected']."'";
                                                         $form_creator ->popArr['DocVisit']= $ip_obj->getDoctorVisit('',$wheredata,'date','asc');
                                                     

                                                         $is_field[0]="a.title='Dr'";                                                  													
							 $form_creator ->popArr['doctors']=$emp_obj->getEmployee($is_field);
                                                         $form_creator ->formPath ='/templates/nurse/doctor_visit.php';
							 break;
                                case 'Nursing_Notes':    $ip_obj=new Inpatient();

                                                         $wheredata[0]="status = 0";
                                                         $wheredata[1]="ipno = '".$_SESSION['patient_selected']."'";
                                                         $form_creator ->popArr['nurNotes']=$ip_obj->getIPNursingNotes('',$wheredata,'date','asc');

                                                         $form_creator ->formPath ='/templates/nurse/nursing_notes.php';
							 break;
			       case 'Select_Station' : 
                                                       $room_obj=new room();

                                                       $condition[] = "status=0";
                                                       $stationInfo=$room_obj->getNursingStation($condition);

                                                       $form_creator ->popArr['stationInfo']=$stationInfo;

                                                       $form_creator ->formPath ='/templates/nurse/select_station.php';
							 break;
													
			
			}
			
			$form_creator->display();
	
	}
	
       function select_ip_patient($post) {

             $ip_obj= new Inpatient();

             $_SESSION['patient_selected']=$post['id'];
             $_SESSION['current_menu']="Bill_Procedure";

             $selectCondition[]="b.`id`='".$post['id']."'";
             $patientInfo=$ip_obj->getIPPatientInfo('',$selectCondition,'b.admission_date','asc');

             $age=$patientInfo[0][4];
				
	     $age_in=explode(" ",$age);
	     $age=$age_in[0];
	     $age_type=$age_in[1];

             $_SESSION['patient_name']=$patientInfo[0][1]." ".$patientInfo[0][2]." ".$patientInfo[0][3];
             $_SESSION['age']=$age." ".$age_type;	
	     $_SESSION['gender']=$patientInfo[0][6];
             $_SESSION['doctor']=$patientInfo[0][17]." ".$patientInfo[0][18];
             $_SESSION['room_no']=$patientInfo[0][37];
	     $_SESSION['bed_no']=$patientInfo[0][38];

             //$this->viewPage('Bill_Procedure');

             $data['status']="success";
             echo json_encode($data);
      }
      function save_nursing_station($post) {

              $db_function =new DBFunction();

              $_SESSION['station_id']=$post['station'];
              $_SESSION['station_name']=$db_function->getidToValue("station_name","id",$post['station'],"hcare_nursing_stations");

              $_SESSION['select_station']="";

              $this->viewPage('Home');
      }
     function add_procedure($post){
              
            $ip_obj=new Inpatient();
             $db_function =new DBFunction();

             $test_id=$post['procedure'];
             $post['test_amount']=$db_function->getidToValue("amount","id",$test_id,"hcare_procedure");
             $result = $ip_obj->addIPProcedure($post);

            if($result) { $message="Added Successfully!";}
            else  $message="Failed To Add!";

             $this->viewPage('Bill_Procedure','','',$message);
     }

     
     function delete_procedure($post){
              
            $ip_obj=new Inpatient();
             
             $result=$ip_obj->deleteIPProcedure($post);

            if($result) { $message="Deleted Successfully!";}
            else  $message="Failed To Delete!";

             $this->viewPage('Bill_Procedure','','',$message);
     }
     function add_doctor_visit($post){
              
             $ip_obj=new Inpatient();           
             $db_function =new DBFunction();
             
             $post['amount']=0;
             if($post['visit_type'] == "E"){
              
                $post['amount']=$db_function->getidToValue("emergency_visit","emp_id",$post['doctor'],"hcare_doc_fee");

             }else if($post['visit_type'] == "V"){
       
               $post['amount']=$db_function->getidToValue("ip_visit","emp_id",$post['doctor'],"hcare_doc_fee");

             }else if($post['visit_type'] == "S"){

               $post['amount']=$db_function->getidToValue("surgery_charge","emp_id",$post['doctor'],"hcare_doc_fee");
             }
           
                $result = $ip_obj->add_doctor_visit($post);

            if($result) { $message="Added Successfully!";}
            else  $message="Failed To Add!";

             $this->viewPage('Doctor_Visit','','',$message);
     }

     
     function delete_doctor_visit($post){
             $ip_obj=new Inpatient(); 
             
             $result=$ip_obj->delete_doctor_visit($post);

            if($result) { $message="Deleted Successfully!";}
            else  $message="Failed To Delete!";

             $this->viewPage('Doctor_Visit','','',$message);
     }
    function add_nursing_notes($post){
              
             $ip_obj=new Inpatient();
             $result = $ip_obj->add_nursing_notes($post);

            if($result) { $message="Added Successfully!";}
            else  $message="Failed To Add!";

             $this->viewPage('Nursing_Notes','','',$message);
     }

     
     function delete_nursing_notes($post){
             $ip_obj=new Inpatient();              
             $result=$ip_obj->delete_nursing_notes($post);

            if($result) { $message="Deleted Successfully!";}
            else  $message="Failed To Delete!";

             $this->viewPage('Nursing_Notes','','',$message);
     }
	
}



?>
