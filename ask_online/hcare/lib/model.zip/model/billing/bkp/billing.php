<?php session_start();
require_once ROOT_PATH . '/lib/confs/DMLFunctions.php';
require_once ROOT_PATH . '/lib/confs/config.php';


class Billing{

	
	
	function Billing(){
		$conf=new Config();
		$this->dbConnection=new DMLFunctions($conf);
	}
	
	function addCustomer($post){
	
		$field_names=array("id","name","age","gender","place","contact_no","refferal_info");
		$field_data=array("",$post['name'],$post['age'],$post['gender'],$post['place'],$post['contact_no'],$post['refferal_info']);
		
		$result=$this->dbConnection->insert($field_names,$field_data,"hcare_direct_customer");
		
		if($result) return mysql_insert_id();
		else return 0;
	}
	function addCredit($post){
	
		$field_names=array("id","bill_no","bill_date","amount","user_id");
		$field_data=array("",$post['billid'],date('Y-m-d',strtotime($post['new_date'])),$post['amount_paid'],$_SESSION['user_id']);
		
		$result=$this->dbConnection->insert($field_names,$field_data,"hcare_bill_payments");
		
		if($result) return mysql_insert_id();
		else return 0;
	}
	function updateCustomer($post){
	
			$id=$post['id'];
			
		$field_names=array("name","age","gender","place","contact_no","refferal_info");
		$field_data=array($post['name'],$post['age'],$post['gender'],$post['place'],$post['contact_no'],$post['refferal_info']);
			
	
	
		$result=$this->dbConnection->update($field_names,$field_data,"id",$id,"hcare_direct_customer");
		
		if($result) return $id;
		else return 0;
	}
	function addtoBill($post){
	
		if(!empty($post['card_amount'])){
			$credit_card=$post['card_amount'];
		}else $credit_card=0;
		
		if(!empty($post['ins_deduction'])){
			$ins_deduction=$post['ins_deduction'];
		}else $ins_deduction=0;
		
		
		$amount_paid=$post['amount_paid']+$credit_card+$ins_deduction;
		$credit=$post['net_amount']-$amount_paid;
	
		$field_names=array("id","type","ref_no","total_amount","dr_disc","net_total","paid_with","cash","credit","credit_card","insurance","bill_date","remarks","user_id","opno");
		$field_data=array("",$post['type'],$post['id'],$post['total_amount'],$post['dr_disc'],$post['net_amount'],$post['payment_mode'],$post['amount_paid'],$credit,$credit_card,$ins_deduction,date("Y-m-d",strtotime($post['date'])),$post['remarks'],$_SESSION['user_id'],$post['opno']);
		
		$result=$this->dbConnection->insert($field_names,$field_data,"hcare_bill");
		
		if($result) return mysql_insert_id();
		else return 0;
	
	}
	function updateBill($post){
	
			$id=$post['billid'];
			
		if(!empty($post['card_amount'])){
			$credit_card=$post['card_amount'];
		}else $credit_card=0;		
		
		if(!empty($post['ins_deduction'])){
			$ins_deduction=$post['ins_deduction'];
		}else $ins_deduction=0;
		
		
		$amount_paid=$post['amount_paid']+$credit_card+$ins_deduction;
		$credit=$post['net_amount']-$amount_paid;
	
		$field_names=array("type","ref_no","total_amount","dr_disc","net_total","paid_with","cash","credit","credit_card","insurance","bill_date","remarks");
		$field_data=array($post['type'],$post['id'],$post['total_amount'],$post['dr_disc'],$post['net_amount'],$post['payment_mode'],$post['amount_paid'],$credit,$credit_card,$ins_deduction,date("Y-m-d",strtotime($post['date'])),$post['remarks']);
			
	
	
		$result=$this->dbConnection->update($field_names,$field_data,"id",$id,"hcare_bill");
		
		if($result) return $id;
		else return 0;
	}
	function addToBillItems($bill_id,$items,$post){
	
		
		$discount=$items[2]-$items[5];
		$field_names=array("id","bill_id","bill_date","type","test_type","test_id","category_id","test_amount","discount_type","discount_value","discount","net_amount");
		$field_data=array("",$bill_id,date("Y-m-d",strtotime($post['date'])),$items[6],$items[8],$items[0],$items[7],$items[2],$items[3],$items[4],$discount,$items[5]);
		
		$result=$this->dbConnection->insert($field_names,$field_data,"hcare_bill_items");
		
		if($result) return mysql_insert_id();
		else return 0;
	}
	function deleteBillItems($post){
	
		$id=$post['billid'];
		$where[0]="bill_id ='".$id."'";
		$result=$this->dbConnection->deletePermenantly($where,"hcare_bill_items");
		
		if($result) return true;
		else return false;
	}
	public function getCreditBillInfo($wheredata){
	
		$arrList='';
		$i=0;
		$query=$this->dbConnection->BuiltQuery('hcare_bill_payments','',$wheredata,'id','asc');	
		$result=$this->dbConnection->executeQuery($query);
		
		if(mysql_num_rows($result) > 0){
			
			while($row=mysql_fetch_assoc($result)){
			
				$arrList[$i][0]=$row['id'];
				$arrList[$i][1]=$row['bill_no'];
				$arrList[$i][2]=$row['bill_date'];
				$arrList[$i][3]=$row['amount'];
				$arrList[$i][4]=$row['user_id'];
				
				$i++;
			}
			
		}
		
		return $arrList;
	
	}
		 	 	 	 	 	 	 	 	 	 	  	 	 	 	 	 	 	 	
	public function getfullCreditInfo($wheredata){   
	
				$arrFieldList[0]= "a.`id`";
				$arrFieldList[1]= "a.`type`";
				$arrFieldList[2]= "a.`ref_no`";
				$arrFieldList[3]= "a.`total_amount`";
				$arrFieldList[4]= "a.`dr_disc`";
				$arrFieldList[5]= "a.`net_total`";
				$arrFieldList[6]= "a.`paid_with`";
				$arrFieldList[7]= "a.`cash`";
				$arrFieldList[8]= "a.`credit`";
				$arrFieldList[9]= "a.`credit_card`";
				$arrFieldList[10]= "a.`insurance`";
				$arrFieldList[11]= "a.`bill_date`";
				$arrFieldList[12]= "a.`remarks`";
				$arrFieldList[13]= "a.`user_id`";
				$arrFieldList[14]= "a.`status`";
				
				$arrFieldList[15]= "b.`id`";
				$arrFieldList[16]= "b.`bill_no`";
				$arrFieldList[17]= "b.`bill_date`";
				$arrFieldList[18]= "b.`amount`";
				$arrFieldList[19]= "b.`user_id`";
				
				$arrTables[0] = "`hcare_bill` a";
       			$arrTables[1] = "`hcare_bill_payments` b";
				
				$joinConditions[1] = "a.`id` = b.`bill_no`";
				
				if(!empty($wheredata)) {
					for($k=0;$k<count($wheredata);$k++){
					
						$selectConditions[]=$wheredata[$k];
					}
				}
				
        		$query=$this->dbConnection->selectFromMultipleTable($arrFieldList, $arrTables, $joinConditions,$selectConditions);
			
				$result=$this->dbConnection->executeQuery($query);
				$i=0;
				
				if(mysql_num_rows($result)>0){
								$i=0;
						while($row=mysql_fetch_array($result)){
									
								for($k=0;$k<count($arrFieldList);$k++) {						
								
									$arrList[$i][$k]=$row[$k];
								}
								$i++;
						
						}
				
				}
			return $arrList;
				
				
				
	}
	function getBillInfoAllField($wheredata = null ,$orderbyfield = null,$oderby = null,$credit = false){
	
				$arrFieldList[0]= "a.`id`";
				$arrFieldList[1]= "a.`type`";
				$arrFieldList[2]= "a.`ref_no`";
				$arrFieldList[3]= "a.`total_amount`";
				$arrFieldList[4]= "a.`dr_disc`";
				$arrFieldList[5]= "a.`net_total`";
				$arrFieldList[6]= "a.`paid_with`";
				$arrFieldList[7]= "a.`cash`";
				$arrFieldList[8]= "a.`credit`";
				$arrFieldList[9]= "a.`credit_card`";
				$arrFieldList[10]= "a.`insurance`";
				$arrFieldList[11]= "a.`bill_date`";
				$arrFieldList[12]= "a.`remarks`";
				$arrFieldList[13]= "a.`user_id`";
				$arrFieldList[14]= "a.`status`";
				$arrFieldList[15]= "a.`lab_status`";
				$arrFieldList[16]= "b.`id`";
				$arrFieldList[17]= "b.`first_name`";
				$arrFieldList[18]= "b.`middle_name`";
				$arrFieldList[19]= "b.`last_name`";
				$arrFieldList[20]= "b.`age`";
				$arrFieldList[21]= "b.`gender`";
				$arrFieldList[22]= "b.`place`";
				$arrFieldList[23]= "b.`contact_no`";
				$arrFieldList[24]= "c.`name`";
				$arrFieldList[25]= "c.`age`";
				$arrFieldList[26]= "c.`gender`";
				$arrFieldList[27]= "c.`place`";
				$arrFieldList[28]= "c.`contact_no`";
				$arrFieldList[29]= "c.`refferal_info`";
				
				$arrTables[0] = "`hcare_bill` a";
       			$arrTables[1] = "`hcare_op_patient_info` b";
       			$arrTables[2] = "`hcare_direct_customer` c";				    
					
				$joinConditions[1] = "a.`opno` = b.`id`";
        		$joinConditions[2] = "a.`ref_no` = c.`id`";
					
				
				
				$orderbyfield="a.id";
				$orderby="asc";
				
				$query=$this->dbConnection->selectFromMultipleTable($arrFieldList, $arrTables, $joinConditions, $wheredata,'',$orderbyfield,$oderby);
				
				$result=$this->dbConnection->executeQuery($query);
				
				if(mysql_num_rows($result)>0){
								$i=0;
						while($row=mysql_fetch_array($result)){
						
						
							//Calculating Credit Balance amount
							$data=true;
							$where[0]="bill_no='".$row[0]."'";
							$creditInfo=$this->getCreditBillInfo($where);

							$creditPayment=0;
							if(!empty($creditInfo)){
					 
								for($k=0;$k<count($creditInfo);$k++){
					
									$creditPayment=$creditPayment+$creditInfo[$k][3];
								}
							}
				
							$credit_amount=$row['credit']-$creditPayment;
							
							if($credit == true && $credit_amount <= 0){ 
				 				$data=false; 
							}
			
							if($data) {		
								$arrList[$i][0]=$row[0];
								$arrList[$i][1]=$row[1];
								$arrList[$i][2]=$row[2];
				
								if($row[1] == "OP"){
					
									$opno=$this->dbConnection->idToValue("hcare_op_visit_info","opno","id",$row[2]);
					
									$arrList[$i][3]=$row[17]." ".$row[18]." ".$row[19];
					
									$arrList[$i][4]=$row[20];
									$arrList[$i][5]=$row[21];
									$arrList[$i][6]=$row[22];
									$arrList[$i][7]=$row[23];
									
									//get doc id from patient visit info
									$doc_id=$this->dbConnection->idToValue("hcare_op_visit_info","doc_id","id",$row[2]);	
													
									$arrList[$i][8]=$this->dbConnection->idToValue("hcare_emp_info","title","id",$doc_id)." ".$this->dbConnection->idToValue("hcare_emp_info","first_name","id",$doc_id)." ".$this->dbConnection->idToValue("hcare_emp_info","last_name","id",$doc_id);
									
								}else{
				
									$opno=$row[2];
									$arrList[$i][3]=$row[24];
					
									$arrList[$i][4]=$row[25];
									$arrList[$i][5]=$row[26];
									$arrList[$i][6]=$row[27];
									$arrList[$i][7]=$row[28];			
									$arrList[$i][8]=$row[29];
								}
				
								$arrList[$i][9]=$row[3];
								$arrList[$i][10]=$row[4];
								$arrList[$i][11]=$row[5];
								$arrList[$i][12]=$row[6];
								$arrList[$i][13]=$row[7]+$creditPayment;
								$arrList[$i][14]=$row[8]-$creditPayment;
								$arrList[$i][15]=$row[9];
								$arrList[$i][16]=$row[11];
								$arrList[$i][17]=$row[12];
								$arrList[$i][18]=$row[13];
								$arrList[$i][19]=$opno;
								$arrList[$i][20]=$row[10];
								$arrList[$i][21]=$row[8];
								$arrList[$i][22]=$row[14];
								$i++;
								
							}
			
								
						}
				
				}
			return $arrList;
				
	}
	function getBillInfo($wheredata = null ,$orderbyfield = null,$oderby = null,$credit = false ){
	
		$arrList='';
		$i=0;
		$data=true;
		$query=$this->dbConnection->BuiltQuery('hcare_bill','',$wheredata,'id','asc');	
		$result=$this->dbConnection->executeQuery($query);
		//echo $query;
		if(mysql_num_rows($result) > 0){
			$p=1;
			while($row=mysql_fetch_assoc($result)){
			$data=true;
				$where[0]="bill_no='".$row['id']."'";
				$creditInfo=$this->getCreditBillInfo($where);

				$creditPayment=0;
				if(!empty($creditInfo)){
					 
					for($k=0;$k<count($creditInfo);$k++){
					
						$creditPayment=$creditPayment+$creditInfo[$k][3];
					}
				}
				
				$credit_amount=$row['credit']-$creditPayment;
				if($credit == true && $credit_amount <= 0){ 
				 $data=false; 
				}
			
			if($data){
				$arrList[$i][0]=$row['id'];
				$arrList[$i][1]=$row['type'];
				$arrList[$i][2]=$row['ref_no'];
				
				if($row['type'] == "OP"){
					
					$opno=$this->dbConnection->idToValue("hcare_op_visit_info","opno","id",$row['ref_no']);
					
				$arrList[$i][3]=$this->dbConnection->idToValue("hcare_op_patient_info","first_name","id",$opno)." ".$this->dbConnection->idToValue("hcare_op_patient_info","middle_name","id",$opno)." ".$this->dbConnection->idToValue("hcare_op_patient_info","last_name","id",$opno);
					
					$arrList[$i][4]=$this->dbConnection->idToValue("hcare_op_patient_info","age","id",$opno);
					$arrList[$i][5]=$this->dbConnection->idToValue("hcare_op_patient_info","gender","id",$opno);
					$arrList[$i][6]=$this->dbConnection->idToValue("hcare_op_patient_info","place","id",$opno);
					$arrList[$i][7]=$this->dbConnection->idToValue("hcare_op_patient_info","contact_no","id",$opno);
					$doc_id=$this->dbConnection->idToValue("hcare_op_visit_info","doc_id","id",$row['ref_no']);					
					$arrList[$i][8]=$this->dbConnection->idToValue("hcare_emp_info","title","id",$doc_id)." ".$this->dbConnection->idToValue("hcare_emp_info","first_name","id",$doc_id)." ".$this->dbConnection->idToValue("hcare_emp_info","last_name","id",$doc_id);
				}else{
				
					$opno=$row['ref_no'];
					$arrList[$i][3]=$this->dbConnection->idToValue("hcare_direct_customer","name","id",$row['ref_no']);
					
					$arrList[$i][4]=$this->dbConnection->idToValue("hcare_direct_customer","age","id",$row['ref_no']);
					$arrList[$i][5]=$this->dbConnection->idToValue("hcare_direct_customer","gender","id",$row['ref_no']);
					$arrList[$i][6]=$this->dbConnection->idToValue("hcare_direct_customer","place","id",$row['ref_no']);
					$arrList[$i][7]=$this->dbConnection->idToValue("hcare_direct_customer","contact_no","id",$row['ref_no']);				
					$arrList[$i][8]=$this->dbConnection->idToValue("hcare_direct_customer","refferal_info","id",$row['ref_no']);
				}
				
				$arrList[$i][9]=$row['total_amount'];
				$arrList[$i][10]=$row['dr_disc'];
				$arrList[$i][11]=$row['net_total'];
				$arrList[$i][12]=$row['paid_with'];
				$arrList[$i][13]=$row['cash']+$creditPayment;
				$arrList[$i][14]=$row['credit']-$creditPayment;
				$arrList[$i][15]=$row['credit_card'];
				$arrList[$i][16]=$row['bill_date'];
				$arrList[$i][17]=$row['remarks'];
				$arrList[$i][18]=$row['user_id'];
				$arrList[$i][19]=$opno;
				$arrList[$i][20]=$row['insurance'];
				$arrList[$i][21]=$row['credit'];
				$arrList[$i][22]=$row['lab_status'];
				$i++;
			}
			}
		
		}
	
		return $arrList;
	}
	
	public function getBillItemsInfo($wheredata){
	
		$arrList='';
		$i=0;
		$query=$this->dbConnection->BuiltQuery('hcare_bill_items','',$wheredata,'id','asc');	
		$result=$this->dbConnection->executeQuery($query);
		
		if(mysql_num_rows($result) > 0){
			
			while($row=mysql_fetch_assoc($result)){
				
				$arrList[$i][0]=$row['id'];
				$arrList[$i][1]=$row['bill_id'];
				$arrList[$i][2]=$row['bill_date'];
				$arrList[$i][3]=$row['type'];
				$arrList[$i][4]=$row['test_id'];
				
				if($row['type'] == "C") {
				
					$arrList[$i][5]="Consultation";
					
				}else if($row['type'] == "P") {
				
					$arrList[$i][5]=$this->dbConnection->idToValue("hcare_procedure","procedure_test","id",$row['test_id']);
					
				}else if($row['type'] == "L") {
				
					$cid=$row['category_id'];
					$check_catid=$this->dbConnection->idToValue("hcare_lab_test","catId","id",$row['test_id']);
					if($cid == $check_catid){
						$arrList[$i][5]=$this->dbConnection->idToValue("hcare_lab_test","testName","id",$row['test_id']);
					}else {
						$arrList[$i][5]=$this->dbConnection->idToValue("hcare_lab_element","test_name","id",$row['test_id']);
					}
				}
				$arrList[$i][6]=$row['category_id'];
				$arrList[$i][7]=$row['test_amount'];
				$arrList[$i][8]=$row['discount_type'];
				$arrList[$i][9]=$row['discount_value'];
				$arrList[$i][10]=$row['discount'];
				$arrList[$i][11]=$row['net_amount'];
				
				$i++;
			}
		}
		return $arrList;
	}
	function cancelBill($post){
	
		$id=$post['id'];
		
		$field_names1=array('status');
		$field_data=array('1');
		
		$result=$this->dbConnection->update($field_names1,$field_data,"id",$id,"hcare_bill");
		
		if($result) return true;
		else return false;
	}
	function cancelBillItems($post){
	
		$id=$post['id'];
		
		$field_names1=array('status');
		$field_data=array('1');
		
		$result=$this->dbConnection->update($field_names1,$field_data,"bill_id",$id,"hcare_bill_items");
		
		if($result) return true;
		else return false;
	}
	/*function addPatientinfo($post){
	
			$age=$post['age']." ".$post['age_type'];
			$dob = date("Y-m-d",strtotime($post['dob']));
			
			$field_names=array("id","first_name","middle_name","last_name","age","dob","gender","marital_status","place","nationality","contact_no","email");
			
			$field_data=array("",$post['first_name'],$post['middle_name'],$post['last_name'],$age,$dob,$post['gender'],$post['marital_status'],$post['place'],$post['nationality'],$post['contact_no'],$post['email']);
	
		$result=$this->dbConnection->insert($field_names,$field_data,"hcare_op_patient_info");
		
		if($result) return mysql_insert_id();
		else return 0;
	}
	function updatePatientinfo($post){
	
			$id=$post['opno'];
			$field_names=array("first_name","middle_name","last_name","age","dob","gender","marital_status","place","nationality","contact_no","email");
			$field_data=array($post['first_name'],$post['middle_name'],$post['last_name'],$post['age']." ".$post['age_type'],$post['dob'],$post['gender'],$post['marital_status'],$post['place'],$post['nationality'],$post['contact_no'],$post['email']);
			
	
	
		$result=$this->dbConnection->update($field_names,$field_data,"id",$id,"hcare_op_patient_info");
		
		if($result) return $id;
		else return 0;
	}
	function addVisitInfo($post){
	
			if(!empty($post['bk_id'])){
				$reg_from = "Booking";
			}else $reg_from ="Registration";
	
			$field_names=array("id","opno","doc_id","doc_fee","reg_fee","visit_time","visit_date","validity_expiry","insurance_company","policy_no","claim_no","company_name","company_id","relation","ins_date_issue","ins_date_expiry","cons_disc_amt","visit_status","remarks","refferal_info","user_id","token_no","reg_from","mlc_summary","op_reset_no");
			if(!empty($post['date_issue'])){
				$post['date_issue']=date("Y-m-d",strtotime($post['date_issue']));
				$post['date_expiry']=date("Y-m-d",strtotime($post['date_expiry']));
			}
			
			$field_data=array("",$post['opno'],$post['doctor'],$post['docfee'],$post['regfee'],$post['visit_time'],$post['visit_date'],$post['validity'],$post['insurance_company'],$post['policy_no'],$post['claim'],$post['company_name'],$post['company_id'],$post['relation'],$post['date_issue'],$post['date_expiry'],$post['cons_disc_amt'],$post['status'],$post['remarks'],$post['refferal_info'],$_SESSION['user_id'],$post['token'],$reg_from,$post['mlc_summary'],$post['reset_op_no']);
			
			$result=$this->dbConnection->insert($field_names,$field_data,"hcare_op_visit_info");
			
			if($result) return mysql_insert_id();
			else return 0;
			
	}
	function updateVisitInfo($post){
	
			$id=$post['id'];
			
			$field_names=array("doc_id","doc_fee","reg_fee","visit_time","visit_date","validity_expiry","insurance_company","policy_no","claim_no","company_name","company_id","relation","ins_date_issue","ins_date_expiry","cons_disc_amt","visit_status","remarks","refferal_info","user_id","mlc_summary");
			if(!empty($post['date_issue'])){
				$post['date_issue']=date("Y-m-d",strtotime($post['date_issue']));
				$post['date_expiry']=date("Y-m-d",strtotime($post['date_expiry']));
			}
			
			$field_data=array($post['doctor'],$post['docfee'],$post['regfee'],$post['visit_time'],$post['visit_date'],$post['validity'],$post['insurance_company'],$post['policy_no'],$post['claim'],$post['company_name'],$post['company_id'],$post['relation'],$post['date_issue'],$post['date_expiry'],$post['cons_disc_amt'],$post['status'],$post['remarks'],$post['refferal_info'],$_SESSION['user_id'],$post['mlc_summary']);
			
			
			$result=$this->dbConnection->update($field_names,$field_data,"id",$id,"hcare_op_visit_info");
			
			if($result) return $id;
			else return 0;
			
	}
	function deletePatientVisit($post){
		$id=$post['id'];
		$where[0]="id= '".$id."'";
		$result=$this->dbConnection->deletePermenantly($where,"hcare_op_visit_info");
	}
	
	function getOPPatientInfo($selectfield = null,$selectCondition = null ,$orderbyfield = null,$oderby = null ){
	
				$arrList='';
			if(empty($selectfield)) {
			
				$arrFieldList[0]= "a.`id`";
				$arrFieldList[1]= "a.`first_name`";
				$arrFieldList[2]= "a.`middle_name`";
				$arrFieldList[3]= "a.`last_name`";
				$arrFieldList[4]= "a.`age`";
				$arrFieldList[5]= "a.`dob`";
				$arrFieldList[6]= "a.`gender`";
				$arrFieldList[7]= "a.`marital_status`";
				$arrFieldList[8]= "a.`place`";
				$arrFieldList[9]= "a.`nationality`";
				$arrFieldList[10]= "a.`contact_no`";
				$arrFieldList[11]= "a.`email`";
				$arrFieldList[12]= "a.`status`";
				$arrFieldList[13]= "b.`id`";
				$arrFieldList[14]= "b.`doc_id`";
				$arrFieldList[15]= "c.`first_name`";
				$arrFieldList[16]= "c.`last_name`";
				$arrFieldList[17]= "b.`doc_fee`";
				$arrFieldList[18]= "b.`reg_fee`";
				$arrFieldList[19]= "b.`visit_time`";
				$arrFieldList[20]= "b.`visit_date`";
				$arrFieldList[21]= "b.`validity_expiry`";
				$arrFieldList[22]= "b.`insurance_company`";
				$arrFieldList[23]= "d.`insurance_company`";
				$arrFieldList[24]= "b.`policy_no`";
				$arrFieldList[25]= "b.`claim_no`";
				$arrFieldList[26]= "b.`company_name`";
				$arrFieldList[27]= "b.`company_id`";
				$arrFieldList[28]= "b.`relation`";
				$arrFieldList[29]= "b.`ins_date_issue`";
				$arrFieldList[30]= "b.`ins_date_expiry`";
				$arrFieldList[31]= "b.`cons_disc_amt`";
				$arrFieldList[32]= "b.`visit_status`";
				$arrFieldList[33]= "b.`remarks`";
				$arrFieldList[34]= "b.`refferal_info`";
				$arrFieldList[35]= "b.`user_id`";
				$arrFieldList[36]= "b.`token_no`";
				$arrFieldList[37]= "b.`reg_from`";
				$arrFieldList[38]= "b.`mlc_summary`";
				$arrFieldList[39]= "b.`op_reset_no`";
				$arrFieldList[40]= "b.`paid_status`";
			}else {
			
				for($k=0;$k<count($selectfield);$k++){
					
						$arrFieldList[]=$selectfield[$k];
					}
			
			}
			
			 		$arrTables[0] = "`hcare_op_patient_info` a";
       			    $arrTables[1] = "`hcare_op_visit_info` b";
       			    $arrTables[2] = "`hcare_emp_info` c";
				    $arrTables[3] = "`hcare_insurance_company` d";
					
					$joinConditions[1] = "a.`id` = b.`opno`";
        		    $joinConditions[2] = "b.`doc_id` = c.`id`";
					$joinConditions[3] = "b.`insurance_company` = d.`id`";
					
					if(!empty($selectCondition)) {
					for($k=0;$k<count($selectCondition);$k++){
					
						$selectConditions[]=$selectCondition[$k];
					}
				}
				$selectConditions[]="a.`status`=0";
				$query=$this->dbConnection->selectFromMultipleTable($arrFieldList, $arrTables, $joinConditions, $selectConditions,'',$orderbyfield,$oderby);
				
				$result=$this->dbConnection->executeQuery($query);
				
				if(mysql_num_rows($result)>0){
								$i=0;
						while($row=mysql_fetch_array($result)){
									
								for($k=0;$k<count($arrFieldList);$k++) {						
								
									$arrList[$i][$k]=$row[$k];
								}
								$i++;
						
						}
				
				}
			return $arrList;
	}
*/
	
}
?>
