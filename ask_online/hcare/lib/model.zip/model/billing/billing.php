﻿<?php session_start();
require_once ROOT_PATH . '/lib/confs/DMLFunctions.php';
require_once ROOT_PATH . '/lib/confs/config.php';


class Billing{

	
	
	function Billing(){
		$conf=new Config();
		$this->dbConnection=new DMLFunctions($conf);
	}
	
	function addCustomer($post){
	
		$field_names=array("id","name","age","gender","place","contact_no","refferal_info");
		$field_data=array("",$post['name'],$post['age'],$post['gender'],$post['place'],$post['contact_no'],$post['refferal_info']);
		
		$result=$this->dbConnection->insert($field_names,$field_data,"hcare_direct_customer");
		
		if($result) return mysql_insert_id();
		else return 0;
	}
	function addCredit($post){
	
		$field_names=array("id","bill_no","bill_date","amount","user_id");
		$field_data=array("",$post['billid'],date('Y-m-d',strtotime($post['new_date'])),$post['amount_paid'],$_SESSION['user_id']);
		
		$result=$this->dbConnection->insert($field_names,$field_data,"hcare_bill_payments");
		
		if($result) return mysql_insert_id();
		else return 0;
	}
	function updateCustomer($post){
	
			$id=$post['id'];
			
		$field_names=array("name","age","gender","place","contact_no","refferal_info");
		$field_data=array($post['name'],$post['age'],$post['gender'],$post['place'],$post['contact_no'],$post['refferal_info']);
			
	
	
		$result=$this->dbConnection->update($field_names,$field_data,"id",$id,"hcare_direct_customer");
		
		if($result) return $id;
		else return 0;
	}
	function addUpdateHistory($post,$netamt){
		
			$field_names=array("bill_id","updated_on","test_id","test_type","amount","bill_amt_bef","bill_amt_aft","action","user_id");
			
			for($i=0;$i<count($_SESSION["items_updated"]);$i++){
			
				$items_in_array=explode("!$%",$_SESSION["items_updated"][$i]);
				
				if($items_in_array[3] == "Removed"){
					$netamt_aft=$netamt-$items_in_array[1];
				}else{
					$netamt_aft=$netamt+$items_in_array[1];
				}
				
				$field_data=array($post['billid'],date("Y-m-d"),$items_in_array[0],$items_in_array[2],$items_in_array[1],$netamt,$netamt_aft,$items_in_array[3],$_SESSION['user_id']);
				
				$result=$this->dbConnection->insert($field_names,$field_data,"hcare_bill_updations");
				
				$netamt=$netamt_aft;
			
			} 
	}
	function addtoBill($post){
	
		if(!empty($post['card_amount'])){
			$credit_card=$post['card_amount'];
		}else $credit_card=0;
		
		if(!empty($post['ins_deduction'])){
			$ins_deduction=$post['ins_deduction'];
		}else $ins_deduction=0;
		
		
		$amount_paid=$post['amount_paid']+$credit_card+$ins_deduction;
		$credit=$post['net_amount']-$amount_paid;
	
		$field_names=array("id","type","ref_no","total_amount","dr_disc","net_total","paid_with","cash","credit","credit_card","insurance","bill_date","remarks","user_id","opno");
		$field_data=array("",$post['type'],$post['id'],$post['total_amount'],$post['dr_disc'],$post['net_amount'],$post['payment_mode'],$post['amount_paid'],$credit,$credit_card,$ins_deduction,date("Y-m-d",strtotime($post['date'])),$post['remarks'],$_SESSION['user_id'],$post['opno']);
		
		$result=$this->dbConnection->insert($field_names,$field_data,"hcare_bill");
		
		if($result) return mysql_insert_id();
		else return 0;
	
	}
	function add_advance_payment($post){
	
	    
	
	    $field_names=array("id","ipno","payment_mode","cash","card_amount","cheque_no","date",remarks,user_id);
	    $field_data=array("",$post["id"],$post["payment_mode"],$post["advance_amount"],$post["card_amount"],$post["cheque_no"],$post['curr_date_time'],$post['remarks'],$_SESSION['user_id']);
	    
	    $result=$this->dbConnection->insert($field_names,$field_data,"hcare_advance_payments");
		
	   if($result) return mysql_insert_id();
	   else return 0;
	
	}
	function add_ip_bill($post){
	
	   $field_names=array("id", "ipno", "bill_date", "bill_time", "total_amount", "amount_paid", "disc_type", "disc_amt", "balance", "payment_mode", "amount", "card_amount", "cheque_no", "remarks","user_id");
	   
	    $field_data=array("", $post['id'], $post['curr_date'],$post['curr_time'], $post['total_amount'], $post['amount_paid'], $post['disc_type'], $post['discount'], $post['balance'], $post['payment_mode'], $post['final_amount'], $post['card_amount'],$post['cheque_no'], $post['remarks'],$_SESSION['user_id']);
	    
	    
	    $result=$this->dbConnection->insert($field_names,$field_data,"hcare_ip_bill");
		
		if($result) return mysql_insert_id();
		else return 0;
	  
	
	}
	
	function add_ip_bill_items($billid,$items,$particulars){
	
	
	
	   $field_names=array("id", "billno", "particulars", "amount");
	   $field_data=array("", $billid, $particulars, $items);
	   
	   
	   $result=$this->dbConnection->insert($field_names,$field_data,"hcare_ip_bill_items");
		
		if($result) return mysql_insert_id();
		else return 0;
	
	}
	function updateBill($post){
	
			$id=$post['billid'];
			
		if(!empty($post['card_amount'])){
			$credit_card=$post['card_amount'];
		}else $credit_card=0;		
		
		if(!empty($post['ins_deduction'])){
			$ins_deduction=$post['ins_deduction'];
		}else $ins_deduction=0;
		
		
		$amount_paid=$post['amount_paid']+$credit_card+$ins_deduction;
		$credit=$post['net_amount']-$amount_paid;
	
		$field_names=array("type","ref_no","total_amount","dr_disc","net_total","paid_with","cash","credit","credit_card","insurance","bill_date","remarks");
		$field_data=array($post['type'],$post['id'],$post['total_amount'],$post['dr_disc'],$post['net_amount'],$post['payment_mode'],$post['amount_paid'],$credit,$credit_card,$ins_deduction,date("Y-m-d",strtotime($post['date'])),$post['remarks']);
			
	
	
		$result=$this->dbConnection->update($field_names,$field_data,"id",$id,"hcare_bill");
		
		if($result) return $id;
		else return 0;
	}
	function addToBillItems($bill_id,$items,$post){
	
		
		$discount=$items[2]-$items[5];
		$field_names=array("id","bill_id","bill_date","type","test_type","test_id","category_id","test_amount","discount_type","discount_value","discount","net_amount");
		$field_data=array("",$bill_id,date("Y-m-d",strtotime($post['date'])),$items[6],$items[8],$items[0],$items[7],$items[2],$items[3],$items[4],$discount,$items[5]);
		
		$result=$this->dbConnection->insert($field_names,$field_data,"hcare_bill_items");
		
		if($result) return mysql_insert_id();
		else return 0;
	}
	function deleteBillItems($post){
	
		$id=$post['billid'];
		$where[0]="bill_id ='".$id."'";
		$result=$this->dbConnection->deletePermenantly($where,"hcare_bill_items");
		
		if($result) return true;
		else return false;
	}
	public function getCreditBillInfo($wheredata){
	
		$arrList='';
		$i=0;
		$query=$this->dbConnection->BuiltQuery('hcare_bill_payments','',$wheredata,'id','asc');	
		$result=$this->dbConnection->executeQuery($query);
		
		if(mysql_num_rows($result) > 0){
			
			while($row=mysql_fetch_assoc($result)){
			
				$arrList[$i][0]=$row['id'];
				$arrList[$i][1]=$row['bill_no'];
				$arrList[$i][2]=$row['bill_date'];
				$arrList[$i][3]=$row['amount'];
				$arrList[$i][4]=$row['user_id'];
				
				$i++;
			}
			
		}
		
		return $arrList;
	
	}
	public function getIPBillInfo($wheredata=null){
	
		$arrList='';
		$i=0;
		$query=$this->dbConnection->BuiltQuery('hcare_ip_bill','',$wheredata,'id','asc');	
		$result=$this->dbConnection->executeQuery($query);
		
		if(mysql_num_rows($result) > 0){
			
			while($row=mysql_fetch_assoc($result)){
			
				$arrList[$i][0]=$row['id'];
				$arrList[$i][1]=$row['ipno'];
				$arrList[$i][2]=date("Y-m-d",strtotime($row['bill_date']));
				$arrList[$i][3]=$row['bill_time'];
				$arrList[$i][4]=$row['total_amount'];
				$arrList[$i][5]=$row['amount_paid'];
				$arrList[$i][6]=$row['disc_type'];
				$arrList[$i][7]=$row['disc_amt'];
				$arrList[$i][8]=$row['balance'];
				$arrList[$i][9]=$row['payment_mode'];
				$arrList[$i][10]=$row['amount'];
				$arrList[$i][11]=$row['card_amount'];
				$arrList[$i][12]=$row['cheque_no'];
				$arrList[$i][13]=$row['remarks'];
				$arrList[$i][14]=$row['user_id'];
				
				$opno= $this->dbConnection->idToValue("hcare_ip_info","opno","id",$row['ipno']);
				$room_id= $this->dbConnection->idToValue("hcare_ip_info","room_id","id",$row['ipno']);
                                $roomno= $this->dbConnection->idToValue("hcare_rooms","room_number","id",$room_id);
				
				
				$arrList[$i][15]=$this->dbConnection->idToValue("hcare_op_patient_info","first_name","id",$opno)." ".$this->dbConnection->idToValue("hcare_op_patient_info","middle_name","id",$opno)." ".$this->dbConnection->idToValue("hcare_op_patient_info","last_name","id",$opno);

                                $arrList[$i][16]=$roomno;
				
				$i++;
			}
			
		}
		
		return $arrList;
	
	}
	public function getIPBillItems($wheredata){
	
		$arrList='';
		$i=0;
		$query=$this->dbConnection->BuiltQuery('hcare_ip_bill_items','',$wheredata,'id','asc');	
		$result=$this->dbConnection->executeQuery($query);
		
		if(mysql_num_rows($result) > 0){
			
			while($row=mysql_fetch_assoc($result)){
			
				$arrList[$i][0]=$row['id'];
				$arrList[$i][1]=$row['billno'];
				$arrList[$i][2]=$row['particulars'];
				$arrList[$i][3]=$row['amount'];
				
				$i++;
			}
			
		}
		
		return $arrList;
	
	}
	function getAdvancePayments($wheredata){
	
		$arrList='';
		$i=0;
		$query=$this->dbConnection->BuiltQuery('hcare_advance_payments','',$wheredata,'id','asc');	
		$result=$this->dbConnection->executeQuery($query);
		
		if(mysql_num_rows($result) > 0){
			
			while($row=mysql_fetch_assoc($result)){
			
			
				$arrList[$i][0]=$row['id'];
				$arrList[$i][1]=$row['ipno'];
				$arrList[$i][2]=$row['payment_mode'];
				$arrList[$i][3]=$row['cash'];
				$arrList[$i][4]=$row['card_amount'];
				
				$arrList[$i][5]=$row['cheque_no'];
				$arrList[$i][6]=$row['date'];
				
				$arrList[$i][7]=$row['user_id'];
				
				
				
				$opno= $this->dbConnection->idToValue("hcare_ip_info","opno","id",$row['ipno']);
				$room_id= $this->dbConnection->idToValue("hcare_ip_info","room_id","id",$row['ipno']);
                                $roomno= $this->dbConnection->idToValue("hcare_rooms","room_number","id",$room_id);
				
				
				$arrList[$i][8]=$this->dbConnection->idToValue("hcare_op_patient_info","first_name","id",$opno)." ".$this->dbConnection->idToValue("hcare_op_patient_info","middle_name","id",$opno)." ".$this->dbConnection->idToValue("hcare_op_patient_info","last_name","id",$opno);

                                $arrList[$i][9]=$roomno;

                                $arrList[$i][10]=$row['remarks'];
                                $arrList[$i][11]=$row['user_id'];
				
				
				$i++;
			}
			
		}
		
		return $arrList;
	
	}
		 	 	 	 	 	 	 	 	 	 	  	 	 	 	 	 	 	 	
	public function getfullCreditInfo($wheredata){   
	
				$arrFieldList[0]= "a.`id`";
				$arrFieldList[1]= "a.`type`";
				$arrFieldList[2]= "a.`ref_no`";
				$arrFieldList[3]= "a.`total_amount`";
				$arrFieldList[4]= "a.`dr_disc`";
				$arrFieldList[5]= "a.`net_total`";
				$arrFieldList[6]= "a.`paid_with`";
				$arrFieldList[7]= "a.`cash`";
				$arrFieldList[8]= "a.`credit`";
				$arrFieldList[9]= "a.`credit_card`";
				$arrFieldList[10]= "a.`insurance`";
				$arrFieldList[11]= "a.`bill_date`";
				$arrFieldList[12]= "a.`remarks`";
				$arrFieldList[13]= "a.`user_id`";
				$arrFieldList[14]= "a.`status`";
				
				$arrFieldList[15]= "b.`id`";
				$arrFieldList[16]= "b.`bill_no`";
				$arrFieldList[17]= "b.`bill_date`";
				$arrFieldList[18]= "b.`amount`";
				$arrFieldList[19]= "b.`user_id`";
				
				$arrTables[0] = "`hcare_bill` a";
       			        $arrTables[1] = "`hcare_bill_payments` b";
				
				$joinConditions[1] = "a.`id` = b.`bill_no`";
				
				if(!empty($wheredata)) {
					for($k=0;$k<count($wheredata);$k++){
					
						$selectConditions[]=$wheredata[$k];
					}
				}
				
        		$query=$this->dbConnection->selectFromMultipleTable($arrFieldList, $arrTables, $joinConditions,$selectConditions);
			
				$result=$this->dbConnection->executeQuery($query);
				$i=0;
				
				if(mysql_num_rows($result)>0){
								$i=0;
						while($row=mysql_fetch_array($result)){
									
								for($k=0;$k<count($arrFieldList);$k++) {						
								
									$arrList[$i][$k]=$row[$k];
								}
								if($row[1] == "OP" || $row[1] == "IP"){
								
								if($row[1] == "IP"){
					                             
					                               $opno=$this->dbConnection->idToValue("hcare_ip_info","opno","id",$row[2]);
					                        }else{
								        $opno=$this->dbConnection->idToValue("hcare_op_visit_info","opno","id",$row[2]);
								}
                                                                      
									$arrList[$i][$k++]=$this->dbConnection->idToValue("hcare_op_patient_info","first_name","id",$opno)." ".$this->dbConnection->idToValue("hcare_op_patient_info","middle_name","id",$opno)." ".$this->dbConnection->idToValue("hcare_op_patient_info","last_name","id",$opno);
								}else{
									$arrList[$i][$k++]=$this->dbConnection->idToValue("hcare_direct_customer","name","id",$row[2]);
                                                                       $opno=0;
								}
                                                               echo $arrList[$i][$k++]=$opno;
								
								$i++;
						
						}
				
				}
			return $arrList;
				
				
				
	}
	/*function getIPBillFieldInfo($selectField,$wheredata){
	
	           
		   
		   
		   $query=$this->dbConnection->BuiltQuery('hcare_bill',$selectField,$wheredata);	
		   $result=$this->dbConnection->executeQuery($query);
		   
		   $i=0;
		   
			if(mysql_num_rows($result) > 0){
			
			  while($row=mysql_fetch_assoc($result)){
			
			         for($k=0;$k<count($wheredata);$k++){
			         
			             $arrList[$i][$k]=$row[$selectField[$k]];
			         }
			         
			         $i++;
			   }
			}
			
			return $arrList;
	}*/
	
	
	function getBillConsoItems($wheredata = null ){
	
	
			$selectField[0]="sum(net_amount)";
			$selectField[1]="count(test_id)";
			$selectField[2]="type";
			$selectField[3]="test_id";
			$selectField[4]="test_type";
			$selectField[5]="category_id";
			
			$group_by[]="type";
			$group_by[]="test_id";
			$group_by[]="category_id";
			
			$query=$this->dbConnection->BuiltQuery('hcare_bill_items',$selectField,$wheredata,'id','asc',$group_by);	
			$result=$this->dbConnection->executeQuery($query);
			
			$i=0;
			if(mysql_num_rows($result) > 0){
			
			while($row=mysql_fetch_assoc($result)){
			
				$arrList[$i][0]=$row['sum(net_amount)'];
				$arrList[$i][1]=$row['count(test_id)'];
				$arrList[$i][2]=$row['type'];
				$arrList[$i][3]=$row['test_id'];
				$arrList[$i][4]=$row['test_type'];
				
				if($row['type'] == "C") {
				
					$arrList[$i][5]="Consultation";
					
				}else if($row['type'] == "P") {
				
					$arrList[$i][5]=$this->dbConnection->idToValue("hcare_procedure","procedure_test","id",$row['test_id']);
					
				}else if($row['type'] == "L") {
				
					$cid=$row['category_id'];
					$check_catid=$this->dbConnection->idToValue("hcare_lab_test","catId","id",$row['test_id']);
					if($cid == $check_catid){
						$arrList[$i][5]=$this->dbConnection->idToValue("hcare_lab_test","testName","id",$row['test_id']);
					}else {
						$arrList[$i][5]=$this->dbConnection->idToValue("hcare_lab_element","test_name","id",$row['test_id']);
					}
				}
				
				$i++;
			}
			
		}
		
		return $arrList;
	
	}
	function getBillItemPatient($wheredata = null,$groupby= null ){
	
	
	  $arrFieldList[0]= "a.`id`";
	  $arrFieldList[1]="sum(b.net_amount)";
	  $arrFieldList[2]="b.test_id";
	  $arrFieldList[3]="b.type";
	  
	  
	  $arrTables[0] = "`hcare_bill` a";
          $arrTables[1] = "`hcare_bill_items` b";
          
          $joinConditions[1] = "a.`id` = b.`bill_id`";
          
          
          $query=$this->dbConnection->selectFromMultipleTable($arrFieldList, $arrTables, $joinConditions, $wheredata,'',$orderbyfield,$oderby,'',$groupby);
				
	$result=$this->dbConnection->executeQuery($query);
				
				if(mysql_num_rows($result)>0){
								$i=0;
						while($row=mysql_fetch_array($result)){
						
						  $arrList[$i][0]=$row['sum(b.net_amount)'];
						  $arrList[$i][1]=$row['test_id'];
						  
						  
						  
						  if($row['type'] == "C") {
				
					               $arrList[$i][2]="Consultation";
					
				                 }else if($row['type'] == "P") {
				
					              $arrList[$i][2]=$this->dbConnection->idToValue("hcare_procedure","procedure_test","id",$row['test_id']);
					
				                  }else if($row['type'] == "L") {
				
					                   $cid=$row['category_id'];
					                   $check_catid=$this->dbConnection->idToValue("hcare_lab_test","catId","id",$row['test_id']);
					                   
					                   if($cid == $check_catid){
					                   
								$arrList[$i][2]=$this->dbConnection->idToValue("hcare_lab_test","testName","id",$row['test_id']);
							}else {
								$arrList[$i][2]=$this->dbConnection->idToValue("hcare_lab_element","test_name","id",$row['test_id']);
							}
						}
				
							$i++;
						
						}
						
			       }
			       
			       
			       return $arrList;
	
	}
	function getBillInfoAllField($wheredata = null ,$orderbyfield = null,$oderby = null,$credit = false){
	
				$arrFieldList[0]= "a.`id`";
				$arrFieldList[1]= "a.`type`";
				$arrFieldList[2]= "a.`ref_no`";
				$arrFieldList[3]= "a.`total_amount`";
				$arrFieldList[4]= "a.`dr_disc`";
				$arrFieldList[5]= "a.`net_total`";
				$arrFieldList[6]= "a.`paid_with`";
				$arrFieldList[7]= "a.`cash`";
				$arrFieldList[8]= "a.`credit`";
				$arrFieldList[9]= "a.`credit_card`";
				$arrFieldList[10]= "a.`insurance`";
				$arrFieldList[11]= "a.`bill_date`";
				$arrFieldList[12]= "a.`remarks`";
				$arrFieldList[13]= "a.`user_id`";
				$arrFieldList[14]= "a.`status`";
				$arrFieldList[15]= "a.`lab_status`";
				$arrFieldList[16]= "b.`id`";
				$arrFieldList[17]= "b.`first_name`";
				$arrFieldList[18]= "b.`middle_name`";
				$arrFieldList[19]= "b.`last_name`";
				$arrFieldList[20]= "b.`age`";
				$arrFieldList[21]= "b.`gender`";
				$arrFieldList[22]= "b.`place`";
				$arrFieldList[23]= "b.`contact_no`";
				$arrFieldList[24]= "c.`name`";
				$arrFieldList[25]= "c.`age`";
				$arrFieldList[26]= "c.`gender`";
				$arrFieldList[27]= "c.`place`";
				$arrFieldList[28]= "c.`contact_no`";
				$arrFieldList[29]= "c.`refferal_info`";
				$arrFieldList[30]= "a.`cancellation_details`";
				
				$arrTables[0] = "`hcare_bill` a";
       			        $arrTables[1] = "`hcare_op_patient_info` b";
       			        $arrTables[2] = "`hcare_direct_customer` c";	
       			       			    
					
				$joinConditions[1] = "a.`opno` = b.`id`";
        		        $joinConditions[2] = "a.`ref_no` = c.`id`";
        		         
					
				
				
				$orderbyfield="a.id";
				$orderby="asc";
				
				echo $query=$this->dbConnection->selectFromMultipleTable($arrFieldList, $arrTables, $joinConditions, $wheredata,'',$orderbyfield,$oderby);
				
				$result=$this->dbConnection->executeQuery($query);
				
				if(mysql_num_rows($result)>0){
								$i=0;
						while($row=mysql_fetch_array($result)){
						
						
							//Calculating Credit Balance amount
							$data=true;
							$where[0]="bill_no='".$row[0]."'";
							$creditInfo=$this->getCreditBillInfo($where);

							$creditPayment=0;
							if(!empty($creditInfo)){
					 
								for($k=0;$k<count($creditInfo);$k++){
					
									$creditPayment=$creditPayment+$creditInfo[$k][3];
								}
							}
				
							$credit_amount=$row['credit']-$creditPayment;
							
							if($credit == true && $credit_amount <= 0){ 
				 				$data=false; 
							}
			
							if($data) {		
								$arrList[$i][0]=$row[0];
								$arrList[$i][1]=$row[1];
								$arrList[$i][2]=$row[2];
				
								if($row[1] == "OP" || $row[1] == "IP"){
					
					                             if($row[1] == "IP"){
					                             
					                               $opno=$this->dbConnection->idToValue("hcare_ip_info","opno","id",$row[2]);
					                               //get doc id from patient visit info
									$doc_id=$this->dbConnection->idToValue("hcare_ip_info","doc_id","id",$row[2]);
					                                
					                             }else{
									$opno=$this->dbConnection->idToValue("hcare_op_visit_info","opno","id",$row[2]);
									//get doc id from patient visit info
									$doc_id=$this->dbConnection->idToValue("hcare_op_visit_info","doc_id","id",$row[2]);
								     }
					
									$arrList[$i][3]=$row[17]." ".$row[18]." ".$row[19];
					
									$arrList[$i][4]=$row[20];
									$arrList[$i][5]=$row[21];
									$arrList[$i][6]=$row[22];
									$arrList[$i][7]=$row[23];
									
										
													
									$arrList[$i][8]=$this->dbConnection->idToValue("hcare_emp_info","title","id",$doc_id)." ".$this->dbConnection->idToValue("hcare_emp_info","first_name","id",$doc_id)." ".$this->dbConnection->idToValue("hcare_emp_info","last_name","id",$doc_id);
									
								}else{
				
									$opno=0;
									$arrList[$i][3]=$row[24];
					
									$arrList[$i][4]=$row[25];
									$arrList[$i][5]=$row[26];
									$arrList[$i][6]=$row[27];
									$arrList[$i][7]=$row[28];			
									$arrList[$i][8]=$row[29];
								}
				
								$arrList[$i][9]=$row[3];
								$arrList[$i][10]=$row[4];
								$arrList[$i][11]=$row[5];
								$arrList[$i][12]=$row[6];
								$arrList[$i][13]=$row[7]+$creditPayment;
								$arrList[$i][14]=$row[8]-$creditPayment;
								$arrList[$i][15]=$row[9];
								$arrList[$i][16]=$row[11];
								$arrList[$i][17]=$row[12];
								$arrList[$i][18]=$row[13];
								$arrList[$i][19]=$opno;
								$arrList[$i][20]=$row[10];
								$arrList[$i][21]=$row[8];
								$arrList[$i][22]=$row[14];
								$arrList[$i][23]=$row[30];
								$i++;
								
							}
			
								
						}
				
				}
			return $arrList;
				
	}
	function getBillInfo($wheredata = null ,$orderbyfield = null,$oderby = null,$credit = false ){
	
		$arrList='';
		$i=0;
		$data=true;
		$query=$this->dbConnection->BuiltQuery('hcare_bill','',$wheredata,'id','asc');	
		$result=$this->dbConnection->executeQuery($query);
		//echo $query;
		if(mysql_num_rows($result) > 0){
			$p=1;
			while($row=mysql_fetch_assoc($result)){
			$data=true;
				$where[0]="bill_no='".$row['id']."'";
				$creditInfo=$this->getCreditBillInfo($where);

				$creditPayment=0;
				if(!empty($creditInfo)){
					 
					for($k=0;$k<count($creditInfo);$k++){
					
						$creditPayment=$creditPayment+$creditInfo[$k][3];
					}
				}
				
				$credit_amount=$row['credit']-$creditPayment;
				if($credit == true && $credit_amount <= 0){ 
				 $data=false; 
				}
			
			if($data){
				$arrList[$i][0]=$row['id'];
				$arrList[$i][1]=$row['type'];
				$arrList[$i][2]=$row['ref_no'];
				
				if($row['type'] == "OP" || $row['type'] == "IP") {
					
                    if($row['type'] == "OP") {
					$opno=$this->dbConnection->idToValue("hcare_op_visit_info","opno","id",$row['ref_no']);
                      $doc_id=$this->dbConnection->idToValue("hcare_op_visit_info","doc_id","id",$row['ref_no']);	
                   }else if($row['type'] == "IP") {
					$opno=$this->dbConnection->idToValue("hcare_ip_info","opno","id",$row['ref_no']);
                                        $doc_id=$this->dbConnection->idToValue("hcare_ip_info","doc_id","id",$row['ref_no']);	
                   }
					
				$arrList[$i][3]=$this->dbConnection->idToValue("hcare_op_patient_info","first_name","id",$opno)." ".$this->dbConnection->idToValue("hcare_op_patient_info","middle_name","id",$opno)." ".$this->dbConnection->idToValue("hcare_op_patient_info","last_name","id",$opno);
					
					$arrList[$i][4]=$this->dbConnection->idToValue("hcare_op_patient_info","age","id",$opno);
					$arrList[$i][5]=$this->dbConnection->idToValue("hcare_op_patient_info","gender","id",$opno);
					$arrList[$i][6]=$this->dbConnection->idToValue("hcare_op_patient_info","place","id",$opno);
					$arrList[$i][7]=$this->dbConnection->idToValue("hcare_op_patient_info","contact_no","id",$opno);
									
					$arrList[$i][8]=$this->dbConnection->idToValue("hcare_emp_info","title","id",$doc_id)." ".$this->dbConnection->idToValue("hcare_emp_info","first_name","id",$doc_id)." ".$this->dbConnection->idToValue("hcare_emp_info","last_name","id",$doc_id);
				}else{
				
					$opno='';
					$arrList[$i][3]=$this->dbConnection->idToValue("hcare_direct_customer","name","id",$row['ref_no']);
					
					$arrList[$i][4]=$this->dbConnection->idToValue("hcare_direct_customer","age","id",$row['ref_no']);
					$arrList[$i][5]=$this->dbConnection->idToValue("hcare_direct_customer","gender","id",$row['ref_no']);
					$arrList[$i][6]=$this->dbConnection->idToValue("hcare_direct_customer","place","id",$row['ref_no']);
					$arrList[$i][7]=$this->dbConnection->idToValue("hcare_direct_customer","contact_no","id",$row['ref_no']);				
					$arrList[$i][8]=$this->dbConnection->idToValue("hcare_direct_customer","refferal_info","id",$row['ref_no']);
				}
				
				$arrList[$i][9]=$row['total_amount'];
				$arrList[$i][10]=$row['dr_disc'];
				$arrList[$i][11]=$row['net_total'];
				$arrList[$i][12]=$row['paid_with'];
				$arrList[$i][13]=$row['cash']+$creditPayment;
				$arrList[$i][14]=$row['credit']-$creditPayment;
				$arrList[$i][15]=$row['credit_card'];
				$arrList[$i][16]=$row['bill_date'];
				$arrList[$i][17]=$row['remarks'];
				$arrList[$i][18]=$row['user_id'];
				$arrList[$i][19]=$opno;
				$arrList[$i][20]=$row['insurance'];
				$arrList[$i][21]=$row['credit'];
				$arrList[$i][22]=$row['lab_status'];
				
				$arrList[$i][23]=$dr_disc_amt=($row['total_amount']*($row['dr_disc']/100));
				$arrList[$i][24]=$row['cancellation_details'];

                               if($row['type'] == "IP") {
                                    
                                 $arrList[$i][25]=$this->dbConnection->idToValue("hcare_ip_info","discharge_date","id",$row['ref_no']);
                               }else $arrList[$i][25]='';
				$i++;
			}
			}
		
		}
	
		return $arrList;
	}
	
	public function getBillItemsInfo($wheredata){
	
		$arrList='';
		$i=0;
		$query=$this->dbConnection->BuiltQuery('hcare_bill_items','',$wheredata,'id','asc');	
		$result=$this->dbConnection->executeQuery($query);
		
		if(mysql_num_rows($result) > 0){
			
			while($row=mysql_fetch_assoc($result)){
				
				$arrList[$i][0]=$row['id'];
				$arrList[$i][1]=$row['bill_id'];
				$arrList[$i][2]=$row['bill_date'];
				$arrList[$i][3]=$row['type'];
				$arrList[$i][4]=$row['test_id'];
				
				if($row['type'] == "C") {
				
					$arrList[$i][5]="Consultation";
					
				}else if($row['type'] == "P") {
				
					$arrList[$i][5]=$this->dbConnection->idToValue("hcare_procedure","procedure_test","id",$row['test_id']);
					
				}else if($row['type'] == "L") {
				
					$cid=$row['category_id'];
					$check_catid=$this->dbConnection->idToValue("hcare_lab_test","catId","id",$row['test_id']);
					if($cid == $check_catid){
						$arrList[$i][5]=$this->dbConnection->idToValue("hcare_lab_test","testName","id",$row['test_id']);
					}else {
						$arrList[$i][5]=$this->dbConnection->idToValue("hcare_lab_element","test_name","id",$row['test_id']);
					}
				}
				$arrList[$i][6]=$row['category_id'];
				$arrList[$i][7]=$row['test_amount'];
				$arrList[$i][8]=$row['discount_type'];
				$arrList[$i][9]=$row['discount_value'];
				$arrList[$i][10]=$row['discount'];
				$arrList[$i][11]=$row['net_amount'];
				
				$i++;
			}
		}
		return $arrList;
	}
        public function getpharmaBill($wheredata = null){
                        
             
		$billInfo='';
		$i=0;
		$query=$this->dbConnection->BuiltQuery('hcare_pharma_invoice','',$wheredata,'id','asc');	
		$result=$this->dbConnection->executeQuery($query);

               if(mysql_num_rows($result) > 0){
			
			while($row=mysql_fetch_assoc($result)){

                             $where=array();
			     $where[]="bill_no = ".$row['id'];
                             $creditInfo=$this->getpharmaCreditPayment($where);
			     $credit=0;

				if(!empty($creditInfo)){
				
					for($k=0;$k<count($creditInfo);$k++){
					
						$credit +=$creditInfo[$k][2];
					}
				
				}

                                $amount_paid=$row['amount_paid'];
				$balance=$row['balance'];
                                $rem_balance=$balance-$credit;
                               $new_amount=$amount_paid+$credit;

                                $billInfo[$i][1]= $row['id'];
                                $billInfo[$i][2]= $row['net_total'];
				$billInfo[$i][3]= $row['payment_mode'];
				$billInfo[$i][4]= $row['checque_no'];
				$billInfo[$i][5]= $row['checque_amt'];;
				$billInfo[$i][6]= $row['card_amt'];;
                                $billInfo[$i][7]= $amount_paid;
				$billInfo[$i][8]= $balance;
                                $billInfo[$i][9]= $credit;
                                $billInfo[$i][10]=$new_amount;
                                $billInfo[$i][11]=$rem_balance;
                                $billInfo[$i][12]= $row['ip_no'];
                                $billInfo[$i][13]= $row['op_no'];
                              $i++;
                      }
              }
		      
                return $billInfo;  

       }
       public function getpharmaCreditPayment($wheredata = null){

                $billInfo='';
		$i=0;
		$query=$this->dbConnection->BuiltQuery('hcare_pharma_credit_payment','',$wheredata,'id','asc');	
		$result=$this->dbConnection->executeQuery($query);

               if(mysql_num_rows($result) > 0){
			
			while($row=mysql_fetch_assoc($result)){

                                
				$billInfo[$i][0]= $row['id'];
				$billInfo[$i][1]= $row['bill_no'];
				$billInfo[$i][2]= $row['amount'];

                              $i++;
                      }
              }
		      
                return $billInfo;  
       }
	function cancelBill($post){
	
		$id=$post['id'];
		
		$cancellation_details=$post['cancellation_details'];
		
		$field_names1=array('status','cancellation_details');
		$field_data=array('1',"$cancellation_details");
		
		$result=$this->dbConnection->update($field_names1,$field_data,"id",$id,"hcare_bill");
		
		if($result) return true;
		else return false;
	}
	function cancelBillItems($post){
	
		$id=$post['id'];
		
		
		$field_names1=array('status');
		$field_data=array('1');
		
		$result=$this->dbConnection->update($field_names1,$field_data,"bill_id",$id,"hcare_bill_items");
		
		if($result) return true;
		else return false;
	}
	
	
}
?>
