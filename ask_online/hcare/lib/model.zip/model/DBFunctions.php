<?php 
require_once ROOT_PATH . '/lib/confs/DMLFunctions.php';
require_once ROOT_PATH . '/lib/confs/config.php';


class DBFunction{

	
	
	function DBFunction(){
		$conf=new Config();
		$this->dbConnection=new DMLFunctions($conf);
	}

	function getCountries(){
	
			$arrList='';
			$query=$this->dbConnection->BuiltQuery("hcare_countries");	
			$result=$this->dbConnection->executeQuery($query);
			
			$i=0;
		
			if(mysql_num_rows($result)>0){
						
				while($row=mysql_fetch_assoc($result)){
				
					$arrList[$i][0]=$row['id'];
					$arrList[$i][1]=$row['country'];
					$i++;
				}	
			}
			
			return $arrList;
	}
	
	public function getDoctorPrescribedTest($opid){
	
			$wheredata[0]="opid = '".$opid."'";
			$query=$this->dbConnection->BuiltQuery("hcare_doc_page",'',$wheredata);	
			$result=$this->dbConnection->executeQuery($query);
			$row='';
			if(mysql_num_rows($result)>0){
			
				$row=mysql_fetch_assoc($result);
				
				
			}
			
			return $row;
	}
	public function getidToValue($field,$where_field,$value,$table){
	
		$result=$this->dbConnection->idToValue($table,$field,$where_field,$value);
		
		return $result;
	}
	
	function isValidCatagory($test)
	{
	
			$wheredata[0]="test_name = '".$test."'";
			 $query=$this->dbConnection->BuiltQuery("hcare_lab_element",'',$wheredata);	
			$result=$this->dbConnection->executeQuery($query);
			
			if(mysql_num_rows($result)>0){
			
				return true;
			}else return false;
	
	}
	function isValidTest($test)
	{
	
			$wheredata[0]="testName = '".$test."'";
			$query=$this->dbConnection->BuiltQuery("hcare_lab_test",'',$wheredata);	
			$result=$this->dbConnection->executeQuery($query);
			
			if(mysql_num_rows($result)>0){
			
				return true;
			}else return false;
	
	}

}
?>