<?php

require_once ROOT_PATH . '/lib/confs/DMLFunctions.php';
require_once ROOT_PATH . '/lib/confs/config.php';
class Report{

	var $dbConnection;
	
	
	function Report(){
		$conf=new Config();
		$this->dbConnection=new DMLFunctions($conf);
	}

	function daily_collection($fromdate,$todate){
	
		$arrayList='';
		$query="select sum(doc_fee) from hcare_op_visit_info where visit_date >='$fromdate' and visit_date<='$todate'";
		$result=$this->dbConnection->executeQuery($query);
		$arrayList[0][0]="Consultation";
		$arrayList[0][1]=mysql_result($result,0,'sum(doc_fee)');
		
		$query="select sum(reg_fee) from hcare_op_visit_info where visit_date >='$fromdate' and visit_date<='$todate'";
		$result=$this->dbConnection->executeQuery($query);	
		$arrayList[1][0]="Reg Fee";	
		$arrayList[1][1]=mysql_result($result,0,'sum(reg_fee)');
		
		return $arrayList;
	}
	function daily_bill_collection($fromdate,$todate,$user_id = null){
	
		$arrayList='';
		$query="select sum(cash) from hcare_bill where bill_date >='$fromdate' and bill_date<='$todate'";
		
		if(!empty($user_id)) $query .= " and user_id in $user_id";
		//echo $query;
		
		$result=$this->dbConnection->executeQuery($query);
		$arrayList[0][0]="Cash";
		$arrayList[0][1]=mysql_result($result,0,'sum(cash)');
		
		$query="select sum(credit_card) from hcare_bill where bill_date >='$fromdate' and bill_date<='$todate'";
		
		if(!empty($user_id)) $query .= " and user_id in $user_id";
		
		$result=$this->dbConnection->executeQuery($query);
		$arrayList[1][0]="Credit Card";
		$arrayList[1][1]=mysql_result($result,0,'sum(credit_card)');
		
		$query="select sum(credit) from hcare_bill where bill_date >='$fromdate' and bill_date<='$todate'";
		
		if(!empty($user_id)) $query .= " and user_id in $user_id";
		
		$result=$this->dbConnection->executeQuery($query);
		$arrayList[2][0]="Credit";
		$arrayList[2][1]=mysql_result($result,0,'sum(credit)');
		
		$query="select sum(insurance) from hcare_bill where bill_date >='$fromdate' and bill_date<='$todate'";
		
		if(!empty($user_id)) $query .= " and user_id in $user_id";
		
		$result=$this->dbConnection->executeQuery($query);
		$arrayList[3][0]="Insurance";
		$arrayList[3][1]=mysql_result($result,0,'sum(insurance)');
		
		$query="select sum(amount) from hcare_bill_payments where bill_date >='$fromdate' and bill_date<='$todate'";
		
		if(!empty($user_id)) $query .= " and user_id in $user_id";
		
		$result=$this->dbConnection->executeQuery($query);
		$arrayList[4][0]="Credit Payment";
		$arrayList[4][1]=mysql_result($result,0,'sum(amount)');
		
		$query="select sum(net_total) from hcare_bill where bill_date >='$fromdate' and bill_date<='$todate'";
		
		if(!empty($user_id)) $query .= " and user_id in $user_id";
		
		$result=$this->dbConnection->executeQuery($query);
		$arrayList[5][0]="Total Collection";
		$arrayList[5][1]=mysql_result($result,0,'sum(net_total)')+$arrayList[4][1];
		
		return $arrayList;
		
	}
	function patient_count($docid,$fromdate,$todate){
	
			$query1="select count(*) from hcare_op_visit_info where visit_date >='$fromdate' and visit_date<='$todate' and (visit_status='NEW'  and free=0) and doc_id=$docid and cancelled=0";
			$result1=$this->dbConnection->executeQuery($query1);
			$new=mysql_result($result1,0,'count(*)');
			
			$query1="select count(*) from hcare_op_visit_info where visit_date >='$fromdate' and visit_date<='$todate' and ( visit_status='RENEW' and free=0) and doc_id=$docid and cancelled =0";
			$result1=$this->dbConnection->executeQuery($query1);
			$renew=mysql_result($result1,0,'count(*)');
			
			$query2="select count(*) from hcare_op_visit_info where visit_date >='$fromdate' and visit_date<='$todate' and visit_status='VISIT' and free=0 and doc_id=$docid and cancelled=0";
			$result2=$this->dbConnection->executeQuery($query2);
			$visit=mysql_result($result2,0,'count(*)');
			
			
			$query3="select count(*) from hcare_op_visit_info where visit_date >='$fromdate' and visit_date<='$todate' and free=1 and doc_id=$docid and cancelled=0";
			$result3=$this->dbConnection->executeQuery($query3);
			$free=mysql_result($result3,0,'count(*)');
			
			$query3="select sum(doc_fee) from hcare_op_visit_info where visit_date >='$fromdate' and visit_date<='$todate' and visit_status='FREE' and doc_id=$docid and cancelled=0";
			$result3=$this->dbConnection->executeQuery($query3);
			$paid=mysql_result($result3,0,'sum(doc_fee)');
			
			
			return array($new,$visit,$free,$paid,$renew);
		
	
	
	}

}


?>
