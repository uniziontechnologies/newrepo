﻿
<?php session_start();
require_once ROOT_PATH . '/lib/confs/DMLFunctions.php';
require_once ROOT_PATH . '/lib/confs/config.php';


class Inpatient{

	
	
	function Inpatient(){
		$conf=new Config();
		$this->dbConnection=new DMLFunctions($conf);
	}
	function addIpPatient($post){
	
			$age=$post['age']." ".$post['age_type'];
			$dob = date("Y-m-d",strtotime($post['dob']));
			
			$field_names=array( 'id' ,'visit_id' ,'opno' ,'doc_id' ,'admission_time' ,'admission_date'  ,'insurance_company' ,'policy_no' ,'claim_no' ,'company_name' ,'company_id' ,'relation' ,'ins_date_issue' ,'ins_date_expiry' ,'referral_info' ,'room_id' ,'bed_id' ,'room_rent' ,
'remarks' ,'user_id' );
			$field_data=array("",$post['id'],$post['opno'],$post['doctor'],$post['admission_time'],$post['admission_date'],$post['insurance_company'],$post['policy_no'],$post['claim'],$post['company_name'],$post['company_id'],$post['relation'],$post['date_issue'],$post['date_expiry'],$post['refferal_info'],$post['room'],$post['bed_no'],$post['rent'],$post['remarks'],$_SESSION['user_id']);
		
        
        $result=$this->dbConnection->insert($field_names,$field_data,"hcare_ip_info");
		
		if($result) return mysql_insert_id();
		else return 0;
	}
	function add_discharge_date($post){
	
	  $field_names=array( 'discharge_time' ,'discharge_date');
	  $field_data=array($post['curr_time'],date("Y-m-d",strtotime($post['dod'])));
	  
	  $result=$this->dbConnection->update($field_names,$field_data,"id",$post['id'],"hcare_ip_info");
		
		if($result) return $id;
		else return 0;
	
	}
	function updateIpPatient($post){
	
	   $id=$post['ipno'];
	   
	   $field_names=array( 'doc_id' ,'insurance_company' ,'policy_no' ,'claim_no' ,'company_name' ,'company_id' ,'relation' ,'ins_date_issue' ,'ins_date_expiry' ,'referral_info' ,'remarks');
			$field_data=array($post['doctor'],$post['insurance_company'],$post['policy_no'],$post['claim'],$post['company_name'],$post['company_id'],$post['relation'],$post['date_issue'],$post['date_expiry'],$post['refferal_info'],$post['remarks']);

                        if(!empty($post['room']) && !empty($post['bed_no'])){

                                $field_names[]='room_id';
                                $field_names[]='bed_id'; 
                                $field_names[]='room_rent' ;

                               $field_data[]=$post['room'];
                               $field_data[]=$post['bed_no']; 
                               $field_data[]=$post['rent'] ;

                        }
			
			$result=$this->dbConnection->update($field_names,$field_data,"id",$id,"hcare_ip_info");
		
		if($result) return $id;
		else return 0;
		
	
	}
        function addIProomHistory($post){
               
                
	  $field_names=array( 'ipno' ,'start_date','end_date','room_id','bed_id','rent');
	  $field_data=array($post['ipno'],date("Y-m-d",strtotime($post['startdate'])),date("Y-m-d",strtotime($post['enddate'])),$post['room_id'],$post['bed_id'],$post['current_rent']);
	  
	  $result=$this->dbConnection->insert($field_names,$field_data,"hcare_ip_room_history");
		
		if($result) return mysql_insert_id();
		else return 0;

        }
function getRoomhistory($selectfield = null,$wheredata = null,$orderbyfield = null,$orderby = null){
	
		$arrList='';
		
		
		$query=$this->dbConnection->BuiltQuery("hcare_ip_room_history",$selectfield,$wheredata,$orderbyfield,$orderby);	
		
		$result=$this->dbConnection->executeQuery($query);
		$i=0;
		
		if(mysql_num_rows($result)>0){
			if(empty($selectfield)){
				while($row=mysql_fetch_array($result)){
				
						
						$arrList[$i][0]=$row[0];
						$arrList[$i][1]=$row[1];
						$arrList[$i][2]=$row[2];
						$arrList[$i][3]=$row[3];
						$arrList[$i][4]=$row[4];
                                                $arrList[$i][5]=$row[5];
                                                $arrList[$i][6]=$row[6];
						$arrList[$i][7]=$this->dbConnection->idToValue("hcare_rooms","room_number","id",$row[4]);
						
						$arrList[$i][8]=$this->dbConnection->idToValue("hcare_room_beds","bed_number","id",$row[5]);
					
					
						$i++;
				}
				
			
			}
		
		}
		return $arrList;	
	
	}
	
	function getIPPatientInfo($selectfield = null,$selectCondition = null ,$orderbyfield = null,$oderby = null ){
	
	     if(empty($selectfield)) {
			
				$arrFieldList[0]= "a.`id`";
				$arrFieldList[1]= "a.`first_name`";
				$arrFieldList[2]= "a.`middle_name`";
				$arrFieldList[3]= "a.`last_name`";
				$arrFieldList[4]= "a.`age`";
				$arrFieldList[5]= "a.`dob`";
				$arrFieldList[6]= "a.`gender`";
				$arrFieldList[7]= "a.`marital_status`";
				$arrFieldList[8]= "a.`place`";
				$arrFieldList[9]= "a.`nationality`";
				$arrFieldList[10]= "a.`contact_no`";
				$arrFieldList[11]= "a.`email`";
				$arrFieldList[12]= "a.`status`";
				$arrFieldList[13]= "b.`id`";
				$arrFieldList[14]= "b.`visit_id`";
				$arrFieldList[15]= "b.`opno`";
				$arrFieldList[16]= "b.`doc_id`";
				$arrFieldList[17]= "f.`first_name`";
				$arrFieldList[18]= "f.`last_name`";
				$arrFieldList[19]= "b.`admission_time`";
				$arrFieldList[20]= "b.`admission_date`";
				$arrFieldList[21]= "b.`discharge_time`";
				$arrFieldList[22]= "b.`discharge_date`";
				$arrFieldList[23]= "b.`insurance_company`";
				$arrFieldList[24]= "d.`insurance_company`";
				$arrFieldList[25]= "b.`policy_no`";
				$arrFieldList[26]= "b.`claim_no`";
				$arrFieldList[27]= "b.`company_name`";
				$arrFieldList[28]= "b.`company_id`";
				$arrFieldList[29]= "b.`relation`";
				$arrFieldList[30]= "b.`ins_date_issue`";
				$arrFieldList[31]= "b.`ins_date_expiry`";
				$arrFieldList[32]= "b.`referral_info`";
				$arrFieldList[33]= "b.`room_id`";
				$arrFieldList[34]= "b.`bed_id`";
				$arrFieldList[35]= "b.`room_rent`";
				$arrFieldList[36]= "c.`room_category`";
				$arrFieldList[37]= "c.`room_number`";
				$arrFieldList[38]= "e.`bed_number`";
				$arrFieldList[39]= "e.`bed_status`";
				$arrFieldList[40]= "b.`remarks`";
				$arrFieldList[41]= "b.`payment_status`";
				$arrFieldList[42]= "b.`cancelled`";
				$arrFieldList[43]= "b.`cancellation_details`";
				$arrFieldList[44]= "b.`user_id`";
                                $arrFieldList[45]= "a.`care_of`";				$arrFieldList[46]= "a.`address`";				$arrFieldList[47]= "a.`mobile`";
				
				
		}else {
			
				for($k=0;$k<count($selectfield);$k++){
					
						$arrFieldList[]=$selectfield[$k];
					}
			
	   }
	   
	                $arrTables[0] = "`hcare_ip_info` b";
	                $arrTables[1] = "`hcare_op_patient_info` a";       			    
       			    $arrTables[2] = "`hcare_rooms` c";
					$arrTables[3] = "`hcare_room_beds` e";
					$arrTables[4] = "`hcare_emp_info` f";
				    $arrTables[5] = "`hcare_insurance_company` d";
			        
					$joinConditions[1] = "b.`opno` = a.`id`";
					$joinConditions[2] = "b.`room_id` = c.`id`";
					$joinConditions[3] = "b.`bed_id` = e.`id`";
        		    $joinConditions[4] = "b.`doc_id` = f.`id`";
					$joinConditions[5] = "b.`insurance_company` = d.`id`";
					
					
					if(!empty($selectCondition)) {
					for($k=0;$k<count($selectCondition);$k++){
					
						$selectConditions[]=$selectCondition[$k];
					}
				}
				$selectConditions[]="a.`status`=0";
				//$orderbyfield="b.id";
				//$orderby="asc";
				
			      $query=$this->dbConnection->selectFromMultipleTable($arrFieldList, $arrTables, $joinConditions, $selectConditions,'',$orderbyfield,$oderby);
				
				$result=$this->dbConnection->executeQuery($query);
				
				if(mysql_num_rows($result)>0){
								$i=0;
						while($row=mysql_fetch_array($result)){
									
								for($k=0;$k<count($arrFieldList);$k++) {						
								
									$arrList[$i][$k]=$row[$k];
								}
                                
						     $i++;
						}
				    
				}
			return $arrList;
	
	}
        function addIPProcedure($post){
	
		
		$field_names=array("id","ipno","procedure_test","amount","date","user","status");
		$field_data=array("",$_SESSION['patient_selected'],$post['procedure'],$post['test_amount'],date("Y-m-d",strtotime($post['date'])),$_SESSION['user_id'],0);
		$result=$this->dbConnection->insert($field_names,$field_data,'hcare_ip_procedure');
		
		if($result) return true;
		else return false;
	
	}
        function deleteIPProcedure($post){
	
		$id=$post['id'];
		
		$field_names1=array('status','cancellation_details');
		$field_data=array('1',$post['del_details']);
		
		$result=$this->dbConnection->update($field_names1,$field_data,"id",$id,'hcare_ip_procedure');
		
		if($result) return true;
		else return false;
	}
	function getIPProcedure($selectfield = null,$wheredata = null,$orderbyfield = null,$orderby = null){
	
		$arrList='';
		if(empty($wheredata)){
				$wheredata[0]="status = 0";
		}
		$query=$this->dbConnection->BuiltQuery('hcare_ip_procedure',$selectfield,$wheredata,$orderbyfield,$orderby);	
		$result=$this->dbConnection->executeQuery($query);
		$i=0;
		

		if(mysql_num_rows($result)>0){
			if(empty($selectfield)){
				while($row=mysql_fetch_assoc($result)){

					$arrList[$i][0]=$row['id'];
				        $arrList[$i][1]=$row['procedure_test'];
                                        $arrList[$i][2]=$this->dbConnection->idToValue("hcare_procedure","procedure_test","id",$row['procedure_test']);
                                        $arrList[$i][3]=$row['amount'];
				        $arrList[$i][4]=date("d-m-Y",strtotime($row['date']));
				        $arrList[$i][5]=$row['status'];
				        $arrList[$i][6]=$row['user'];
                                        $arrList[$i][7]= $this->dbConnection->idToValue("hcare_users","user_name","id",$row['user']);
						$i++;
				}
				
			
			}
		
		}
		return $arrList;	
	
	}

        function add_doctor_visit($post){
	
		
		$field_names=array("id","ipno","doctor","visit_charge","date","visit_type","user","status");
		$field_data=array("",$_SESSION['patient_selected'],$post['doctor'],$post['amount'],date("Y-m-d",strtotime($post['date'])),$post['visit_type'],$_SESSION['user_id'],0);
		$result=$this->dbConnection->insert($field_names,$field_data,'hcare_ip_doctor_visit');
		
		if($result) return true;
		else return false;
	
	}
        function delete_doctor_visit($post){
	
		$id=$post['id'];
		
		$field_names1=array('status','cancellation_details');
		$field_data=array('1',$post['del_details']);
		
		$result=$this->dbConnection->update($field_names1,$field_data,"id",$id,'hcare_ip_doctor_visit');
		
		if($result) return true;
		else return false;
	}
        function getDoctorVisit($selectfield = null,$wheredata = null,$orderbyfield = null,$orderby = null){
	
		$arrList='';
		if(empty($wheredata)){
				$wheredata[0]="status = 0";
		}
		$query=$this->dbConnection->BuiltQuery('hcare_ip_doctor_visit',$selectfield,$wheredata,$orderbyfield,$orderby);	
		$result=$this->dbConnection->executeQuery($query);
		$i=0;
		

		if(mysql_num_rows($result)>0){
			if(empty($selectfield)){
				while($row=mysql_fetch_assoc($result)){

					$arrList[$i][0]=$row['id'];
				        $arrList[$i][1]=$row['doctor'];
                                        $arrList[$i][2]="Dr. ".$this->dbConnection->idToValue("hcare_emp_info","first_name","id",$row['doctor'])." ".$this->dbConnection->idToValue("hcare_emp_info","last_name","id",$row['doctor']);
                                        $arrList[$i][3]=$row['visit_charge'];
				        $arrList[$i][4]=date("d-m-Y",strtotime($row['date']));
                                        $arrList[$i][5]=$row['visit_type'];
				        $arrList[$i][6]=$row['status'];
				        $arrList[$i][7]=$row['user'];
                                        $arrList[$i][8]= $this->dbConnection->idToValue("hcare_users","user_name","id",$row['user']);
                                        $arrList[$i][9]=$row['cancellation_details'];
						$i++;
				}
				
			
			}
		
		}
		return $arrList;	
	
	}
        function add_nursing_notes($post){
	
		
		$field_names=array("id","ipno","nursing_notes","date","user","status");
		$field_data=array("",$_SESSION['patient_selected'],$post['nursing_notes'],date("Y-m-d",strtotime($post['date'])),$_SESSION['user_id'],0);
		$result=$this->dbConnection->insert($field_names,$field_data,'hcare_ip_nursing_notes');
		
		if($result) return true;
		else return false;
	
	}
        function delete_nursing_notes($post){
	
		$id=$post['id'];
		
		$field_names1=array('status','cancellation_details');
		$field_data=array('1',$post['del_details']);
		
		$result=$this->dbConnection->update($field_names1,$field_data,"id",$id,'hcare_ip_nursing_notes');
		
		if($result) return true;
		else return false;
	}
        function getIPNursingNotes($selectfield = null,$wheredata = null,$orderbyfield = null,$orderby = null){
	
		$arrList='';
		if(empty($wheredata)){
				$wheredata[0]="status = 0";
		}
		$query=$this->dbConnection->BuiltQuery('hcare_ip_nursing_notes',$selectfield,$wheredata,$orderbyfield,$orderby);	
		$result=$this->dbConnection->executeQuery($query);
		$i=0;
		

		if(mysql_num_rows($result)>0){
			if(empty($selectfield)){
				while($row=mysql_fetch_assoc($result)){

					$arrList[$i][0]=$row['id'];
				        $arrList[$i][1]=$row['nursing_notes'];                                        
				        $arrList[$i][2]=date("d-m-Y",strtotime($row['date']));                                       
				        $arrList[$i][3]=$row['status'];
				        $arrList[$i][4]=$row['user'];
                                        $arrList[$i][5]= $this->dbConnection->idToValue("hcare_users","user_name","id",$row['user']);
                                        $arrList[$i][6]=$row['cancellation_details'];
						$i++;
				}
				
			
			}
		
		}
		return $arrList;	
	
	}
	/*function updatePatientinfo($post){
	
			$id=$post['opno'];
			$field_names=array("first_name","middle_name","last_name","age","dob","gender","marital_status","place","nationality","contact_no","email");
			$field_data=array($post['first_name'],$post['middle_name'],$post['last_name'],$post['age']." ".$post['age_type'],$post['dob'],$post['gender'],$post['marital_status'],$post['place'],$post['nationality'],$post['contact_no'],$post['email']);
			
	
	
		$result=$this->dbConnection->update($field_names,$field_data,"id",$id,"hcare_op_patient_info");
		
		if($result) return $id;
		else return 0;
	}
	function addVisitInfo($post){
	
			if(!empty($post['bk_id'])){
				$reg_from = "Booking";
			}else $reg_from ="Registration";
			
			if(!empty($post['free'])){
				$free=1;
			}else $free=0;
	
			$field_names=array("id","opno","doc_id","doc_fee","reg_fee","visit_time","visit_date","validity_expiry","insurance_company","policy_no","claim_no","company_name","company_id","relation","ins_date_issue","ins_date_expiry","cons_disc_amt","visit_status","remarks","refferal_info","user_id","token_no","reg_from","mlc_summary","op_reset_no","paid_status","free");
			if(!empty($post['date_issue'])){
				$post['date_issue']=date("Y-m-d",strtotime($post['date_issue']));
				$post['date_expiry']=date("Y-m-d",strtotime($post['date_expiry']));
			}
			
			$field_data=array("",$post['opno'],$post['doctor'],$post['docfee'],$post['regfee'],$post['visit_time'],$post['visit_date'],$post['validity'],$post['insurance_company'],$post['policy_no'],$post['claim'],$post['company_name'],$post['company_id'],$post['relation'],$post['date_issue'],$post['date_expiry'],$post['cons_disc_amt'],$post['status'],$post['remarks'],$post['refferal_info'],$_SESSION['user_id'],$post['token'],$reg_from,$post['mlc_summary'],$post['reset_op_no'],"1",$free);
			
			$result=$this->dbConnection->insert($field_names,$field_data,"hcare_op_visit_info");
			
			if($result) return mysql_insert_id();
			else return 0;
			
	}
	function updateVisitInfo($post){
	
			$id=$post['id'];
			
			if(!empty($post['free'])){
				$free=1;
			}else $free=0;
			
			$field_names=array("doc_id","doc_fee","reg_fee","visit_time","visit_date","validity_expiry","insurance_company","policy_no","claim_no","company_name","company_id","relation","ins_date_issue","ins_date_expiry","cons_disc_amt","visit_status","remarks","refferal_info","user_id","mlc_summary","free");
			if(!empty($post['date_issue'])){
				$post['date_issue']=date("Y-m-d",strtotime($post['date_issue']));
				$post['date_expiry']=date("Y-m-d",strtotime($post['date_expiry']));
			}
			
			$field_data=array($post['doctor'],$post['docfee'],$post['regfee'],$post['visit_time'],$post['visit_date'],$post['validity'],$post['insurance_company'],$post['policy_no'],$post['claim'],$post['company_name'],$post['company_id'],$post['relation'],$post['date_issue'],$post['date_expiry'],$post['cons_disc_amt'],$post['status'],$post['remarks'],$post['refferal_info'],$_SESSION['user_id'],$post['mlc_summary'],$free);
			
			
			$result=$this->dbConnection->update($field_names,$field_data,"id",$id,"hcare_op_visit_info");
			
			if($result) return $id;
			else return 0;
			
	}
	function deletePatientVisit($post){
		$id=$post['id'];
		$details=$post['cancellation_details'];
				
		$field_names1=array('cancelled','cancellation_details');
		$field_data=array('1',$details);
		
		$result=$this->dbConnection->update($field_names1,$field_data,"id",$id,"hcare_op_visit_info");
		
		#$result=$this->dbConnection->deletePermenantly($where,"hcare_op_visit_info");
	}
	function updatePaidStatus($opid,$status){
	
		$field_names1=array('paid_status');
		$field_data=array($status);
		
		$result=$this->dbConnection->update($field_names1,$field_data,"id",$opid,"hcare_op_visit_info");
		
		if($result) return true;
		else return false;
	
	}
	
	function getOPPatientInfo($selectfield = null,$selectCondition = null ,$orderbyfield = null,$oderby = null ){
	
				$arrList='';
			if(empty($selectfield)) {
			
				$arrFieldList[0]= "a.`id`";
				$arrFieldList[1]= "a.`first_name`";
				$arrFieldList[2]= "a.`middle_name`";
				$arrFieldList[3]= "a.`last_name`";
				$arrFieldList[4]= "a.`age`";
				$arrFieldList[5]= "a.`dob`";
				$arrFieldList[6]= "a.`gender`";
				$arrFieldList[7]= "a.`marital_status`";
				$arrFieldList[8]= "a.`place`";
				$arrFieldList[9]= "a.`nationality`";
				$arrFieldList[10]= "a.`contact_no`";
				$arrFieldList[11]= "a.`email`";
				$arrFieldList[12]= "a.`status`";
				$arrFieldList[13]= "b.`id`";
				$arrFieldList[14]= "b.`doc_id`";
				$arrFieldList[15]= "c.`first_name`";
				$arrFieldList[16]= "c.`last_name`";
				$arrFieldList[17]= "b.`doc_fee`";
				$arrFieldList[18]= "b.`reg_fee`";
				$arrFieldList[19]= "b.`visit_time`";
				$arrFieldList[20]= "b.`visit_date`";
				$arrFieldList[21]= "b.`validity_expiry`";
				$arrFieldList[22]= "b.`insurance_company`";
				$arrFieldList[23]= "d.`insurance_company`";
				$arrFieldList[24]= "b.`policy_no`";
				$arrFieldList[25]= "b.`claim_no`";
				$arrFieldList[26]= "b.`company_name`";
				$arrFieldList[27]= "b.`company_id`";
				$arrFieldList[28]= "b.`relation`";
				$arrFieldList[29]= "b.`ins_date_issue`";
				$arrFieldList[30]= "b.`ins_date_expiry`";
				$arrFieldList[31]= "b.`cons_disc_amt`";
				$arrFieldList[32]= "b.`visit_status`";
				$arrFieldList[33]= "b.`remarks`";
				$arrFieldList[34]= "b.`refferal_info`";
				$arrFieldList[35]= "b.`user_id`";
				$arrFieldList[36]= "b.`token_no`";
				$arrFieldList[37]= "b.`reg_from`";
				$arrFieldList[38]= "b.`mlc_summary`";
				$arrFieldList[39]= "b.`op_reset_no`";
				$arrFieldList[40]= "b.`paid_status`";
				$arrFieldList[41]= "b.`free`";
				$arrFieldList[42]= "b.`cancelled`";
				$arrFieldList[43]= "b.`cancellation_details`";
			}else {
			
				for($k=0;$k<count($selectfield);$k++){
					
						$arrFieldList[]=$selectfield[$k];
					}
			
			}
			
			 		$arrTables[0] = "`hcare_op_patient_info` a";
       			    $arrTables[1] = "`hcare_op_visit_info` b";
       			    $arrTables[2] = "`hcare_emp_info` c";
				    $arrTables[3] = "`hcare_insurance_company` d";
					
					$joinConditions[1] = "a.`id` = b.`opno`";
        		    $joinConditions[2] = "b.`doc_id` = c.`id`";
					$joinConditions[3] = "b.`insurance_company` = d.`id`";
					
					if(!empty($selectCondition)) {
					for($k=0;$k<count($selectCondition);$k++){
					
						$selectConditions[]=$selectCondition[$k];
					}
				}
				$selectConditions[]="a.`status`=0";
				$orderbyfield="b.op_reset_no";
				$orderby="asc";
				$query=$this->dbConnection->selectFromMultipleTable($arrFieldList, $arrTables, $joinConditions, $selectConditions,'',$orderbyfield,$oderby);
				
				$result=$this->dbConnection->executeQuery($query);
				
				if(mysql_num_rows($result)>0){
								$i=0;
						while($row=mysql_fetch_array($result)){
									
								for($k=0;$k<count($arrFieldList);$k++) {						
								
									$arrList[$i][$k]=$row[$k];
								}
								$i++;
						
						}
				
				}
			return $arrList;
	}*/

	
}
?>
