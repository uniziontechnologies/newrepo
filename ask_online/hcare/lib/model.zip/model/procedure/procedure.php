<?php

require_once ROOT_PATH . '/lib/confs/DMLFunctions.php';
require_once ROOT_PATH . '/lib/confs/config.php';
class Procedure{

	var $dbConnection;
	var $field_names=array("id","category_id","procedure_test","amount","description","status");
	var $tablename="hcare_procedure";
	
	function Procedure(){
		$conf=new Config();
		$this->dbConnection=new DMLFunctions($conf);
	}

	function addProcedure($post){
	
		
		
		$field_data=array("",$post['category'],$post['procedure'],$post['amount'],$post['description'],0);
		$result=$this->dbConnection->insert($this->field_names,$field_data,$this->tablename);
		
		if($result) return true;
		else return false;
	
	}
	function updateProcedure($post){
	
		$id=$post['id'];		
		
		
		$this->field_names=array("category_id","procedure_test","amount","description","status");
		$field_data=array($post['category'],$post['procedure'],$post['amount'],$post['description'],0);
	
		
		$result=$this->dbConnection->update($this->field_names,$field_data,"id",$id,$this->tablename);
		
		if($result) return true;
		else return false;
	
	}
	function deleteProcedure($post){
	
		$id=$post['id'];
		
		$field_names1=array('status');
		$field_data=array('1');
		
		$result=$this->dbConnection->update($field_names1,$field_data,"id",$id,$this->tablename);
		
		if($result) return true;
		else return false;
	}
	function getProcedure($selectfield = null,$wheredata = null,$orderbyfield = null,$orderby = null){
	
		$arrList='';
		if(empty($wheredata)){
				$wheredata[0]="status = 0";
		}
		$query=$this->dbConnection->BuiltQuery($this->tablename,$selectfield,$wheredata,$orderbyfield,$orderby);	
		$result=$this->dbConnection->executeQuery($query);
		$i=0;
		
		if(mysql_num_rows($result)>0){
			if(empty($selectfield)){
				while($row=mysql_fetch_assoc($result)){
					$j=0;
					for($k=0;$k<count($this->field_names);$k++) {
					
						
						if($this->field_names[$k] == "category_id"){
							$arrList[$i][$j++]=$this->dbConnection->idToValue("hcare_procedure_category","category","id",$row[$this->field_names[$k]]);
						}
						
						$arrList[$i][$j++]=$row[$this->field_names[$k]];
						
					}
						$i++;
				}
				
			
			}
		
		}
		return $arrList;	
	
	}

	
}


?>
