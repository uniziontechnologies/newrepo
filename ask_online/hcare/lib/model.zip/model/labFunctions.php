<?php 
require_once ROOT_PATH . '/lib/confs/DMLFunctions.php';
require_once ROOT_PATH . '/lib/confs/config.php';


class LabFunctions{

	
	
	function DBFunction(){
		$conf=new Config();
		$this->dbConnection=new DMLFunctions($conf);
	}

	function getCountries(){
	
			$arrList='';
			$query=$this->dbConnection->BuiltQuery("hcare_countries");	
			$result=$this->dbConnection->executeQuery($query);
			
			$i=0;
		
			if(mysql_num_rows($result)>0){
						
				while($row=mysql_fetch_assoc($result)){
				
					$arrList[$i][0]=$row['id'];
					$arrList[$i][1]=$row['country'];
					$i++;
				}	
			}
			
			return $arrList;
	}

}
?>