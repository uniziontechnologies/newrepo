<?php

require_once ROOT_PATH . '/lib/confs/DMLFunctions.php';
require_once ROOT_PATH . '/lib/confs/config.php';

class roomCategory{

	var $dbConnection;	
	
	function RoomCategory(){
		$conf=new Config();
		$this->dbConnection=new DMLFunctions($conf);
	}

	function addRoomCategory($post){
	
		
		$field_names=array("id","category","rent","status");
		$field_data=array("",$post['category'],$post['rent'],0);
		$result=$this->dbConnection->insert($field_names,$field_data,"hcare_room_category");
		
		if($result) return true;
		else return false;
	
	}
	function updateRoomCategory($post){
	
		$id=$post['id'];		
		
		
		$field_names=array("category","rent","status");
		$field_data=array($post['category'],$post['rent'],0);
	
		
		$result=$this->dbConnection->update($field_names,$field_data,"id",$id,"hcare_room_category");
		
		if($result) return true;
		else return false;
	
	}
	function deleteRoomCategory($post){
	
		$id=$post['id'];
		
		$field_names1=array('status');
		$field_data=array('1');
		
		$result=$this->dbConnection->update($field_names1,$field_data,"id",$id,"hcare_room_category");
		
		if($result) return true;
		else return false;
	}
	function getRoomCategory($selectfield = null,$wheredata = null,$orderbyfield = null,$orderby = null){
	
		$arrList='';
		
		if(empty($wheredata)){
				$wheredata[0]="status = 0";
		}
		$query=$this->dbConnection->BuiltQuery("hcare_room_category",$selectfield,$wheredata,$orderbyfield,$orderby);	
		$result=$this->dbConnection->executeQuery($query);
		$i=0;
		
		if(mysql_num_rows($result)>0){
			if(empty($selectfield)){
				while($row=mysql_fetch_array($result)){
				
						
						$arrList[$i][0]=$row[0];
						$arrList[$i][1]=$row[1];
						$arrList[$i][2]=$row[2];
						$arrList[$i][3]=$row[3];
						
					
						$i++;
				}
				
			
			}
		
		}
		return $arrList;	
	
	}
	
	
	

}


?>
