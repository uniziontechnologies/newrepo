<?php 

require_once ROOT_PATH . '/lib/confs/DMLFunctions.php';
require_once ROOT_PATH . '/lib/confs/config.php';
class User{

	var $dbConnection;
	var $field_names=array("id","employee_id","user_name","password","user_type","status");
	var $tablename="hcare_users";
	
	function User(){
		$conf=new Config();
		$this->dbConnection=new DMLFunctions($conf);
	}

	function addUser($post){
		$password = md5($post['password']);
		
		$field_data=array("",$post['emp_id'],$post['username'],$password,$post['user_type'],0);
		$result=$this->dbConnection->insert($this->field_names,$field_data,$this->tablename);
		
		if($result) return true;
		else return false;
	
	}
	function updateUser($post){
	
		$userid=$post['id'];
		
		if($post['password']!=''){
		
			$password = md5($post['password']);
			$this->field_names=array("employee_id","user_name","password","user_type","status");
			$field_data=array($post['emp_id'],$post['username'],$password,$post['user_type'],0);
			
		}else{
		
			$this->field_names=array("employee_id","user_name","user_type","status");
			$field_data=array($post['emp_id'],$post['username'],$post['user_type'],0);
		}
		
		$result=$this->dbConnection->update($this->field_names,$field_data,"id",$userid,$this->tablename);
		
		if($result) return true;
		else return false;
	
	}
	function deleteUser($post){
	
		$userid=$post['id'];
		
		$field_names1=array('status');
		$field_data=array('1');
		
		$result=$this->dbConnection->update($field_names1,$field_data,"id",$userid,$this->tablename);
		
		if($result) return true;
		else return false;
	}
	function getUser($selectfield = null,$wherefield = null){
	
		$arrList=array();
		
				$wherefield[]="status = '0'";
				
			
		$query=$this->dbConnection->BuiltQuery($this->tablename,$selectfield,$wherefield);	
		$result=$this->dbConnection->executeQuery($query);
		$i=0;
		
		if(mysql_num_rows($result)>0){
			if(empty($selectfield)){
				while($row=mysql_fetch_assoc($result)){
					$j=0;
					for($k=0;$k<count($this->field_names);$k++) {
						if($this->field_names[$k]=="employee_id"){
							$empname="Soni";
							$arrList[$i][$j++]=$empname;
						}else if($this->field_names[$k]=="user_type"){
							 
							
							 $data[0]="id='".$row[$this->field_names[$k]]."'";
							 $user_type=$this->getUsertype($data);
							 $user_name=$user_type[0][1];
							 
							$arrList[$i][$j++]=$user_name;
						}
						$arrList[$i][$j++]=$row[$this->field_names[$k]];
						
					}
						$i++;
				}
				//0->id
				//1->employee name
				//2->employeeid
				//3->username
				//4->pwd
				//5->usertype
				//6->usertypeid
				//7->status
			
			}
		
		}
		return $arrList;	
	
	}
	function checkUser($post){
	
		$action=$post['action'];
		$userid=$post['id'];
		$username_db=$this->dbConnection->idToValue($this->tablename,"user_name","id",$userid);
		$username=$post['username'];
		
		//$id=$this->dbConnection->idToValue($this->tablename,"id","user_name",$username);
		//$status=$this->dbConnection->idToValue($this->tablename,"status","id",$id);
		
		$data[0]="user_name ='".$username."'";
		$data[1]="status='0'";;
		
		
		
		$userInfo=$this->getUser('',$data);
		
		if($action == "ADD" && !empty($userInfo)){
			return false;
		}else if ($action == "UPDATE" && $username_db!=$username && !empty($userInfo)){
			return false;
		}else{
			return true;
		}
	}
	
	function login($username,$password){
	
		$password1=md5($password);
		
		$wheredata[0]="user_name = '".$username."'";
		$wheredata[1]="password ='".$password1."'";
		
		
		
		$userInfo=$this->getUser('',$wheredata);
		
		return $userInfo;
	
	}
	
	function getUsertype($wheredata = null){
	
			$arrList='';
			$i=0;
			
			if(empty($wheredata)){
				
				$wheredata[0]="status = '0'";
			}
			$query=$this->dbConnection->BuiltQuery("hcare_user_type",'',$wheredata);
			$result=$this->dbConnection->executeQuery($query);
			
			if(mysql_num_rows($result)>0){
				while($row=mysql_fetch_assoc($result)){
				
					$arrList[$i][0]=$row['id'];
					$arrList[$i][1]=$row['user_type'];
					$i++;
				
				}
			
			}
			return $arrList;
	}
        function getfullUserInfo($wheredata = null) {
                
                                $arrFieldList[0]= "a.`id`";
				$arrFieldList[1]= "a.`employee_id`";
				$arrFieldList[2]= "a.`user_name`";
				$arrFieldList[3]= "a.`password`";
				$arrFieldList[4]= "a.`user_type`";
				$arrFieldList[5]= "a.`branch`";
				$arrFieldList[6]= "a.`status`";
				$arrFieldList[7]= "b.`id`";
				$arrFieldList[8]= "b.`user_type`";
				$arrFieldList[9]= "b.`status`";

                                $arrTables[0] = "`hcare_users` a";
       			        $arrTables[1] = "`hcare_user_type` b";

                                $joinConditions[1] = "a.`user_type` = b.`id`";

                                
				if(!empty($wheredata)) {
					for($k=0;$k<count($wheredata);$k++){
					
						$selectConditions[]=$wheredata[$k];
					}
				}

                              $query=$this->dbConnection->selectFromMultipleTable($arrFieldList, $arrTables, $joinConditions,$selectConditions);
			
				$result=$this->dbConnection->executeQuery($query);
				$i=0;
                                $arrList=array();
				
				if(mysql_num_rows($result)>0){
								$i=0;
						while($row=mysql_fetch_array($result)){
									
								for($k=0;$k<count($arrFieldList);$k++) {						
								
									$arrList[$i][$k]=$row[$k];
								}
                                                    $i++;
                                               }
                               }

                    return $arrList;
				

        }



}


?>
