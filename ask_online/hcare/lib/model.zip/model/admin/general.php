<?php

require_once ROOT_PATH . '/lib/confs/DMLFunctions.php';
require_once ROOT_PATH . '/lib/confs/config.php';
class General{

	var $dbConnection;
	
	
	function General(){
		$conf=new Config();
		$this->dbConnection=new DMLFunctions($conf);
	}

	function addOpSettings($post){
		
		$field_names=array("id","op_validity","reg_fee","date");
		$field_data=array("",$post['validity_days'],$post['reg_fee'],date("Y-m-d"));
		
		$result=$this->dbConnection->insert($field_names,$field_data,"hcare_op_settings");
		
		if($result) return true;
		else return false;
	
	}
	function getOpSettings($selectfield = null,$condition =null ,$orderbyfield = null,$orderbytype = null){
	
			
			$arrList='';
			
			$query=$this->dbConnection->BuiltQuery("hcare_op_settings",$selectfield,$condition,$orderbyfield,$orderbytype);	
			$result=$this->dbConnection->executeQuery($query);
			$i=0;
			if(mysql_num_rows($result)>0){
			
				if(!empty($selectfield)){
						while($row=mysql_fetch_assoc($result)){
							for($j=0;$j<count($selectfield);$j++){
								$arrList[$i][$j]=$row[$selectfield[$j]];
							}
							$i++;
						}
				}else{
						while($row=mysql_fetch_assoc($result)){
				
								$arrList[$i][0]=$row['id'];
								$arrList[$i][1]=$row['op_validity'];
								$arrList[$i][2]=$row['reg_fee'];
								$arrList[$i][3]=$row['date'];
								$i++;
						}
				}
			
		}else{
								
		
		}
		return $arrList;
	}
	

}


?>