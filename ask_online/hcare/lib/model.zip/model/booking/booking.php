
<?php

require_once ROOT_PATH . '/lib/confs/DMLFunctions.php';
require_once ROOT_PATH . '/lib/confs/config.php';
require_once ROOT_PATH . '/lib/model/admin/employee.php';

class Booking{

	var $field_names=array("id","doc_id","cons_time","booking_limit","active","Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday");
	var $tablename="hcare_doc_scheduling";
	
	function Booking(){
		$conf=new Config();
		$this->dbConnection=new DMLFunctions($conf);
	}
	
	function getNextRegToken($docid,$date){
	
		$selectfield[0]="token_no";
		
		$wheredata[0]="doc_id ='".$docid."'";
		$wheredata[1]="visit_date ='".date("Y-m-d",strtotime($date))."'";
		$wheredata[2]="reg_from ='registration'";
		
		$query=$this->dbConnection->BuiltQuery('hcare_op_visit_info',$selectfield,$wheredata,'id','desc');	
		$result=$this->dbConnection->executeQuery($query);
		
		if(mysql_num_rows($result) > 0){
		
			$token_no =mysql_result($result,0,'token_no')+1;
			
			
			$booktoken=$this->getNextToken($docid,$date);
			if($booktoken == 1) $bookcount=0;
			
			if($token_no <$booktoken) $token_no=$booktoken;
			
		}else $token_no=1;
		
		return $token_no;
	
	}
	function getNextToken($docid,$date){
	
		$selectfield[0]="token_no";
		$wheredata[0]="doc_id ='".$docid."'";
		$wheredata[1]="booking_date ='".date("Y-m-d",strtotime($date))."'";
		$wheredata[2]="token_from ='Normal'";
		
		$query=$this->dbConnection->BuiltQuery('hcare_booking_info',$selectfield,$wheredata,'id','desc');	
		$token_no=1;
		$result=$this->dbConnection->executeQuery($query);
		
		if(mysql_num_rows($result) > 0){
		
			$token_no =mysql_result($result,0,'token_no')+1;
		}else $token_no=1;
		
		return $token_no;
	
	}
	
	function addBookingInfo($token_no,$post){
	
		$field_names=array("id","token_no","doc_id","booking_date","booked_on","patient_name","place","phone","token_from");
		$field_data=array("",$token_no,$post['id'],date("Y-m-d",strtotime($post['booking_date'])),date('Y-m-d'),$post['patient_name'],$post['place'],$post['phone'],$post['token_from']);
		
		$result=$this->dbConnection->insert($field_names,$field_data,"hcare_booking_info");
		
		if($result) return mysql_insert_id();
		else return 0;
	
	}
	function getBookingList($wheredata){
	
		$arrList='';
		$i=0;
		$query=$this->dbConnection->BuiltQuery('hcare_booking_info','',$wheredata,'id','desc');	
		$result=$this->dbConnection->executeQuery($query);
		
		if(mysql_num_rows($result) > 0){
			
			while($row=mysql_fetch_assoc($result)){
			
				$arrList[$i][0]=$row['id'];
				$arrList[$i][1]=$row['token_no'];
				$arrList[$i][2]=$row['doc_id'];
				$arrList[$i][3]=$this->dbConnection->idToValue("hcare_emp_info","title","id",$row['doc_id'])." ".$this->dbConnection->idToValue("hcare_emp_info","first_name","id",$row['doc_id'])." ".$this->dbConnection->idToValue("hcare_emp_info","last_name","id",$row['doc_id']);
				$arrList[$i][4]=date("d-m-Y",strtotime($row['booking_date']));
				$arrList[$i][5]=$row['booked_on'];
				$arrList[$i][6]=$row['patient_name'];
				$arrList[$i][7]=$row['place'];
				$arrList[$i][8]=$row['phone'];
				$arrList[$i][9]=$row['status'];
				$i++;
			}
		
		}
	
		return $arrList;
	}
	function updateToVisit($bk_id){
	
		$field_names=array("visited");
		$field_data=array("1");
	
		$result=$this->dbConnection->update($field_names,$field_data,"id",$bk_id,"hcare_booking_info");
	
	}

	

}


?>