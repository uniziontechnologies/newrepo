
<?php

require_once ROOT_PATH . '/lib/confs/DMLFunctions.php';
require_once ROOT_PATH . '/lib/confs/config.php';
require_once ROOT_PATH . '/lib/model/admin/employee.php';

class Scheduling{

	var $field_names=array("id","doc_id","cons_time","booking_limit","booking_status","Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday");
	var $tablename="hcare_doc_scheduling";
	function Scheduling(){
		$conf=new Config();
		$this->dbConnection=new DMLFunctions($conf);
	}
	function changeBookingStatus($post){
	
		$field_names=array("booking_status");
		
		 $status = $post['status'];
		 
		 if($status == "Active") $status="Blocked";
		 else $status="Active";
		
		$field_data=array($status);
		
		$result=$this->dbConnection->update($field_names,$field_data,"doc_id",$post['id'],$this->tablename);
			
			if($status == "Active") $status="Activated";
			if($result) return "$status Successfully!";
			else return "Failed To $status Doctor";
	}

	function addSheduling($postArr,$sheduledInfo){
	
		$status="Active";
	
	
	$field_data=array('',$postArr['id'],$postArr['cons_time'],$postArr['bk_limit'],$status,$sheduledInfo[0],$sheduledInfo[1],$sheduledInfo[2],$sheduledInfo[3],$sheduledInfo[4],$sheduledInfo[5],$sheduledInfo[6]);
	
	$result=$this->dbConnection->insert($this->field_names,$field_data,$this->tablename);
			
			if($result) return true;
			else return false;
	
	}
	function updateSheduling($postArr,$sheduledInfo){
	
	
		$status=$postArr['status'];	
		$field_names=array("cons_time","booking_limit","booking_status","Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday");
	
	$field_data=array($postArr['cons_time'],$postArr['bk_limit'],$status,$sheduledInfo[0],$sheduledInfo[1],$sheduledInfo[2],$sheduledInfo[3],$sheduledInfo[4],$sheduledInfo[5],$sheduledInfo[6]);
	
	
			
			
			$result=$this->dbConnection->update($field_names,$field_data,"doc_id",$postArr['id'],$this->tablename);
			
			
			if($result) return true;
			else return false;
	
	}
	function getSchedulingByDate($date,$dep_id = null){
	
		$arrList='';
		$i=0;
		
		$weekday = date('l', strtotime($date));
		$weekno	=date('N', strtotime($date));
		
		if($weekno == 7 ){
			$start=5;
		}else{
			$start=9+($weekno-1)*4;
		}
		$emp_obj=new Employee();
		
		$is_field[0]= "a.title ='Dr'";
		if(!empty($dep_id)){
		
			$is_field[1]= "b.department_id ='".$dep_id."'";
		}
		$doctors=$emp_obj->getEmployee($is_field);
		
		if(!empty($doctors)){
		
			for($k=0;$k<count($doctors);$k++){ 
				$docid=$doctors[$k][0];
				$drScheduling=$this->getDrScheduling($docid,$weekday);
				if(!empty($drScheduling)){
				
					if($drScheduling[0][4] == "Active") { 
						$arrList[$i][0]=$docid;
						$arrList[$i][1]=$doctors[$k][1]." ".$doctors[$k][2]." ".$doctors[$k][3];
						$arrList[$i][2]=$drScheduling[0][$start];
						$arrList[$i][3]=$drScheduling[0][$start+1];
						$arrList[$i][4]=$drScheduling[0][$start+2];
						$arrList[$i][5]=$drScheduling[0][$start+3];
						$i++;
					}
					
				}
			}
		}
		
		return $arrList;
	
	}
	
	function getDrScheduling($docid,$shed_day = null){
	
		$arrList='';
		$i=0;
		$l=0;
		
			$wheredata[$l++] = "doc_id =$docid";
		
		if(!empty($shed_day)){
			$wheredata[$l++] = "$shed_day !=''";
		}
		
		$query=$this->dbConnection->BuiltQuery($this->tablename,'',$wheredata);	
		$result=$this->dbConnection->executeQuery($query);
		
		if(mysql_num_rows($result)>0){
			
			while($row=mysql_fetch_assoc($result)){
				$j=0;
				for($m=0;$m<count($this->field_names);$m++) {
				
					if($m >= 5){
					
					
						$data=explode("/",$row[$this->field_names[$m]]);
						if(count($data) > 1 ){
							for($h=0;$h<count($data);$h++){
								$arrList[$i][$j++]=$data[$h];
							}
						}else{
						
							for($h=0;$h<4;$h++){
								$arrList[$i][$j++]='';
							}
						}
					}else {
						$arrList[$i][$j++]=$row[$this->field_names[$m]];
					}
				}
				
				$i++;
			
			}
		
		}
			return $arrList;
	}
	function getSchedulingList($is_field = null ){
	
		$arrList='';
		$i=0;
		$emp_obj=new Employee();
		$doctors=$emp_obj->getEmployee($is_field);
		
		if(!empty($doctors)){
		
			for($k=0;$k<count($doctors);$k++){ 
				$docid=$doctors[$k][0];
				
				$wheredata[0] = "doc_id =$docid";		
				$arrList[$i][0]=$docid;
				$arrList[$i][1]=$doctors[$k][1]." ".$doctors[$k][2]." ".$doctors[$k][3];
				
				$query=$this->dbConnection->BuiltQuery($this->tablename,$selectfield,$wheredata,$orderbyfield,$orderby);	
				$result=$this->dbConnection->executeQuery($query);
		
		
				if(mysql_num_rows($result)>0){
					if(empty($selectfield)){
						while($row=mysql_fetch_assoc($result)){
							$j=2;
							for($m=0;$m<count($this->field_names);$m++) {
						
								
								$arrList[$i][$j++]=$row[$this->field_names[$m]];
						
							}
							
						}
				//0->id
				//1->department name
				//2->employee_name
				//3->department in charge_id
				//4->phone				
				//5->status
			
					}
		
				}
				$i++;
			}
		
		}
		
		return $arrList;	
	
	}
	
	

}


?>
