
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $lang_title; ?></title>
<link rel="stylesheet" type="text/css" href="../../css/theme.css" />
<link rel="stylesheet" type="text/css" href="../../css/style.css" />
<link rel="stylesheet" type="text/css" href="../../css/dialog_box.css" />
<script type="text/javascript" src="../../js/dialog_box.js"></script>
<script type="text/javascript" src="../../js/jquery-1.2.6.min.js"></script>
<script type="text/javascript" src="../../js/common_functions.js">  </script>
<script>
   var StyleFile = "theme" + document.cookie.charAt(6) + ".css";
  
   document.writeln('<link rel="stylesheet" type="text/css" href="../../css/' + StyleFile + '">');

           $(document).ready(function(){
   
                $(".save").bind('click', function() {
		
                       if($("#station").val() == ""){
                          
                         showDialog('Error','Please Select Your Nursing Station.','error',2);
			 return false;

                      }else {
			
                        
			$("#form").attr("action","../../lib/controllers/centralController.php?module=Nurse&sub_module=save_nursing_station");
			$("#form").submit();
                     }
		});
   
        });
</script>
<!--[if IE]>
<link rel="stylesheet" type="text/css" href="css/ie-sucks.css" />
<![endif]-->
</head>
<body id="frame">
<form name="station" id="form"  method="post" action=""> 
<?php
	$stationInfo=$this->popArr['stationInfo'];
?>
 <div id="wrapper">
            <div id="content">
			<div id="box">
                	
				
				
						
						<fieldset id="op">
					
                        		<legend><?php echo $lang_select." ".$lang_nursing_station;?></legend>
								
								<label for="station"><?php echo $lang_nursing_station; ?> <span id='requiredfield'>*</span> : </label>
											
									<select name="station" id="station">
                                                                            <option value="">-------select--------</option>
                                                                            <?php

                                                                               if(!empty($stationInfo)) {

                                                                                  for($i=0;$i<count($stationInfo);$i++) {


                                                                               ?>
                                                                                 <option value="<?php echo $stationInfo[$i][0];?>"><?php echo $stationInfo[$i][1];?> </option>


                                                                          <?php }

                                                                              }

                                                                         ?>
											
										
								
								
											<br />								
										
								
									<input id="button1" type="button" name="save" class="save" value="Save" /></td>
								
					</fieldset>			
					
			</div>
			<BR />
       			
				</div>
				
			
				
            </div>
           
      </div>
	 
</form>	  
</body>
	</html>
	
