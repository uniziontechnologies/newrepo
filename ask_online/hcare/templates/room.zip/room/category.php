
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $lang_title; ?></title>
<link rel="stylesheet" type="text/css" href="../../css/theme.css" />
<link rel="stylesheet" type="text/css" href="../../css/style.css" />
<script type="text/javascript" src="../../js/common_functions.js">  </script>
<script>
   var StyleFile = "theme" + document.cookie.charAt(6) + ".css";
  
   document.writeln('<link rel="stylesheet" type="text/css" href="../../css/' + StyleFile + '">');
   
   function submitform(action,id){
   	setAction(action,id);
	
   	document.category.action="../../lib/controllers/centralController.php?module=Room&sub_module=RoomCategory";
	document.category.submit();
   }
   
   
</script>
<!--[if IE]>
<link rel="stylesheet" type="text/css" href="css/ie-sucks.css" />
<![endif]-->
</head>
<body id="frame">
<form name="category" id="form"  method="post" action=""> 
<?php
	$categoryInfo=$this->popArr['category'];
?>
 <div id="wrapper">
            <div id="content">
			<div id="box">
                	
					<h3> <?php echo $lang_search." ".$lang_room." ".$lang_category; ?></h3>
					<div align="center">
						<table>
								<tr>
										<td id="noborder"><?php echo $lang_category; ?>
											
											<input name="category" id="category" value='' autocomplete="off" />
											&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
										</td>
										
									<td id="noborder">
									&nbsp;&nbsp;
									<input id="button1" type="button" name="Search" value="Search" onclick="submitform('<?php echo $lang_search;?>','');"/></td>
								</tr>
						</table>
				
					</div>
			</div>
			<BR />
       			<div id="rightnow">
                	<h3 class="reallynow">
						<?php echo $lang_category." ".$lang_list; ?>
						 <a href="#" onClick="submitform('<?php echo $lang_create_page;?>','');"  class="add"><?php echo $lang_add." ".$lang_category;?></a>
                       
					
					</h3>
					<?php if(isset($this->popArr['message'])){?>
						<div id='message'><?php echo $this->popArr['message'];?></div>
					<?php } ?>
					<br />
			<div align="center">
			<table width="55%">
				<thead>
					<tr>
                         <th ><a href="#"><?php echo $lang_sl_no; ?></a></th>
                            	<th><a href="#"><?php echo $lang_category; ?></a></th>
                                <th><a href="#"><?php echo $lang_rent; ?></a></th>                    
                                                          
                                <th ><a href="#"><?php echo $lang_action; ?></a></th>
                            </tr>
						</thead>
						<tbody>	
		<?php
			if(!empty($categoryInfo)){
			$j=1;
				for($i=0;$i<count($categoryInfo);$i++) {?>
					<tr>
						<td><?php echo $j++;?></td>
						<td><?php echo $categoryInfo[$i][1];?></td>
						<td><?php echo $categoryInfo[$i][2];?></td>	
											
						
						<td>
							<a href="#" onClick="submitform('<?php echo $lang_edit_page;?>','<?php echo $categoryInfo[$i][0];?>');"><img src="../../img/icons/user_edit.png" title="Edit user" width="16" height="16" /></a>
							<a href="#" onClick="submitform('<?php echo $lang_delete;?>','<?php echo $categoryInfo[$i][0];?>');"><img src="../../img/icons/user_delete.png" title="Delete user" width="16" height="16" /></a>
						</td>
                           
					</tr>
						
				
		<?php	}
			
			}		
		?>
					</tbody>
				</table>
			</div>
				</div>
				
			
				
            </div>
           
      </div>
	  <input type="hidden" name="id" id="id" />
	 <input type="hidden" name="action" id="action" />
</form>	  
</body>
	</html>
	
