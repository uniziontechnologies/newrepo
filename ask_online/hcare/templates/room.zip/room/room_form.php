<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $lang_title; ?></title>

<link rel="stylesheet" type="text/css" href="../../css/theme.css" />
<link rel="stylesheet" type="text/css" href="../../css/style.css" />
<link rel="stylesheet" type="text/css" href="../../css/dialog_box.css" />
<script type="text/javascript" src="../../js/dialog_box.js"></script>
<script type="text/javascript" src="../../js/common_functions.js"></script>
<script type="text/javascript" src="../../js/jquery-1.2.6.min.js"></script>

<script>
   var StyleFile = "theme" + document.cookie.charAt(6) + ".css";
  
   document.writeln('<link rel="stylesheet" type="text/css" href="../../css/' + StyleFile + '">');
   
   $(document).ready(function(){
   	
	$("#total_bed_no").attr("readonly",true);
	$("#total_bed_no").val("1");
	
   		$("#bed_capacity").bind('change', function() {
		
			if($("#bed_capacity").val() == "MULTIBED"){
			
				$("#total_bed_no").val("");
				$("#total_bed_no").attr("readonly",false);
			}else{
			
				$("#total_bed_no").val("1");
				$("#total_bed_no").attr("readonly",true);
			}
		});
		
		$("#button1").bind('click', function() {
		
			if($("#category").val() == ""){
			
				showDialog('Error','Please Select Room Category.','error',2);
				return false;
			}else if($("#roomno").val() == ""){
			
				showDialog('Error','Please  Enter Valid Room Number.','error',2);
				return false;
			}
			else if($("#bed_capacity").val() == "MULTIBED" && $("#total_bed_no").val() ==""){
			
				showDialog('Error','Please Enter No Of Beds In the Room.','error',2);
				return false;
			}else{
			
				$("#form").attr("action","../../lib/controllers/centralController.php?module=Room&sub_module=Room");
				$("#form").submit();
			
			}
		});
   });
   
   /*function select_bedtype(){
   alert(document.room.total_bed_no.disabled);
   		if(document.room.bed_type.value =='MULTIBED'){
		    alert("1");
			document.room.total_bed_no.disabled = "false"; alert(document.room.total_bed_no.disabled);
		}else if(document.room.bed_type.value =='SINGLE'){
		alert("2");
			document.room.total_bed_no.disabled="true"; alert(document.room.total_bed_no.disabled);
		}
   }*/
</script>
<!--[if IE]>
<link rel="stylesheet" type="text/css" href="css/ie-sucks.css" />
<![endif]-->
</head>
<body id="frame" onload="document.room.category.focus();">
<form name="room" id="form" method="post" action=""> 
<?php
	$action = $this->popArr['action'];
	
	$categoryInfo=$this->popArr['categoryInfo'];
	if(isset($this->popArr['roomInfo'])){
	
		$roomInfo=$this->popArr['roomInfo'];
		$id=$roomInfo[0][0];
		$category=$roomInfo[0][1];
		$roomno=$roomInfo[0][2];
		$bed_capacity=$roomInfo[0][3];
		$total_bed_no=$roomInfo[0][4];
		
		
		
	}else{
	
		$id='';
		$category='';
		$roomno='';
		$bed_capacity='';
		$total_bed_no='';
		
	}
?>
 <div id="wrapper">
            <div id="content">
			
       			 <div id="box">
				 	
				<?php if($action == $lang_add){ ?>
				
                	<h3 id="<?php echo $lang_add.' '.$lang_room;?>" ><?php echo $lang_add.' '.$lang_room;?></h3><BR />
				<?php }else { ?>
				
					<h3 id="<?php echo $lang_update.' '.$lang_room;?>"><?php echo $lang_update.' '.$lang_room;?></h3><BR />
					
				<?php } ?>
					
					<div id='required'><?php echo $lang_markedfieldrequired; ?></div>
					
					<?php if(isset($this->popArr['message'])){?>
					
						<div id='message'><?php echo $this->popArr['message'];?></div>
						
					<?php } ?>
					
					<fieldset id="personal">
					
                        <legend><?php echo $lang_room." DETAILS ";?></legend>
						
						<label for="room_category"><?php echo $lang_category; ?> <span id='requiredfield'>*</span> : </label>
                        <!--<input name="category" id="category"  
                        tabindex="2"  onkeypress="nextField(event.keyCode,rent)" value="<?php echo $category; ?>" autocomplete="off"/>-->
						
						<select name="category" id="category"   onkeypress="nextField(event.keyCode,roomno)" onChange="nextField(event.keyCode,roomno)" /> 		
									<option value=''>------------------------------</option>
											
											<?php for($i=0;$i<count($categoryInfo);$i++){ 
																						
													if((!empty($post['category']) && $post['category']==$categoryInfo[$i][0]) || (!empty($category) && $category==$categoryInfo[$i][0])) { ?>
													
														<option value='<?php echo $categoryInfo[$i][0];?>' selected><?php echo $categoryInfo[$i][1];?></option>
										<?php   	}else {?>
										
														<option value='<?php echo $categoryInfo[$i][0];?>'><?php echo  $categoryInfo[$i][1];?></option>
												
										<?php 		} 
												} ?>
									</select>
						
                       	<br />	
						
						<label for="roomno"><?php echo $lang_room_no; ?> : </label>
                        <input name="roomno" id="roomno"  
                        tabindex="2"  onkeypress="nextField(event.keyCode,bed_capacity)" value="<?php echo $roomno ?>" autocomplete="off"/>
						
						<br />
						
						<label for="bed_capacity"><?php echo $lang_bed_capacity; ?> : </label>
						<select name="bed_capacity" id="bed_capacity"    /> 		
									
							<option value='SINGLE' <?php echo (!empty($bed_capacity) && $bed_capacity=="SINGLE")?'selected':'';?>>SINGLE</option>
									<option value='MULTIBED' <?php echo (!empty($bed_capacity) && $bed_capacity=="MULTIBED")?'selected':'';?>>MULTIBED</option>
						</select>
						
						
						<br />
					<?php if($action== $lang_add){?>
					
						<label for="total_bed_no"><?php echo $lang_bed_no; ?> : </label>
                        <input name="total_bed_no" id="total_bed_no"  
                        tabindex="2"  onkeypress="nextField(event.keyCode,Add)" value="<?php echo $total_bed_no ?>" autocomplete="off" size="5" />
						
					<?php }else { ?>
					
						<label for="total_bed_no"><?php echo $lang_bed_no; ?> : </label>
                        <input name="total_bed_no" id="total_bed_no"  
                        tabindex="2"  onkeypress="nextField(event.keyCode,Update)" value="<?php echo $total_bed_no ?>" autocomplete="off" size="5" />
					
					<?php } ?>
                       	<br />						
						
					   
				</fieldset>				
				
				
					<div align="center">
					
					<?php if($action== $lang_add){?>
                     		 <input id="button1" type="button" name="Add" value="Add" />
					<?php }else { ?>
							<input id="button1" type="button" name="Update" value="Update" />
					<?php } ?>
					
					 </div>
					
				</div>
			
				
            </div>
           
      </div>
	  <input name="action" id="action" type="hidden" value="<?php echo $action;?>" />
	   <input name="id" id="id" type="hidden" value="<?php echo $id;?>" />
</form>	  
</body>
	</html>
	
