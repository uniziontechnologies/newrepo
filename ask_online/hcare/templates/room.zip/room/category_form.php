<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $lang_title; ?></title>

<link rel="stylesheet" type="text/css" href="../../css/theme.css" />
<link rel="stylesheet" type="text/css" href="../../css/style.css" />
<link rel="stylesheet" type="text/css" href="../../css/dialog_box.css" />
<script type="text/javascript" src="../../js/dialog_box.js"></script>
<script type="text/javascript" src="../../js/common_functions.js"></script>

<script>
   var StyleFile = "theme" + document.cookie.charAt(6) + ".css";
  
   document.writeln('<link rel="stylesheet" type="text/css" href="../../css/' + StyleFile + '">');
   function submitForm(){
   
   		if(document.categoryform.category.value=='') {
   			showDialog('Error','Please Enter Room Category Name.','error',2);
			return false;
		}else if(document.categoryform.rent.value =='' ){
				showDialog('Error','Please Enter Valid Rent Amount.','error',2);
				return false;
		}else {
			document.categoryform.action="../../lib/controllers/centralController.php?module=Room&sub_module=RoomCategory";
			document.categoryform.submit();
		
		}
   
   }
</script>
<!--[if IE]>
<link rel="stylesheet" type="text/css" href="css/ie-sucks.css" />
<![endif]-->
</head>
<body id="frame" onload="document.categoryform.category.focus();">
<form name="categoryform" id="form" method="post" action=""> 
<?php
	$action = $this->popArr['action'];
	
	
	if(isset($this->popArr['categoryInfo'])){
	
		$categoryInfo=$this->popArr['categoryInfo'];
		$id=$categoryInfo[0][0];
		$category=$categoryInfo[0][1];
		$rent=$categoryInfo[0][2];
		
		
		
	}else{
	
		$id='';
		$category='';
		$rent='';
		
	}
?>
 <div id="wrapper">
            <div id="content">
			
       			 <div id="box">
				 	
				<?php if($action == $lang_add){ ?>
				
                	<h3 id="<?php echo $lang_add.' '.$lang_room.' '.$lang_category;?>" ><?php echo $lang_add.' '.$lang_room.' '.$lang_category;?></h3><BR />
				<?php }else { ?>
				
					<h3 id="<?php echo $lang_update.' '.$lang_room.' '.$lang_category;?>"><?php echo $lang_update.' '.$lang_room.' '.$lang_category;?></h3><BR />
					
				<?php } ?>
					
					<div id='required'><?php echo $lang_markedfieldrequired; ?></div>
					
					<?php if(isset($this->popArr['message'])){?>
					
						<div id='message'><?php echo $this->popArr['message'];?></div>
						
					<?php } ?>
					
					<fieldset id="personal">
					
                        <legend><?php echo $lang_room." ".$lang_category;?></legend>
						
						<label for="user"><?php echo $lang_category; ?> <span id='requiredfield'>*</span> : </label>
                        <input name="category" id="category"  
                        tabindex="2"  onkeypress="nextField(event.keyCode,rent)" value="<?php echo $category; ?>" autocomplete="off"/>
						
                       	<br />	
						
						
						
					<?php if($action== $lang_add){?>
					
						<label for="rent"><?php echo $lang_rent; ?> : </label>
                        <input name="rent" id="rent"  
                        tabindex="2"  onkeypress="nextField(event.keyCode,Add)" value="<?php echo $rent ?>" autocomplete="off"/>
						
					<?php }else { ?>
					
						<label for="rent"><?php echo $lang_rent; ?> : </label>
                        <input name="rent" id="rent"  
                        tabindex="2"  onkeypress="nextField(event.keyCode,Update)" value="<?php echo ($rent == 0 )?'':$rent ?>" autocomplete="off"/>
					
					<?php } ?>
                       	<br />						
						
					   
				</fieldset>				
				
				
					<div align="center">
					
					<?php if($action== $lang_add){?>
                     		 <input id="button1" type="button" name="Add" value="Add" onclick="return submitForm()"/>
					<?php }else { ?>
							<input id="button1" type="button" name="Update" value="Update" onclick="return submitForm()"/>
					<?php } ?>
					
					 </div>
					
				</div>
			
				
            </div>
           
      </div>
	  <input name="action" id="action" type="hidden" value="<?php echo $action;?>" />
	   <input name="id" id="id" type="hidden" value="<?php echo $id;?>" />
</form>	  
</body>
	</html>
	
