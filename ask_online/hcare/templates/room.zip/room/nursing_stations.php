<?php
session_start();

$path=$_SESSION['path'];

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $lang_title; ?></title>
<link rel="stylesheet" type="text/css" href="../../css/theme.css" />
<link rel="stylesheet" type="text/css" href="../../css/style.css" />
<script type="text/javascript" src="../../js/common_functions.js">  </script>
<link rel="stylesheet" type="text/css" href="../../css/dialog_box.css" />
<script type="text/javascript" src="../../js/dialog_box.js"></script>
<script type="text/javascript" src="../../js/jquery-1.2.6.min.js"></script>
<script>
   var StyleFile = "theme" + document.cookie.charAt(6) + ".css";
  
   document.writeln('<link rel="stylesheet" type="text/css" href="../../css/' + StyleFile + '">');
   
   $(document).ready(function(){
  
   		$(".Search").bind('click', function() {
		
			$("#form").attr("action","../../lib/controllers/centralController.php?module=Room&sub_module=Room");
			$("#form").submit();
		});
		$(".edit").bind('click', function() {	 
			
			$("#page_action").val("EDIT_PAGE");
			$("#id").val($(this).attr("id"));
		
			$(".rooms").attr("action","../../lib/controllers/centralController.php?module=Room&sub_module=Create_Nursing_Station");
			//document.rooms.action="../../lib/controllers/centralController.php?module=Room&sub_module=Room";
			//alert(document.rooms.action.value);
			
			
			$(".rooms").submit();
		});
                $(".delete").bind('click', function() {
	
                                var sid=$(this).attr("id");

                                $("#page_action").val("DELETE");
                                             
                                $("#id").val(sid);
                                var a=confirm("Do u want to Delete Nursing Station!");

                                if(a==true){
		
		                  $(".rooms").attr("action","../../lib/controllers/centralController.php?module=Room&sub_module=Process_Station");
                                  $(".rooms").submit();
                               }
                         

                     
                });
		
		$("#add").bind('click', function() {	
		
			$("#page_action").val("CREATE_PAGE");
			$("#form").attr("action","../../lib/controllers/centralController.php?module=Room&sub_module=Create_Nursing_Station");			
			$("#form").submit();
		});
   });
   
   /*function submitform(action,id){
   	setAction(action,id);
	
   	document.rooms.action="../../lib/controllers/centralController.php?module=Room&sub_module=Room";
	document.rooms.submit();
   }*/
</script>
<!--[if IE]>
<link rel="stylesheet" type="text/css" href="css/ie-sucks.css" />
<![endif]-->
</head>
<body id="frame">
<form name="rooms" id="form"  class ="rooms" method="post" action=""> 
<?php
	$roomInfo=$this->popArr['roomInfo'];
        $stationInfo=$this->popArr['stationInfo'];
?>
 <div id="wrapper">
            <div id="content">
			<div id="box">
                	
					<h3> <?php echo $lang_search." ".$lang_room ?></h3>
					<div align="center">
						<table width="90%">
								<tr>
										<td id="noborder"><?php echo $lang_room." ".$lang_category; ?>
											
											<select name="category" id="category"   onkeypress="nextField(event.keyCode,roomno)" onChange="nextField(event.keyCode,roomno)" /> 		
											<option value=''>------------------------------</option>
											
											<?php for($i=0;$i<count($categoryInfo);$i++){ 
																						
													if(!empty($post['category']) && $post['category']==$categoryInfo[$i][0]) { ?>
													
														<option value='<?php echo $categoryInfo[$i][0];?>' selected><?php echo $categoryInfo[$i][1];?></option>
											<?php   }else {?>
										
														<option value='<?php echo $categoryInfo[$i][0];?>'><?php echo  $categoryInfo[$i][1];?></option>
												
											<?php } 
												} ?>
											</select>
											
										</td>
										<td id="noborder">
												
												<?php echo $lang_room_no; ?> : 
												
												<input type="text" name="roomno" value="" />
										</td>
										
										<td id="noborder">
										
											<?php echo $lang_bed_capacity; ?> :
											
											<select name="bed_capacity" id="bed_capacity"    onChange="return select_bedtype()" /> 		
									
												<option value='SINGLE'>SINGLE</option>
												<option value='MULTIBED'>MULTIBED</option>
											</select>
										</td>
										
									<td id="noborder">
									&nbsp;&nbsp;
									<input id="button1" type="button" name="Search" class="Search" value="Search" /></td>
								</tr>
						</table>
				
					</div>
			</div>
			<BR />
       			<div id="rightnow">
                	<h3 class="reallynow">
						<?php echo $lang_nursing_station." ".$lang_list; ?>
						 <a href="#"   class="add" id="add"><?php echo $lang_create." ".$lang_nursing_station;?></a>
                       
					
					</h3>
					<?php if(isset($this->popArr['message'])){?>
						<div id='message'><?php echo $this->popArr['message'];?></div>
					<?php } ?>
					<br />
			<div align="center">
			<table width="85%" >
				
                             <thead>
					<tr>
                                            <th ><?php echo $lang_station_name;?>
                                             <th ><?php echo $lang_room."S";?>
                                              <th ><?php echo $lang_action;?>
                                        </tr>
                             </thead>
                             <tbody>
                         <?php if(!empty($stationInfo)){ 

                                     for($i=0;$i<count($stationInfo);$i++) { ?>

                                     
					<tr>
                                            <td ><?php echo $stationInfo[$i][1];?>
                                            </td>

                                          <td>


                                            <TABLE WIDTH="100%">


                                             <?php
			                      if(!empty($roomInfo)){
			                        $j=1;
				                   for($j=0;$j<count($roomInfo);$j++) {?>
					
						
                                                         <?php if($i%5 == 0) {?>

                                                            <TR>
                                                       <?php } ?>
						              <TD id="noborder"><b><?php  echo $roomInfo[$i][$j][0];?></b></TD>

                                                      <?php if(($i+1)%5 == 0) {?>
                                                              </TR> 
                                                     <?php } ?>
						
											
					
						
                           
					
						
				
		<?php	}
			
			}		
		?>
                                   </TABLE>

                                      </td>
                                      <td> <a href="#"  class="edit" id="<?php echo $stationInfo[$i][0];?>"><img src="../../img/icons/user_edit.png" title="Edit user" width="16" height="16" />&nbsp;&nbsp;<a href="#" class="delete" id="<?php echo $stationInfo[$i][0];?>"><img src="../../img/icons/user_delete.png" title="Delete user" width="16" height="16" /></a>
                                      </td>   
			                </tr>
                                  			
		
					
                 <?php	}
			
			}		
		?>
</tbody>
				</table>
			</div>
				</div>
				
			
				
            </div>
           
      </div>
	  <input type="hidden" name="id" id="id" />
	 <input type="hidden" name="page_action" id="page_action" />
</form>	  
</body>
	</html>
	
