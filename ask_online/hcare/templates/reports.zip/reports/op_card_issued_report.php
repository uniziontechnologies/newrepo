<?php
	
	$patientInfo=$this  ->popArr['patient_info'];
	$cancelled_patient_info=$this  ->popArr['cancelled_patient_info'];
	$post=$this  ->popArr['post'];
	$doctors=$this  ->popArr['doctors'];
	$user=$this  ->popArr['user'];
	$user_type=$this  ->popArr['user_type'];


if (!empty($post['pdf'])) {

ob_start();
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $lang_title; ?></title>
<link rel="stylesheet" href="../../bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="../../dist/css/font-awesome.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="../../dist/css/ionicons.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="../../dist/css/AdminLTE.min.css">
    <link rel="stylesheet" href="../../dist/css/skins/skin-blue.min.css">
<script type="text/javascript" src="../../dist/js/common_functions.js">  </script>
<link rel="stylesheet" href="../../plugins/datepicker/datepicker3.css">
<script type="text/javascript" src="../../dist/js/common_functions.js">  </script>
<script src="../../plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- Bootstrap 3.3.5 -->
    <script src="../../bootstrap/js/bootstrap.min.js"></script>
  
 <!-- date-range-picker -->
    <script src="../../plugins/datepicker/bootstrap-datepicker.js"></script>

 <script>
      $(function () {
	  
	   //Date range picker
        $('#from_date').datepicker();
		 $('#to_date').datepicker();
		 
		 var new_row="<tr><td><b>NEW:&nbsp;&nbsp;"+$('#new').val()+"<b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td><td><b>REVISIT:&nbsp;&nbsp;"+$('#revisit').val()+"<b><td><b>CANCELLED:&nbsp;&nbsp;"+$('#cancelled').val()+"<b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td><td><b>Card fee:&nbsp;&nbsp;"+$('#card_fee').val()+"</td></tr>";
	      $( "#show_total" ).append(new_row);	
	  });
	  </script>
<script>

   function submitform(action,id){
   	
	
		setAction(action,id);
   		document.patients.action="../../lib/controllers/centralController.php?module=Report&sub_module=op_card_issued";
	
		document.patients.submit();
   }
   
   
</script>
<script type="text/javascript">


function printit(){  

alert('Printing..Please make Printer and Paper Ready');
					if (window.print) {
					   window.print();  
					} else {
					   var WebBrowser = '<OBJECT ID="WebBrowser1" WIDTH=0 HEIGHT=0 CLASSID="CLSID:8856F961-340A-11D0-A96B-00C04FD705A2"></OBJECT>';
					document.body.insertAdjacentHTML('beforeEnd', WebBrowser);
					   WebBrowser1.ExecWB(6, 2);//Use a 1 vs. a 2 for a prompting dialog box    WebBrowser1.outerHTML = "";  
					}
					}
   function download_pdf(){
   	
		document.patients.action="../../lib/controllers/centralController.php?module=Report&sub_module=download_pdf";
		document.patients.submit();

   }
</script>


</head>
<body id="frame">
<form name="patients" id="form"  method="post" action=""> 

 <section class="content-header">
          <h4 class="DONTPrint"><?php echo $lang_search; ?></h4>
		  
        </section>
 
	<section class="content">
	 <div class="DONTPrint">				 
	   <div class="box box-info">
                
               <div class="box-body">
				<table class="table table-striped" >
								<tr>
										<td id="noborder"><?php echo $lang_from_date; ?>:</td>
										<td id="noborder" >	
											<input type="text" name="from_date" id="from_date"  class="DatePicker" value="<?php echo (!empty($post['from_date']))?date('d-m-Y',strtotime($post['from_date'])):date('d-m-Y');?>" readonly="true"/>
										</td>
						
											
										
										<td id="noborder"><?php echo $lang_to_date; ?>:</td>
										<td id="noborder" >	<input type="text" name="to_date" id="to_date"  class="DatePicker" value="<?php echo (!empty($post['to_date']))?date('d-m-Y',strtotime($post['to_date'])):date('d-m-Y');?>" readonly="true"/>
											
										</td>
										<td id="noborder">
										<?php echo $lang_op_no; ?></td>
									<td id="noborder" >	<input name="opno" id="opno" tabbindex="2"  onkeypress="nextField(event.keyCode,middle_name)" value="<?php echo (!empty($post['opno']))?$post['opno']:''?>" autocomplete="off"/>
									</td>
								</tr>
								<tr>
								
								<td id="noborder">
									<?php echo $lang_first_name; ?></td>
									<td id="noborder" >	 <input name="first_name" id="first_name" tabbindex="2"  onkeypress="nextField(event.keyCode,middle_name)" value="<?php echo (!empty($post['first_name']))?$post['first_name']:''?>" autocomplete="off"/> 
								 
								</td>
								<td id="noborder">							
								
								<?php echo $lang_place; ?> : </td>
													
							<td id="noborder"  >	 <input type="text" name="place" id="place"   onkeypress="nextField(event.keyCode,nationality)" value="<?php echo (!empty($post['place']))?$post['place']:''?>" /> 	 
							</td>
							
							<td id="noborder">
							<?php echo $lang_doctor; ?> </td>
								<td id="noborder" ><select name="doctor" id="doctor"   onkeypress="nextField(event.keyCode,inc)" /> 		
									<option value=''>------------------------------</option>
											
											<?php for($i=0;$i<count($doctors);$i++){ 
																						
													if(!empty($post['doctor']) && $post['doctor']==$doctors[$i][0]) { ?>
													
														<option value='<?php echo $doctors[$i][0];?>' selected><?php echo $doctors[$i][1].".".$doctors[$i][2]." ".$doctors[$i][3];?></option>
										<?php   	}else {?>
										
														<option value='<?php echo $doctors[$i][0];?>'><?php echo  $doctors[$i][1].".".$doctors[$i][2]." ".$doctors[$i][3];?></option>
												
										<?php 		} 
												} ?>
									</select>
							</td>	
								
								</tr>
								<tr>	
                                                                       <td id="noborder">
							<?php echo $lang_user; ?><?php echo $lang_type; ?> </td>
								<td id="noborder" ><select name="user_type" id="user_type"   onkeypress="nextField(event.keyCode,user)" onchange="submitform();"/> 		
									<option value=''>------------------------------</option>
											
											<?php for($i=0;$i<count($user_type);$i++){ 
																						
													if(!empty($post['user_type']) && $post['user_type']==$user_type[$i][0]) { ?>
													
														<option value='<?php echo $user_type[$i][0];?>' selected><?php echo $user_type[$i][1];?></option>
										<?php   	}else {?>
										
														<option value='<?php echo $user_type[$i][0];?>'><?php echo $user_type[$i][1];?></option>
												
										<?php 		} 
												} ?>
									</select>
							</td>
						<td id="noborder">
							<?php echo $lang_user; ?> </td>
								<td id="noborder" ><select name="user" id="user"   onkeypress="nextField(event.keyCode,inc)" /> 		
									<option value=''>------------------------------</option>
											
											<?php for($i=0;$i<count($user);$i++){ 
																						
													if(!empty($post['user']) && $post['user']==$user[$i][0]) { ?>
													
														<option value='<?php echo $user[$i][0];?>' selected><?php echo $user[$i][3];?></option>
										<?php   	}else {?>
										
														<option value='<?php echo $user[$i][0];?>'><?php echo $user[$i][3];?></option>
												
										<?php 		} 
												} ?>
									</select>
							</td>
															
									<td id="noborder" colspan="2" align="center">
									&nbsp;&nbsp;
									<input id="button1" type="button" name="Search" value="Search" class="btn btn-success" onclick="submitform('<?php echo $lang_search;?>','');"/>
									<input id="button1" type="button" name="Clear" value="Clear"  class="btn btn-info" onclick="submitform('<?php echo $lang_clear;?>','');"/>
									</td>
								</tr>
						</table>
				
					</div>
			</div>
		</div>
			<h4 >CARD ISSUED PATIENTS&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; From <?php echo date("d-m-Y",strtotime($post['from_date'])); ?> To <?php echo $post['to_date'];?></h4>
			<table width="65%" >
				<thead>
					<tr>
						 <th ><a href="#">Patients Visited</a></th><th ><a href="#">Total Fees collected</a></th>
					</tr>
				</thead>
				<tbody id="show_total">
					
				</tbody>
				</table>
			<div class="box box-info">
                
                           <div class="box-body">

<?php

if (!empty($post['pdf'])) {

ob_end_clean();
ob_start();

?>

	<h4>CARD ISSUED PATIENTS&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; From <?php if (!empty($post['from_date'])) {
		echo $post['from_date'];} if (!empty($post['to_date'])) {
			echo "To ".$post['to_date'];
		}?></h4>

<?php
}
?>

			        <table class="table table-bordered table-striped" border="1" style="border-collapse: collapse;">
       			
       			
				<thead>
					<tr>
                          <th width="4%"><a href="#"><?php echo $lang_sl_no; ?></a></th>
						   <th width="10%" ><a href="#"><?php echo $lang_op;?></a></th>
						 <th width="10%"><a href="#"><?php echo $lang_op_no; ?></a></th>
						 <th width="15%"><a href="#"><?php echo $lang_patient." ".$lang_name; ?></a></th>
						 <th width="3%"><a href="#"><?php echo $lang_age; ?></a></th>	
						 <th width="3%"><a href="#"><?php echo $lang_gender; ?></a></th>   					  
                           <th width="10%"><a href="#"><?php echo $lang_place; ?></a></th>
						    <th width="5%"><a href="#"><?php echo $lang_date; ?></a></th>
							<th width="5%"><a href="#"><?php echo $lang_time; ?></a></th>
												
						    <th width="14%"><a href="#"><?php echo $lang_doctor; ?></a></th>
							
							   <th width="5%"><a href="#"><?php echo $lang_card_fee; ?></a></th>
							  <th width="5%"><a href="#"><?php echo $lang_visit_status; ?></a></th>
							  <th width="5%"><a href="#"><?php echo $lang_card_status; ?></a></th>
							                        
							                               
                                
                            </tr>
						</thead>
						<tbody>	
		<?php
		$free=0;
		$visit=0;
		$new=0;
		$revisit=0;
	
		$card_fee=0;
			if(!empty($patientInfo)){
			$j=1;
				for($i=0;$i<count($patientInfo);$i++) {?>
					<tr>
						<td><?php echo $j++;?></td>
						<td><?php echo $patientInfo[$i][39]."/".date("Y",strtotime($patientInfo[0][20]));?></td>
						<td><?php echo $patientInfo[$i][0];?></td>
						<td><?php echo	$patientInfo[$i][1]." ".$patientInfo[$i][2];//." ".$patientInfo[$i][3];?></td>
						<td><?php echo $patientInfo[$i][4];?></td>
						<td><?php echo $patientInfo[$i][6];?></td>
						<td><?php echo $patientInfo[$i][8];?></td>
						<td><?php echo $patientInfo[$i][20];?></td>
						<td><?php echo $patientInfo[$i][19];?></td><td><?php echo $lang_dr.". ".$patientInfo[$i][15]." ".$patientInfo[$i][16];?></td>
						
						<td><?php echo $patientInfo[$i][52];?></td>
						<td>
							<?php if($patientInfo[$i][41] == 1) echo "FREE";
									else echo $patientInfo[$i][32];?></td>
						
						
					<td><?php echo $patientInfo[$i][54];?></td>
                           
					</tr>
						
				<?php
				
						 
						 if (!empty($patientInfo[$i][32]) && $patientInfo[$i][32]=="REVISIT" ) {
						 	$revisit+=1;
						 }
						 else{
						 	$new +=1;
						 }
						
						
						$card_fee +=$patientInfo[$i][52];
				?>
		<?php	}
			
			}		
		?>
					</tbody>
				</table>
				<br /><br />
				
			</div>
				</div>
				
			<div class="box box-info">
                
                           <div class="box-body">
			        <table class="table table-bordered table-striped" border="1" style="border-collapse: collapse;">
       			
       			
				<thead>
					<tr>
                          <th width="4%"><a href="#"><?php echo $lang_sl_no; ?></a></th>
						   <th width="10%" ><a href="#"><?php echo $lang_op;?></a></th>
						 <th width="10%"><a href="#"><?php echo $lang_op_no; ?></a></th>
						 <th width="15%"><a href="#"><?php echo $lang_patient." ".$lang_name; ?></a></th>
						 <th width="3%"><a href="#"><?php echo $lang_age; ?></a></th>	
						 <th width="3%"><a href="#"><?php echo $lang_gender; ?></a></th>   					  
                           <th width="10%"><a href="#"><?php echo $lang_place; ?></a></th>
						    <th width="5%"><a href="#"><?php echo $lang_date; ?></a></th>
							<th width="5%"><a href="#"><?php echo $lang_time; ?></a></th>
												
						    <th width="14%"><a href="#"><?php echo $lang_doctor; ?></a></th>
							
							   <th width="5%"><a href="#"><?php echo $lang_card_fee; ?></a></th>
							  <th width="5%"><a href="#"><?php echo $lang_visit_status; ?></a></th>
							  <th width="5%"><a href="#"><?php echo $lang_card_status; ?></a></th>
							                        
							                               
                                
                            </tr>
						</thead>
						<tbody>	
		<?php
		
		$cancelled=0;
	
		
			if(!empty($cancelled_patient_info)){
			$j=1;
				for($i=0;$i<count($cancelled_patient_info);$i++) {?>
					<tr>
						<td><?php echo $j++;?></td>
						<td><?php echo $cancelled_patient_info[$i][39]."/".date("Y",strtotime($cancelled_patient_info[0][20]));?></td>
						<td><?php echo $cancelled_patient_info[$i][0];?></td>
						<td><?php echo	$cancelled_patient_info[$i][1]." ".$cancelled_patient_info[$i][2];//." ".$patientInfo[$i][3];?></td>
						<td><?php echo $cancelled_patient_info[$i][4];?></td>
						<td><?php echo $cancelled_patient_info[$i][6];?></td>
						<td><?php echo $cancelled_patient_info[$i][8];?></td>
						<td><?php echo $cancelled_patient_info[$i][20];?></td>
						<td><?php echo $cancelled_patient_info[$i][19];?></td><td><?php echo $lang_dr.". ".$cancelled_patient_info[$i][15]." ".$cancelled_patient_info[$i][16];?></td>
						
						<td><?php echo $cancelled_patient_info[$i][52];?></td>
						<td>
							<?php if($cancelled_patient_info[$i][41] == 1) echo "FREE";
									else echo $cancelled_patient_info[$i][32];?></td>
						
						
					<td><?php echo $cancelled_patient_info[$i][54];?></td>
                           
					</tr>
						
				<?php
				
						 $cancelled +=1;
						
						
						$card_fee +=$cancelled_patient_info[$i][52];
				?>
		<?php	}
			
			}		
		?>
					</tbody>
				</table>
				<br /><br />
				
			</div>
				</div>
	<input type="hidden" name="new" id="new" value="<?php echo $new;?>"/>
	<input type="hidden" name="cancelled" id="cancelled" value="<?php echo $cancelled;?>"/>
	<input type="hidden" name="revisit" id="revisit" value="<?php echo $revisit;?>"/>
	<input type="hidden" name="card_fee" id="card_fee" value="<?php echo $card_fee;?>"/>
	  <input type="hidden" name="id" id="id" />
	 <input type="hidden" name="action" id="action" />
	 <input type="hidden" name="page_name" id="op_card_issued" value="op_card_issued" />
	 
	 <?php if(!isset($_POST['export']) && empty($post['pdf']) )
{?>
<div class="DONTPrint" align="center"><input  type="button" name="but" value="Print"  class="btn btn-info" onClick="printit()">&nbsp;<input  type="button" name="but" value="Download" class="btn btn-danger"  onclick="download_pdf()">
</div>

<?php }?>
</section>	 
</form>	  

</body>
	</html>
	
<?php
if (!empty($post['pdf'])) {

$myvar = ob_get_clean();
ob_end_clean();


$myvar = utf8_encode($myvar);
$mpdf = new mPDF('utf-8', 'A4-L');
$mpdf->allow_charset_conversion = TRUE;
$mpdf->charset_in = 'UTF8'; 
$mpdf->WriteHTML($myvar);
$mpdf->Output("Op-Card-Issued-Report.pdf", "D"); 


}





 ?>